
from PyQt6.QtCore import QDate, QDateTime
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem, QAbstractItemView
from ui_py.ui_main import Ui_MainWindow
from db import DB
from queries import Q
from windows.edit_dialog import EditDialog

STYLESHEET = """
QWidget { background:
QLineEdit, QComboBox, QDateEdit, QDateTimeEdit, QSpinBox, QDoubleSpinBox, QListWidget {
  background:
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QDateTimeEdit:focus, QListWidget:focus { border: 1px solid
QPushButton { background:
QPushButton:hover { background:
QPushButton:pressed { background:
QTableWidget { background:
QHeaderView::section { background:
QTableWidget::item:selected { background:
"""

class MainWindow(QMainWindow):
    def __init__(self, role, client_id, username):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setStyleSheet(STYLESHEET)
        self.db = DB()
        self.role = role
        self.client_id = client_id
        self.username = username
        self._setup_tables()
        self._init_defaults()
        self._load_lists()
        self.role_apply(role)
        self._bind()
        self.reload_admin_all()
        self.reload_price()
        self.reload_client_orders()

    def _setup_tables(self):
        for tw in [self.ui.tw_admin, self.ui.tw_services, self.ui.tw_parts, self.ui.tw_client_orders]:
            tw.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            tw.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            tw.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            tw.setAlternatingRowColors(True)

    def _init_defaults(self):
        today = QDate.currentDate()
        self.ui.de_a_from.setDate(today.addMonths(-1))
        self.ui.de_a_to.setDate(today)
        self.ui.de_d_from.setDate(today.addMonths(-1))
        self.ui.de_d_to.setDate(today)
        self.ui.dt_c_sched.setDateTime(QDateTime.currentDateTime().addSecs(3600))

        self.ui.cb_a_status.clear()
        self.ui.cb_a_status.addItem("Все", "ALL")
        for s in ["WAITING","IN_WORK","WAIT_PARTS","WAIT_APPROVAL","COMPLETED","ISSUED","CANCELLED"]:
            self.ui.cb_a_status.addItem(s, s)

    def _bind(self):
        self.ui.btn_a_filter.clicked.connect(self.reload_admin_filtered)
        self.ui.btn_a_reset.clicked.connect(self.reload_admin_all)
        self.ui.btn_a_add.clicked.connect(self.add_wo)
        self.ui.btn_a_edit.clicked.connect(self.edit_wo)
        self.ui.btn_a_details.clicked.connect(self.details_wo)
        self.ui.btn_a_act.clicked.connect(self.act_wo)

        self.ui.btn_d_avg.clicked.connect(self.avg_check)

        self.ui.btn_srv_add.clicked.connect(self.add_service)
        self.ui.btn_srv_edit.clicked.connect(self.edit_service)
        self.ui.btn_srv_del.clicked.connect(self.del_service)

        self.ui.btn_part_add.clicked.connect(self.add_part)
        self.ui.btn_part_edit.clicked.connect(self.edit_part)
        self.ui.btn_part_del.clicked.connect(self.del_part)

        self.ui.cb_c_category.currentIndexChanged.connect(self._reload_client_services)
        self.ui.btn_c_book.clicked.connect(self.client_book)

    def role_apply(self, role):
        idx_a = self.ui.tabs_main.indexOf(self.ui.tab_admin)
        idx_d = self.ui.tabs_main.indexOf(self.ui.tab_director)
        idx_c = self.ui.tabs_main.indexOf(self.ui.tab_client)
        self.ui.tabs_main.setTabVisible(idx_a, role in ("admin",))
        self.ui.tabs_main.setTabVisible(idx_d, role in ("director",))
        self.ui.tabs_main.setTabVisible(idx_c, role in ("client",))
        if role == "admin":
            self.ui.tabs_main.setCurrentIndex(idx_a)
        elif role == "director":
            self.ui.tabs_main.setCurrentIndex(idx_d)
        else:
            self.ui.tabs_main.setCurrentIndex(idx_c)

    def _load_lists(self):
        try:
            self.cats = self.db.fetchall(Q["cat_list"])
            self.ui.cb_c_category.clear()
            for c in self.cats:
                self.ui.cb_c_category.addItem(c["name"], c["id"])
            self._reload_client_services()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def _reload_client_services(self):
        try:
            cat_id = self.ui.cb_c_category.currentData()
            rows = self.db.fetchall(Q["services_by_cat"], (cat_id,))
            self.ui.cb_c_service.clear()
            for r in rows:
                self.ui.cb_c_service.addItem(f'{r["name"]} — {r["price"]}', r["id"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_table(self, tw, rows, headers, keys):
        tw.clear()
        tw.setColumnCount(len(headers))
        tw.setRowCount(len(rows))
        tw.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, k in enumerate(keys):
                v = row.get(k)
                tw.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        tw.resizeColumnsToContents()

    def selected_id(self, tw, col=0):
        sel = tw.selectedItems()
        if not sel:
            return None
        row = sel[0].row()
        try:
            return int(tw.item(row, col).text())
        except:
            return None

    def reload_admin_all(self):
        try:
            rows = self.db.fetchall(Q["wo_all"])
            self.load_table(self.ui.tw_admin, rows,
                            ["ID","Создан","Запись","Статус","Готовность","Сумма","Клиент","Тел","Авто","Госномер","Механик"],
                            ["wo_id","created_at","scheduled_at","status","eta_date","total_amount","client_fio","client_phone","model","plate","mechanic_fio"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_admin_filtered(self):
        try:
            st = self.ui.cb_a_status.currentData()
            d_from = self.ui.de_a_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_a_to.date().toString("yyyy-MM-dd")
            rows = self.db.fetchall(Q["wo_filter"], (st, st, d_from, d_to))
            self.load_table(self.ui.tw_admin, rows,
                            ["ID","Создан","Запись","Статус","Готовность","Сумма","Клиент","Тел","Авто","Госномер","Механик"],
                            ["wo_id","created_at","scheduled_at","status","eta_date","total_amount","client_fio","client_phone","model","plate","mechanic_fio"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_wo(self):
        dlg = EditDialog(EditDialog.MODE_WO, db=self.db, parent=self)
        if dlg.exec():
            self.reload_admin_all()

    def edit_wo(self):
        wid = self.selected_id(self.ui.tw_admin, 0)
        if not wid:
            QMessageBox.warning(self, "Заказ-наряд", "Выбери заказ-наряд.")
            return
        dlg = EditDialog(EditDialog.MODE_WO, db=self.db, record={"wo_id": wid}, parent=self)
        if dlg.exec():
            self.reload_admin_all()

    def details_wo(self):
        wid = self.selected_id(self.ui.tw_admin, 0)
        if not wid:
            QMessageBox.warning(self, "Детализация", "Выбери заказ-наряд.")
            return
        try:
            head = self.db.fetchone("SELECT * FROM v_work_orders WHERE wo_id=%s", (wid,))
            sv = self.db.fetchall(Q["wo_lines_services"], (wid,))
            pt = self.db.fetchall(Q["wo_lines_parts"], (wid,))
            t = []
            t.append(f'ЗАКАЗ-НАРЯД №{head["wo_id"]}')
            t.append(f'Клиент: {head["client_fio"]} | {head["client_phone"]}')
            t.append(f'Авто: {head["brand"]} {head["model"]} | {head["plate"]} | VIN {head["vin"]}')
            t.append(f'Статус: {head["status"]} | Механик: {head.get("mechanic_fio") or "-"} | Готовность: {head.get("eta_date") or "-"}')
            t.append("")
            t.append("Работы:")
            if not sv:
                t.append("-")
            for x in sv:
                t.append(f'- {x["name"]} | {x["unit_price"]} x {x["qty"]} = {x["line_sum"]}')
            t.append("")
            t.append("Запчасти:")
            if not pt:
                t.append("-")
            for x in pt:
                t.append(f'- {x["name"]} | {x["unit_price"]} x {x["qty"]} = {x["line_sum"]}')
            t.append("")
            t.append(f'Итого: {head["total_amount"]}')
            QMessageBox.information(self, "Детализация", "\n".join(t))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def act_wo(self):
        wid = self.selected_id(self.ui.tw_admin, 0)
        if not wid:
            QMessageBox.warning(self, "Акт", "Выбери заказ-наряд.")
            return
        try:
            head = self.db.fetchone("SELECT * FROM v_work_orders WHERE wo_id=%s", (wid,))
            t = []
            t.append("АКТ ПРИЕМА-ПЕРЕДАЧИ")
            t.append(f'Заказ-наряд №{head["wo_id"]}')
            t.append(f'Клиент: {head["client_fio"]} ({head["client_phone"]})')
            t.append(f'Авто: {head["brand"]} {head["model"]}, {head["year"] if "year" in head else ""}')
            t.append(f'Госномер: {head["plate"]}, VIN: {head["vin"]}')
            t.append(f'Дата приема: {head["created_at"]}')
            t.append(f'Статус: {head["status"]}')
            QMessageBox.information(self, "Акт", "\n".join([x for x in t if x.strip()]))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def avg_check(self):
        try:
            d_from = self.ui.de_d_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_d_to.date().toString("yyyy-MM-dd")
            res = self.db.callproc_one("sp_avg_check_period", (d_from, d_to))
            self.ui.lbl_d_avg.setText(str(res["avg_check"] if res else 0.00))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_price(self):
        try:
            s = self.db.fetchall(Q["services_all"])
            self.load_table(self.ui.tw_services, s, ["ID","Категория","Услуга","Цена"], ["id","category","name","price"])
            p = self.db.fetchall(Q["parts_all"])
            self.load_table(self.ui.tw_parts, p, ["ID","Запчасть","Цена","Остаток"], ["id","name","price","stock_qty"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_service(self):
        dlg = EditDialog(EditDialog.MODE_SERVICE, db=self.db, parent=self)
        if dlg.exec():
            self.reload_price()

    def edit_service(self):
        sid = self.selected_id(self.ui.tw_services, 0)
        if not sid:
            QMessageBox.warning(self, "Услуги", "Выбери услугу.")
            return
        dlg = EditDialog(EditDialog.MODE_SERVICE, db=self.db, record={"id": sid}, parent=self)
        if dlg.exec():
            self.reload_price()

    def del_service(self):
        sid = self.selected_id(self.ui.tw_services, 0)
        if not sid:
            QMessageBox.warning(self, "Услуги", "Выбери услугу.")
            return
        try:
            self.db.execute(Q["service_delete"], (sid,))
            self.reload_price()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_part(self):
        dlg = EditDialog(EditDialog.MODE_PART, db=self.db, parent=self)
        if dlg.exec():
            self.reload_price()

    def edit_part(self):
        pid = self.selected_id(self.ui.tw_parts, 0)
        if not pid:
            QMessageBox.warning(self, "Запчасти", "Выбери запчасть.")
            return
        dlg = EditDialog(EditDialog.MODE_PART, db=self.db, record={"id": pid}, parent=self)
        if dlg.exec():
            self.reload_price()

    def del_part(self):
        pid = self.selected_id(self.ui.tw_parts, 0)
        if not pid:
            QMessageBox.warning(self, "Запчасти", "Выбери запчасть.")
            return
        try:
            self.db.execute(Q["part_delete"], (pid,))
            self.reload_price()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_client_orders(self):
        if not self.client_id:
            return
        try:
            cl = self.db.fetchone("SELECT email FROM clients WHERE id=%s", (self.client_id,))
            if not cl:
                return
            rows = self.db.fetchall(Q["wo_by_client"], (cl["email"],))
            self.load_table(self.ui.tw_client_orders, rows,
                            ["ID","Создан","Запись","Статус","Сумма","Авто","Госномер"],
                            ["wo_id","created_at","scheduled_at","status","total_amount","model","plate"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def client_book(self):
        if not self.client_id:
            QMessageBox.warning(self, "Запись", "Нет client_id.")
            return
        try:
            car = self.db.fetchone("SELECT id FROM cars WHERE client_id=%s ORDER BY id LIMIT 1", (self.client_id,))
            if not car:
                QMessageBox.warning(self, "Запись", "У клиента нет авто. Добавь авто через администратора.")
                return
            car_id = int(car["id"])
            sched = self.ui.dt_c_sched.dateTime().toString("yyyy-MM-dd HH:mm:ss")
            complaint = self.ui.le_c_complaint.text().strip() or "Запись клиента"
            mech_id = None
            eta = None
            status = "WAITING"
            service_id = self.ui.cb_c_service.currentData()
            total = 0.0
            wid = self.db.execute(Q["wo_insert"], (self.client_id, car_id, sched, complaint, None, status, mech_id, eta, total))
            if service_id:
                price = float(self.db.fetchone(Q["service_price"], (service_id,))["price"])
                self.db.execute(Q["wos_add"], (wid, int(service_id), 1, price, price))
                self.db.execute("UPDATE work_orders SET total_amount=%s WHERE id=%s", (price, wid))
            self.reload_client_orders()
            QMessageBox.information(self, "Запись", f"Запись создана (№{wid}).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))
