
from PyQt6.QtCore import QDate, QDateTime
from PyQt6.QtWidgets import QDialog, QMessageBox, QAbstractItemView, QTableWidgetItem
from ui_py.ui_edit_dialog import Ui_EditDialog
from queries import Q

class EditDialog(QDialog):
    MODE_WO = "wo"
    MODE_SERVICE = "service"
    MODE_PART = "part"

    def __init__(self, mode, db, record=None, parent=None):
        super().__init__(parent)
        self.ui = Ui_EditDialog()
        self.ui.setupUi(self)
        self.db = db
        self.mode = mode
        self.record = record or {}
        self.ui.btn_cancel.clicked.connect(self.reject)
        self.ui.btn_save.clicked.connect(self.save)

        self.ui.tw_srv.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.ui.tw_part.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.ui.tw_srv.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.ui.tw_part.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.ui.tw_srv.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.ui.tw_part.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.ui.tw_srv.setAlternatingRowColors(True)
        self.ui.tw_part.setAlternatingRowColors(True)

        self.srv_lines = []
        self.part_lines = []

        self.ui.btn_add_srv.clicked.connect(self.add_service_line)
        self.ui.btn_add_part.clicked.connect(self.add_part_line)
        self.ui.btn_recalc.clicked.connect(self.recalc_total)
        self.ui.cb_cat.currentIndexChanged.connect(self._reload_services_combo)

        self._init_mode()

    def _init_mode(self):
        if self.mode == self.MODE_WO:
            self.ui.stack.setCurrentIndex(0)
            self._load_wo()
        else:
            self.ui.stack.setCurrentIndex(1)
            self._load_price()

    def _load_wo(self):
        self.clients = self.db.fetchall(Q["clients_list"])
        self.cars = self.db.fetchall(Q["cars_list"])
        self.mech = self.db.fetchall(Q["mech_list"])
        self.cats = self.db.fetchall(Q["cat_list"])
        self.parts = self.db.fetchall(Q["parts_all"])

        self.ui.cb_client.clear()
        for c in self.clients:
            self.ui.cb_client.addItem(c["fio"], c["id"])

        self.ui.cb_car.clear()
        for ca in self.cars:
            self.ui.cb_car.addItem(ca["title"], ca["id"])

        self.ui.cb_mech.clear()
        self.ui.cb_mech.addItem("Не назначен", None)
        for m in self.mech:
            self.ui.cb_mech.addItem(m["fio"], m["id"])

        self.ui.cb_cat.clear()
        for cat in self.cats:
            self.ui.cb_cat.addItem(cat["name"], cat["id"])

        self.ui.cb_part.clear()
        for p in self.parts:
            self.ui.cb_part.addItem(f'{p["name"]} — {p["price"]} (остаток {p["stock_qty"]})', p["id"])

        now = QDateTime.currentDateTime().addSecs(3600)
        self.ui.dt_sched.setDateTime(now)
        self.ui.de_eta.setDate(QDate.currentDate().addDays(2))
        self._reload_services_combo()

        if self.record.get("wo_id"):
            w = self.db.fetchone("SELECT * FROM work_orders WHERE id=%s", (self.record["wo_id"],))
            if w:
                i = self.ui.cb_client.findData(w["client_id"])
                if i >= 0: self.ui.cb_client.setCurrentIndex(i)
                i = self.ui.cb_car.findData(w["car_id"])
                if i >= 0: self.ui.cb_car.setCurrentIndex(i)
                if w.get("scheduled_at"):
                    self.ui.dt_sched.setDateTime(QDateTime.fromString(str(w["scheduled_at"]), "yyyy-MM-dd HH:mm:ss"))
                self.ui.le_complaint.setText(w.get("complaint") or "")
                self.ui.le_diagnosis.setText(w.get("diagnosis") or "")
                self.ui.cb_status.setCurrentText(w["status"])
                i = self.ui.cb_mech.findData(w.get("mechanic_id"))
                if i >= 0: self.ui.cb_mech.setCurrentIndex(i)
                if w.get("eta_date"):
                    self.ui.de_eta.setDate(QDate.fromString(str(w["eta_date"]), "yyyy-MM-dd"))
                self.ui.lbl_total.setText(str(w.get("total_amount") or 0.00))

                sl = self.db.fetchall("SELECT service_id, qty, unit_price, line_sum FROM wo_services WHERE work_order_id=%s", (w["id"],))
                pl = self.db.fetchall("SELECT part_id, qty, unit_price, line_sum FROM wo_parts WHERE work_order_id=%s", (w["id"],))
                self.srv_lines = [{"id":x["service_id"], "qty":int(x["qty"]), "unit_price":float(x["unit_price"]), "line_sum":float(x["line_sum"])} for x in sl]
                self.part_lines = [{"id":x["part_id"], "qty":int(x["qty"]), "unit_price":float(x["unit_price"]), "line_sum":float(x["line_sum"])} for x in pl]
                self._render_lines()

    def _load_price(self):
        self.cats = self.db.fetchall(Q["cat_list"])
        self.ui.cb_p_cat.clear()
        self.ui.cb_p_cat.addItem("—", None)
        for cat in self.cats:
            self.ui.cb_p_cat.addItem(cat["name"], cat["id"])

        if self.mode == self.MODE_SERVICE:
            self.ui.sp_p_stock.setEnabled(False)
            if self.record.get("id"):
                r = self.db.fetchone("SELECT category_id, name, price FROM services WHERE id=%s", (self.record["id"],))
                if r:
                    i = self.ui.cb_p_cat.findData(r["category_id"])
                    if i >= 0: self.ui.cb_p_cat.setCurrentIndex(i)
                    self.ui.le_p_name.setText(r["name"])
                    self.ui.sp_p_price.setValue(float(r["price"]))
        else:
            self.ui.cb_p_cat.setEnabled(False)
            self.ui.sp_p_stock.setEnabled(True)
            if self.record.get("id"):
                r = self.db.fetchone("SELECT name, price, stock_qty FROM parts WHERE id=%s", (self.record["id"],))
                if r:
                    self.ui.le_p_name.setText(r["name"])
                    self.ui.sp_p_price.setValue(float(r["price"]))
                    self.ui.sp_p_stock.setValue(int(r["stock_qty"]))

    def _reload_services_combo(self):
        cat_id = self.ui.cb_cat.currentData()
        self.services = self.db.fetchall(Q["services_by_cat"], (cat_id,))
        self.ui.cb_service.clear()
        for s in self.services:
            self.ui.cb_service.addItem(f'{s["name"]} — {s["price"]}', s["id"])

    def add_service_line(self):
        sid = self.ui.cb_service.currentData()
        qty = int(self.ui.sp_srv_qty.value())
        if not sid:
            return
        price = float(self.db.fetchone(Q["service_price"], (sid,))["price"])
        line = next((x for x in self.srv_lines if x["id"]==sid), None)
        if line:
            line["qty"] += qty
            line["line_sum"] = round(line["qty"] * line["unit_price"], 2)
        else:
            self.srv_lines.append({"id": int(sid), "qty": qty, "unit_price": price, "line_sum": round(price*qty, 2)})
        self._render_lines()
        self.recalc_total()

    def add_part_line(self):
        pid = self.ui.cb_part.currentData()
        qty = int(self.ui.sp_part_qty.value())
        if not pid:
            return
        price = float(self.db.fetchone(Q["part_price"], (pid,))["price"])
        line = next((x for x in self.part_lines if x["id"]==pid), None)
        if line:
            line["qty"] += qty
            line["line_sum"] = round(line["qty"] * line["unit_price"], 2)
        else:
            self.part_lines.append({"id": int(pid), "qty": qty, "unit_price": price, "line_sum": round(price*qty, 2)})
        self._render_lines()
        self.recalc_total()

    def _render_lines(self):
        def name_service(sid):
            r = self.db.fetchone("SELECT name FROM services WHERE id=%s", (sid,))
            return r["name"] if r else str(sid)
        def name_part(pid):
            r = self.db.fetchone("SELECT name FROM parts WHERE id=%s", (pid,))
            return r["name"] if r else str(pid)

        self.ui.tw_srv.clear()
        self.ui.tw_srv.setColumnCount(5)
        self.ui.tw_srv.setHorizontalHeaderLabels(["ID","Услуга","Кол-во","Цена","Сумма"])
        self.ui.tw_srv.setRowCount(len(self.srv_lines))
        for i, ln in enumerate(self.srv_lines):
            self.ui.tw_srv.setItem(i,0,QTableWidgetItem(str(ln["id"])))
            self.ui.tw_srv.setItem(i,1,QTableWidgetItem(name_service(ln["id"])))
            self.ui.tw_srv.setItem(i,2,QTableWidgetItem(str(ln["qty"])))
            self.ui.tw_srv.setItem(i,3,QTableWidgetItem(str(ln["unit_price"])))
            self.ui.tw_srv.setItem(i,4,QTableWidgetItem(str(ln["line_sum"])))
        self.ui.tw_srv.resizeColumnsToContents()

        self.ui.tw_part.clear()
        self.ui.tw_part.setColumnCount(5)
        self.ui.tw_part.setHorizontalHeaderLabels(["ID","Запчасть","Кол-во","Цена","Сумма"])
        self.ui.tw_part.setRowCount(len(self.part_lines))
        for i, ln in enumerate(self.part_lines):
            self.ui.tw_part.setItem(i,0,QTableWidgetItem(str(ln["id"])))
            self.ui.tw_part.setItem(i,1,QTableWidgetItem(name_part(ln["id"])))
            self.ui.tw_part.setItem(i,2,QTableWidgetItem(str(ln["qty"])))
            self.ui.tw_part.setItem(i,3,QTableWidgetItem(str(ln["unit_price"])))
            self.ui.tw_part.setItem(i,4,QTableWidgetItem(str(ln["line_sum"])))
        self.ui.tw_part.resizeColumnsToContents()

    def recalc_total(self):
        total = 0.0
        for ln in self.srv_lines:
            total += float(ln["line_sum"])
        for ln in self.part_lines:
            total += float(ln["line_sum"])
        total = round(total, 2)
        self.ui.lbl_total.setText(str(total))
        return total

    def save(self):
        try:
            if self.mode == self.MODE_WO:
                self._save_wo()
            elif self.mode == self.MODE_SERVICE:
                self._save_service()
            else:
                self._save_part()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _save_wo(self):
        client_id = int(self.ui.cb_client.currentData())
        car_id = int(self.ui.cb_car.currentData())
        sched = self.ui.dt_sched.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        complaint = self.ui.le_complaint.text().strip() or None
        diagnosis = self.ui.le_diagnosis.text().strip() or None
        status = self.ui.cb_status.currentText()
        mech_id = self.ui.cb_mech.currentData()
        eta = self.ui.de_eta.date().toString("yyyy-MM-dd")
        total = self.recalc_total()

        if self.record.get("wo_id"):
            wid = int(self.record["wo_id"])
            self.db.execute(Q["wo_update"], (client_id, car_id, sched, complaint, diagnosis, status, mech_id, eta, total, status, wid))
            self.db.execute(Q["wos_clear"], (wid,))
            self.db.execute(Q["wop_clear"], (wid,))
        else:
            wid = self.db.execute(Q["wo_insert"], (client_id, car_id, sched, complaint, diagnosis, status, mech_id, eta, total))

        for ln in self.srv_lines:
            self.db.execute(Q["wos_add"], (wid, ln["id"], ln["qty"], ln["unit_price"], ln["line_sum"]))
        for ln in self.part_lines:
            self.db.execute(Q["wop_add"], (wid, ln["id"], ln["qty"], ln["unit_price"], ln["line_sum"]))

    def _save_service(self):
        cat_id = self.ui.cb_p_cat.currentData()
        name = self.ui.le_p_name.text().strip()
        price = float(self.ui.sp_p_price.value())
        if not cat_id or not name:
            raise ValueError("Заполни категорию и название.")
        if self.record.get("id"):
            self.db.execute(Q["service_update"], (int(cat_id), name, price, int(self.record["id"])))
        else:
            self.db.execute(Q["service_insert"], (int(cat_id), name, price))

    def _save_part(self):
        name = self.ui.le_p_name.text().strip()
        price = float(self.ui.sp_p_price.value())
        stock = int(self.ui.sp_p_stock.value())
        if not name:
            raise ValueError("Заполни название.")
        if self.record.get("id"):
            self.db.execute(Q["part_update"], (name, price, stock, int(self.record["id"])))
        else:
            self.db.execute(Q["part_insert"], (name, price, stock))
