
from PyQt6 import QtCore, QtWidgets

class Ui_EditDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("EditDialog")
        Dialog.resize(720, 620)
        self.vbox = QtWidgets.QVBoxLayout(Dialog)
        self.vbox.setContentsMargins(12, 12, 12, 12)
        self.vbox.setSpacing(10)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.setObjectName("stack")

        self.page_wo = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(self.page_wo)

        self.cb_client = QtWidgets.QComboBox(); self.cb_client.setObjectName("cb_client")
        self.cb_car = QtWidgets.QComboBox(); self.cb_car.setObjectName("cb_car")
        self.dt_sched = QtWidgets.QDateTimeEdit(); self.dt_sched.setObjectName("dt_sched"); self.dt_sched.setCalendarPopup(True)
        self.cb_status = QtWidgets.QComboBox(); self.cb_status.setObjectName("cb_status")
        self.cb_status.addItems(["WAITING","IN_WORK","WAIT_PARTS","WAIT_APPROVAL","COMPLETED","ISSUED","CANCELLED"])
        self.cb_mech = QtWidgets.QComboBox(); self.cb_mech.setObjectName("cb_mech")
        self.de_eta = QtWidgets.QDateEdit(); self.de_eta.setObjectName("de_eta"); self.de_eta.setCalendarPopup(True)
        self.le_complaint = QtWidgets.QLineEdit(); self.le_complaint.setObjectName("le_complaint")
        self.le_diagnosis = QtWidgets.QLineEdit(); self.le_diagnosis.setObjectName("le_diagnosis")

        self.cb_cat = QtWidgets.QComboBox(); self.cb_cat.setObjectName("cb_cat")
        self.cb_service = QtWidgets.QComboBox(); self.cb_service.setObjectName("cb_service")
        self.sp_srv_qty = QtWidgets.QSpinBox(); self.sp_srv_qty.setObjectName("sp_srv_qty"); self.sp_srv_qty.setRange(1, 50)
        self.btn_add_srv = QtWidgets.QPushButton("Добавить услугу"); self.btn_add_srv.setObjectName("btn_add_srv")
        self.tw_srv = QtWidgets.QTableWidget(); self.tw_srv.setObjectName("tw_srv")

        self.cb_part = QtWidgets.QComboBox(); self.cb_part.setObjectName("cb_part")
        self.sp_part_qty = QtWidgets.QSpinBox(); self.sp_part_qty.setObjectName("sp_part_qty"); self.sp_part_qty.setRange(1, 50)
        self.btn_add_part = QtWidgets.QPushButton("Добавить запчасть"); self.btn_add_part.setObjectName("btn_add_part")
        self.tw_part = QtWidgets.QTableWidget(); self.tw_part.setObjectName("tw_part")

        self.lbl_total = QtWidgets.QLabel("0.00"); self.lbl_total.setObjectName("lbl_total")
        self.btn_recalc = QtWidgets.QPushButton("Пересчитать"); self.btn_recalc.setObjectName("btn_recalc")

        r=0
        g.addWidget(QtWidgets.QLabel("Клиент"), r,0); g.addWidget(self.cb_client, r,1); g.addWidget(QtWidgets.QLabel("Авто"), r,2); g.addWidget(self.cb_car, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Запись"), r,0); g.addWidget(self.dt_sched, r,1); g.addWidget(QtWidgets.QLabel("Статус"), r,2); g.addWidget(self.cb_status, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Механик"), r,0); g.addWidget(self.cb_mech, r,1); g.addWidget(QtWidgets.QLabel("Готовность"), r,2); g.addWidget(self.de_eta, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Жалоба"), r,0); g.addWidget(self.le_complaint, r,1,1,3); r+=1
        g.addWidget(QtWidgets.QLabel("Диагностика"), r,0); g.addWidget(self.le_diagnosis, r,1,1,3); r+=1

        line = QtWidgets.QFrame(); line.setFrameShape(QtWidgets.QFrame.Shape.HLine); line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        g.addWidget(line, r,0,1,4); r+=1

        g.addWidget(QtWidgets.QLabel("Категория"), r,0); g.addWidget(self.cb_cat, r,1)
        g.addWidget(QtWidgets.QLabel("Услуга"), r,2); g.addWidget(self.cb_service, r,3); r+=1
        h1 = QtWidgets.QHBoxLayout()
        h1.addWidget(QtWidgets.QLabel("Кол-во"))
        h1.addWidget(self.sp_srv_qty)
        h1.addWidget(self.btn_add_srv)
        h1.addStretch()
        g.addLayout(h1, r,0,1,4); r+=1
        g.addWidget(self.tw_srv, r,0,1,4); r+=1

        line2 = QtWidgets.QFrame(); line2.setFrameShape(QtWidgets.QFrame.Shape.HLine); line2.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        g.addWidget(line2, r,0,1,4); r+=1

        g.addWidget(QtWidgets.QLabel("Запчасть"), r,0); g.addWidget(self.cb_part, r,1); r+=1
        h2 = QtWidgets.QHBoxLayout()
        h2.addWidget(QtWidgets.QLabel("Кол-во"))
        h2.addWidget(self.sp_part_qty)
        h2.addWidget(self.btn_add_part)
        h2.addStretch()
        g.addLayout(h2, r,0,1,4); r+=1
        g.addWidget(self.tw_part, r,0,1,4); r+=1

        h3 = QtWidgets.QHBoxLayout()
        h3.addWidget(QtWidgets.QLabel("Итого:"))
        h3.addWidget(self.lbl_total)
        h3.addStretch()
        h3.addWidget(self.btn_recalc)
        g.addLayout(h3, r,0,1,4); r+=1
        g.setRowStretch(r, 1)

        self.stack.addWidget(self.page_wo)

        self.page_price = QtWidgets.QWidget()
        gp = QtWidgets.QGridLayout(self.page_price)
        self.cb_p_cat = QtWidgets.QComboBox(); self.cb_p_cat.setObjectName("cb_p_cat")
        self.le_p_name = QtWidgets.QLineEdit(); self.le_p_name.setObjectName("le_p_name")
        self.sp_p_price = QtWidgets.QDoubleSpinBox(); self.sp_p_price.setObjectName("sp_p_price"); self.sp_p_price.setMaximum(9999999); self.sp_p_price.setDecimals(2)
        self.sp_p_stock = QtWidgets.QSpinBox(); self.sp_p_stock.setObjectName("sp_p_stock"); self.sp_p_stock.setMaximum(999999)

        gp.addWidget(QtWidgets.QLabel("Категория (для услуги)"), 0,0); gp.addWidget(self.cb_p_cat, 0,1)
        gp.addWidget(QtWidgets.QLabel("Название"), 1,0); gp.addWidget(self.le_p_name, 1,1)
        gp.addWidget(QtWidgets.QLabel("Цена"), 2,0); gp.addWidget(self.sp_p_price, 2,1)
        gp.addWidget(QtWidgets.QLabel("Остаток (для запчасти)"), 3,0); gp.addWidget(self.sp_p_stock, 3,1)
        gp.setRowStretch(4,1)

        self.stack.addWidget(self.page_price)

        self.hbox = QtWidgets.QHBoxLayout()
        self.hbox.addStretch()
        self.btn_save = QtWidgets.QPushButton("Сохранить"); self.btn_save.setObjectName("btn_save")
        self.btn_cancel = QtWidgets.QPushButton("Отмена"); self.btn_cancel.setObjectName("btn_cancel")
        self.hbox.addWidget(self.btn_save)
        self.hbox.addWidget(self.btn_cancel)

        self.vbox.addWidget(self.stack)
        self.vbox.addLayout(self.hbox)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
