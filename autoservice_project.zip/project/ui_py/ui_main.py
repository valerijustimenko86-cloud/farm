
from PyQt6 import QtCore, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1180, 760)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.vbox_main = QtWidgets.QVBoxLayout(self.centralwidget)
        self.vbox_main.setContentsMargins(12, 12, 12, 12)
        self.vbox_main.setSpacing(10)

        self.tabs_main = QtWidgets.QTabWidget(parent=self.centralwidget)
        self.tabs_main.setObjectName("tabs_main")

        self.tab_admin = QtWidgets.QWidget()
        self.tab_admin.setObjectName("tab_admin")
        vA = QtWidgets.QVBoxLayout(self.tab_admin)
        vA.setSpacing(10)

        gb = QtWidgets.QGroupBox("Фильтр заказ-нарядов", parent=self.tab_admin)
        grid = QtWidgets.QGridLayout(gb)
        self.cb_a_status = QtWidgets.QComboBox(); self.cb_a_status.setObjectName("cb_a_status")
        self.de_a_from = QtWidgets.QDateEdit(); self.de_a_from.setObjectName("de_a_from"); self.de_a_from.setCalendarPopup(True)
        self.de_a_to = QtWidgets.QDateEdit(); self.de_a_to.setObjectName("de_a_to"); self.de_a_to.setCalendarPopup(True)
        self.btn_a_filter = QtWidgets.QPushButton("Фильтровать"); self.btn_a_filter.setObjectName("btn_a_filter")
        self.btn_a_reset = QtWidgets.QPushButton("Показать все"); self.btn_a_reset.setObjectName("btn_a_reset")

        grid.addWidget(QtWidgets.QLabel("Статус"), 0, 0); grid.addWidget(self.cb_a_status, 0, 1)
        grid.addWidget(QtWidgets.QLabel("С"), 0, 2); grid.addWidget(self.de_a_from, 0, 3)
        grid.addWidget(QtWidgets.QLabel("По"), 0, 4); grid.addWidget(self.de_a_to, 0, 5)
        hb = QtWidgets.QHBoxLayout()
        hb.addStretch()
        hb.addWidget(self.btn_a_filter)
        hb.addWidget(self.btn_a_reset)
        grid.addLayout(hb, 1, 5)

        self.tw_admin = QtWidgets.QTableWidget(); self.tw_admin.setObjectName("tw_admin")

        ha = QtWidgets.QHBoxLayout()
        self.btn_a_add = QtWidgets.QPushButton("Новый заказ-наряд"); self.btn_a_add.setObjectName("btn_a_add")
        self.btn_a_edit = QtWidgets.QPushButton("Редактировать"); self.btn_a_edit.setObjectName("btn_a_edit")
        self.btn_a_details = QtWidgets.QPushButton("Детализация"); self.btn_a_details.setObjectName("btn_a_details")
        self.btn_a_act = QtWidgets.QPushButton("Акт приема-передачи"); self.btn_a_act.setObjectName("btn_a_act")
        ha.addWidget(self.btn_a_add)
        ha.addWidget(self.btn_a_edit)
        ha.addStretch()
        ha.addWidget(self.btn_a_details)
        ha.addWidget(self.btn_a_act)

        vA.addWidget(gb)
        vA.addWidget(self.tw_admin, 3)
        vA.addLayout(ha)

        self.tabs_main.addTab(self.tab_admin, "Администратор")

        self.tab_director = QtWidgets.QWidget()
        self.tab_director.setObjectName("tab_director")
        vD = QtWidgets.QVBoxLayout(self.tab_director)
        vD.setSpacing(10)

        gbA = QtWidgets.QGroupBox("Аналитика", parent=self.tab_director)
        gridA = QtWidgets.QGridLayout(gbA)
        self.de_d_from = QtWidgets.QDateEdit(); self.de_d_from.setObjectName("de_d_from"); self.de_d_from.setCalendarPopup(True)
        self.de_d_to = QtWidgets.QDateEdit(); self.de_d_to.setObjectName("de_d_to"); self.de_d_to.setCalendarPopup(True)
        self.btn_d_avg = QtWidgets.QPushButton("Средний чек (период)"); self.btn_d_avg.setObjectName("btn_d_avg")
        self.lbl_d_avg = QtWidgets.QLabel("0.00"); self.lbl_d_avg.setObjectName("lbl_d_avg")
        gridA.addWidget(QtWidgets.QLabel("С"), 0, 0); gridA.addWidget(self.de_d_from, 0, 1)
        gridA.addWidget(QtWidgets.QLabel("По"), 0, 2); gridA.addWidget(self.de_d_to, 0, 3)
        gridA.addWidget(self.btn_d_avg, 1, 0, 1, 2)
        gridA.addWidget(self.lbl_d_avg, 1, 2, 1, 2)

        gbP = QtWidgets.QGroupBox("Прайс-лист", parent=self.tab_director)
        vP = QtWidgets.QVBoxLayout(gbP)
        self.tabs_price = QtWidgets.QTabWidget()
        self.tab_services = QtWidgets.QWidget(); self.tab_services.setObjectName("tab_services")
        vs = QtWidgets.QVBoxLayout(self.tab_services); vs.setSpacing(8)
        self.tw_services = QtWidgets.QTableWidget(); self.tw_services.setObjectName("tw_services")
        hs = QtWidgets.QHBoxLayout()
        self.btn_srv_add = QtWidgets.QPushButton("Добавить услугу"); self.btn_srv_add.setObjectName("btn_srv_add")
        self.btn_srv_edit = QtWidgets.QPushButton("Изменить"); self.btn_srv_edit.setObjectName("btn_srv_edit")
        self.btn_srv_del = QtWidgets.QPushButton("Удалить"); self.btn_srv_del.setObjectName("btn_srv_del")
        hs.addWidget(self.btn_srv_add); hs.addWidget(self.btn_srv_edit); hs.addWidget(self.btn_srv_del); hs.addStretch()
        vs.addWidget(self.tw_services, 2); vs.addLayout(hs)

        self.tab_parts = QtWidgets.QWidget(); self.tab_parts.setObjectName("tab_parts")
        vp = QtWidgets.QVBoxLayout(self.tab_parts); vp.setSpacing(8)
        self.tw_parts = QtWidgets.QTableWidget(); self.tw_parts.setObjectName("tw_parts")
        hp = QtWidgets.QHBoxLayout()
        self.btn_part_add = QtWidgets.QPushButton("Добавить запчасть"); self.btn_part_add.setObjectName("btn_part_add")
        self.btn_part_edit = QtWidgets.QPushButton("Изменить"); self.btn_part_edit.setObjectName("btn_part_edit")
        self.btn_part_del = QtWidgets.QPushButton("Удалить"); self.btn_part_del.setObjectName("btn_part_del")
        hp.addWidget(self.btn_part_add); hp.addWidget(self.btn_part_edit); hp.addWidget(self.btn_part_del); hp.addStretch()
        vp.addWidget(self.tw_parts, 2); vp.addLayout(hp)

        self.tabs_price.addTab(self.tab_services, "Услуги")
        self.tabs_price.addTab(self.tab_parts, "Запчасти")
        vP.addWidget(self.tabs_price)

        vD.addWidget(gbA)
        vD.addWidget(gbP, 3)

        self.tabs_main.addTab(self.tab_director, "Директор")

        self.tab_client = QtWidgets.QWidget()
        self.tab_client.setObjectName("tab_client")
        vC = QtWidgets.QVBoxLayout(self.tab_client)
        vC.setSpacing(10)

        gbC = QtWidgets.QGroupBox("Запись на обслуживание", parent=self.tab_client)
        gridC = QtWidgets.QGridLayout(gbC)
        self.dt_c_sched = QtWidgets.QDateTimeEdit(); self.dt_c_sched.setObjectName("dt_c_sched"); self.dt_c_sched.setCalendarPopup(True)
        self.cb_c_category = QtWidgets.QComboBox(); self.cb_c_category.setObjectName("cb_c_category")
        self.cb_c_service = QtWidgets.QComboBox(); self.cb_c_service.setObjectName("cb_c_service")
        self.le_c_complaint = QtWidgets.QLineEdit(); self.le_c_complaint.setObjectName("le_c_complaint")
        self.btn_c_book = QtWidgets.QPushButton("Записаться"); self.btn_c_book.setObjectName("btn_c_book")
        gridC.addWidget(QtWidgets.QLabel("Дата/время"), 0, 0); gridC.addWidget(self.dt_c_sched, 0, 1)
        gridC.addWidget(QtWidgets.QLabel("Категория"), 0, 2); gridC.addWidget(self.cb_c_category, 0, 3)
        gridC.addWidget(QtWidgets.QLabel("Тип работ"), 1, 0); gridC.addWidget(self.cb_c_service, 1, 1, 1, 3)
        gridC.addWidget(QtWidgets.QLabel("Комментарий"), 2, 0); gridC.addWidget(self.le_c_complaint, 2, 1, 1, 3)
        gridC.addWidget(self.btn_c_book, 3, 3)

        self.tw_client_orders = QtWidgets.QTableWidget(); self.tw_client_orders.setObjectName("tw_client_orders")

        vC.addWidget(gbC)
        vC.addWidget(QtWidgets.QLabel("Мои заказ-наряды"))
        vC.addWidget(self.tw_client_orders, 3)

        self.tabs_main.addTab(self.tab_client, "Клиент")

        self.vbox_main.addWidget(self.tabs_main)
        MainWindow.setCentralWidget(self.centralwidget)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
