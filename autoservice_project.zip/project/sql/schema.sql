
DROP DATABASE IF EXISTS autoservice;
CREATE DATABASE autoservice CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE autoservice;

CREATE TABLE clients(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_clients_email(email)
) ENGINE=InnoDB;

CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  role ENUM('director','admin','client') NOT NULL,
  client_id INT NULL,
  UNIQUE KEY uq_users_username(username),
  CONSTRAINT fk_users_client FOREIGN KEY(client_id) REFERENCES clients(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cars(
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  brand VARCHAR(60) NOT NULL,
  model VARCHAR(60) NOT NULL,
  year INT NOT NULL,
  vin VARCHAR(32) NOT NULL,
  plate VARCHAR(20) NOT NULL,
  mileage_km INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_cars_vin(vin),
  INDEX ix_cars_client(client_id),
  CONSTRAINT fk_cars_client FOREIGN KEY(client_id) REFERENCES clients(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE mechanics(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE service_categories(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  UNIQUE KEY uq_service_categories_name(name)
) ENGINE=InnoDB;

CREATE TABLE services(
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  INDEX ix_services_cat(category_id),
  CONSTRAINT fk_services_cat FOREIGN KEY(category_id) REFERENCES service_categories(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE parts(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  stock_qty INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE work_orders(
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  car_id INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  scheduled_at DATETIME NULL,
  complaint VARCHAR(255) NULL,
  diagnosis VARCHAR(255) NULL,
  status ENUM('WAITING','IN_WORK','WAIT_PARTS','WAIT_APPROVAL','COMPLETED','ISSUED','CANCELLED') NOT NULL DEFAULT 'WAITING',
  mechanic_id INT NULL,
  eta_date DATE NULL,
  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  completed_at DATETIME NULL,
  CONSTRAINT fk_wo_client FOREIGN KEY(client_id) REFERENCES clients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_wo_car FOREIGN KEY(car_id) REFERENCES cars(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_wo_mech FOREIGN KEY(mechanic_id) REFERENCES mechanics(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX ix_wo_status(status),
  INDEX ix_wo_created(created_at),
  INDEX ix_wo_scheduled(scheduled_at)
) ENGINE=InnoDB;

CREATE TABLE wo_services(
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  service_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  line_sum DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_wos_wo FOREIGN KEY(work_order_id) REFERENCES work_orders(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_wos_srv FOREIGN KEY(service_id) REFERENCES services(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_wos_wo(work_order_id)
) ENGINE=InnoDB;

CREATE TABLE wo_parts(
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  part_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  line_sum DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_wop_wo FOREIGN KEY(work_order_id) REFERENCES work_orders(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_wop_part FOREIGN KEY(part_id) REFERENCES parts(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_wop_wo(work_order_id)
) ENGINE=InnoDB;

CREATE TABLE payments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  method ENUM('CASH','CARD') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  pay_status ENUM('PAID','VOID') NOT NULL DEFAULT 'PAID',
  UNIQUE KEY uq_pay_wo(work_order_id),
  CONSTRAINT fk_pay_wo FOREIGN KEY(work_order_id) REFERENCES work_orders(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE OR REPLACE VIEW v_work_orders AS
SELECT
  w.id AS wo_id,
  w.created_at,
  w.scheduled_at,
  w.status,
  w.eta_date,
  w.total_amount,
  c.fio AS client_fio,
  c.phone AS client_phone,
  c.email AS client_email,
  ca.brand,
  ca.model,
  ca.plate,
  ca.vin,
  m.fio AS mechanic_fio
FROM work_orders w
JOIN clients c ON c.id=w.client_id
JOIN cars ca ON ca.id=w.car_id
LEFT JOIN mechanics m ON m.id=w.mechanic_id;

DELIMITER $$

CREATE PROCEDURE sp_avg_check_period(IN p_from DATE, IN p_to DATE)
BEGIN
  SELECT
    CASE WHEN COUNT(*)=0 THEN 0.00 ELSE ROUND(SUM(total_amount)/COUNT(*), 2) END AS avg_check
  FROM work_orders
  WHERE status IN ('COMPLETED','ISSUED')
    AND DATE(COALESCE(completed_at, created_at)) BETWEEN p_from AND p_to;
END $$

DELIMITER ;

INSERT INTO clients(fio,phone,email) VALUES
('Иванов Иван', '+79990000001', 'ivan@mail.ru'),
('Петров Петр', '+79990000002', 'petr@mail.ru'),
('Сидорова Анна', '+79990000003', 'anna@mail.ru');

INSERT INTO users(username, pass_hash, role, client_id) VALUES
('director', '123', 'director', NULL),
('admin', '123', 'admin', NULL),
('client1', '123', 'client', 1),
('client2', '123', 'client', 2);

INSERT INTO cars(client_id,brand,model,year,vin,plate,mileage_km) VALUES
(1,'Toyota','Camry',2018,'JTNB11HKXJ3000001','A111AA77',120000),
(2,'Kia','Rio',2016,'Z94C241BBGR000002','B222BB77',98000),
(3,'Volkswagen','Polo',2019,'XW8ZZZ61ZKG000003','C333CC77',75000);

INSERT INTO mechanics(fio,phone,is_active) VALUES
('Смирнов Сергей', '+79991110001', 1),
('Кузнецов Алексей', '+79991110002', 1),
('Волкова Мария', '+79991110003', 1);

INSERT INTO service_categories(name) VALUES
('ТО'),('Диагностика'),('Шиномонтаж'),('Кузовной ремонт');

INSERT INTO services(category_id,name,price,is_active) VALUES
(1,'Замена масла', 2500.00, 1),
(2,'Компьютерная диагностика', 1800.00, 1),
(3,'Балансировка колес (комплект)', 2200.00, 1),
(4,'Покраска элемента', 6000.00, 1);

INSERT INTO parts(name,price,stock_qty,is_active) VALUES
('Масляный фильтр', 450.00, 15, 1),
('Масло 5W-30 (1л)', 900.00, 40, 1),
('Тормозные колодки', 3200.00, 8, 1);

INSERT INTO work_orders(client_id,car_id,scheduled_at,complaint,diagnosis,status,mechanic_id,eta_date,total_amount,completed_at) VALUES
(1,1, NOW()+INTERVAL 1 DAY, 'Шум при торможении', 'Износ колодок', 'IN_WORK', 1, CURDATE()+INTERVAL 2 DAY, 3200.00, NULL),
(2,2, NOW()+INTERVAL 2 DAY, 'ТО', 'Плановое ТО', 'WAITING', 2, CURDATE()+INTERVAL 3 DAY, 0.00, NULL),
(3,3, NOW()-INTERVAL 20 DAY, 'Диагностика', 'Ошибки датчика', 'COMPLETED', 3, CURDATE()-INTERVAL 18 DAY, 1800.00, NOW()-INTERVAL 18 DAY);

INSERT INTO wo_services(work_order_id,service_id,qty,unit_price,line_sum) VALUES
(3,2,1,1800.00,1800.00);

INSERT INTO payments(work_order_id,method,amount,pay_status) VALUES
(3,'CARD',1800.00,'PAID');
