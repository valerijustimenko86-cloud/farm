
Q = {
  "auth": "SELECT id, role, client_id FROM users WHERE username=%s AND pass_hash=%s",

  "wo_all": "SELECT * FROM v_work_orders ORDER BY created_at DESC",
  "wo_filter": """
    SELECT * FROM v_work_orders
    WHERE (%s='ALL' OR status=%s)
      AND DATE(created_at) BETWEEN %s AND %s
    ORDER BY created_at DESC
  """,
  "wo_by_client": """
    SELECT * FROM v_work_orders
    WHERE client_email=%s
    ORDER BY created_at DESC
  """,

  "clients_list": "SELECT id, fio FROM clients ORDER BY fio",
  "cars_list": """
    SELECT ca.id, CONCAT(c.fio,' | ',ca.brand,' ',ca.model,' | ',ca.plate) AS title, ca.client_id
    FROM cars ca JOIN clients c ON c.id=ca.client_id
    ORDER BY c.fio, ca.brand, ca.model
  """,
  "mech_list": "SELECT id, fio FROM mechanics WHERE is_active=1 ORDER BY fio",
  "cat_list": "SELECT id, name FROM service_categories ORDER BY name",
  "services_by_cat": "SELECT id, name, price FROM services WHERE is_active=1 AND category_id=%s ORDER BY name",
  "services_all": """SELECT s.id, c.name AS category, s.name, s.price
                    FROM services s JOIN service_categories c ON c.id=s.category_id
                    WHERE s.is_active=1 ORDER BY c.name, s.name""",
  "parts_all": "SELECT id, name, price, stock_qty FROM parts WHERE is_active=1 ORDER BY name",

  "client_insert": "INSERT INTO clients(fio,phone,email) VALUES(%s,%s,%s)",
  "car_insert": """
    INSERT INTO cars(client_id,brand,model,year,vin,plate,mileage_km)
    VALUES(%s,%s,%s,%s,%s,%s,%s)
  """,

  "wo_insert": """
    INSERT INTO work_orders(client_id,car_id,scheduled_at,complaint,diagnosis,status,mechanic_id,eta_date,total_amount)
    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)
  """,
  "wo_update": """
    UPDATE work_orders
    SET client_id=%s, car_id=%s, scheduled_at=%s, complaint=%s, diagnosis=%s, status=%s,
        mechanic_id=%s, eta_date=%s, total_amount=%s,
        completed_at=CASE WHEN %s IN ('COMPLETED','ISSUED') THEN COALESCE(completed_at,NOW()) ELSE completed_at END
    WHERE id=%s
  """,
  "wo_set_status": "UPDATE work_orders SET status=%s WHERE id=%s",

  "wos_clear": "DELETE FROM wo_services WHERE work_order_id=%s",
  "wop_clear": "DELETE FROM wo_parts WHERE work_order_id=%s",
  "wos_add": """
    INSERT INTO wo_services(work_order_id,service_id,qty,unit_price,line_sum)
    VALUES(%s,%s,%s,%s,%s)
  """,
  "wop_add": """
    INSERT INTO wo_parts(work_order_id,part_id,qty,unit_price,line_sum)
    VALUES(%s,%s,%s,%s,%s)
  """,

  "wo_lines_services": """
    SELECT ws.qty, ws.unit_price, ws.line_sum, s.name
    FROM wo_services ws JOIN services s ON s.id=ws.service_id
    WHERE ws.work_order_id=%s
    ORDER BY ws.id
  """,
  "wo_lines_parts": """
    SELECT wp.qty, wp.unit_price, wp.line_sum, p.name
    FROM wo_parts wp JOIN parts p ON p.id=wp.part_id
    WHERE wp.work_order_id=%s
    ORDER BY wp.id
  """,

  "service_price": "SELECT price FROM services WHERE id=%s",
  "part_price": "SELECT price FROM parts WHERE id=%s",

  "service_insert": "INSERT INTO services(category_id,name,price,is_active) VALUES(%s,%s,%s,1)",
  "service_update": "UPDATE services SET category_id=%s, name=%s, price=%s WHERE id=%s",
  "service_delete": "UPDATE services SET is_active=0 WHERE id=%s",

  "part_insert": "INSERT INTO parts(name,price,stock_qty,is_active) VALUES(%s,%s,%s,1)",
  "part_update": "UPDATE parts SET name=%s, price=%s, stock_qty=%s WHERE id=%s",
  "part_delete": "UPDATE parts SET is_active=0 WHERE id=%s",

  "avg_check_call": "CALL sp_avg_check_period(%s,%s)",

  "history_by_client": """
    SELECT wo_id, created_at, status, total_amount, brand, model, plate
    FROM v_work_orders
    WHERE client_email=%s
    ORDER BY created_at DESC
  """
}
