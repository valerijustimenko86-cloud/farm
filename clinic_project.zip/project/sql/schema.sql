
DROP DATABASE IF EXISTS clinic;
CREATE DATABASE clinic CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clinic;

CREATE TABLE insurers(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_insurers_name(name)
) ENGINE=InnoDB;

CREATE TABLE patients(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  birth_date DATE NOT NULL,
  gender ENUM('M','F') NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  passport_series VARCHAR(10) NOT NULL,
  passport_number VARCHAR(20) NOT NULL,
  card_number VARCHAR(30) NOT NULL,
  UNIQUE KEY uq_patients_email(email),
  UNIQUE KEY uq_patients_card(card_number)
) ENGINE=InnoDB;

CREATE TABLE policies(
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  policy_type ENUM('OMC','DMC') NOT NULL,
  policy_number VARCHAR(40) NOT NULL,
  insurer_id INT NOT NULL,
  UNIQUE KEY uq_policies_number(policy_number),
  CONSTRAINT fk_policies_patient FOREIGN KEY(patient_id) REFERENCES patients(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_policies_insurer FOREIGN KEY(insurer_id) REFERENCES insurers(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  role ENUM('chief','registrar','patient') NOT NULL,
  patient_id INT NULL,
  UNIQUE KEY uq_users_username(username),
  CONSTRAINT fk_users_patient FOREIGN KEY(patient_id) REFERENCES patients(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE specializations(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_specs_name(name)
) ENGINE=InnoDB;

CREATE TABLE cabinets(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(40) NOT NULL,
  UNIQUE KEY uq_cabinets_name(name)
) ENGINE=InnoDB;

CREATE TABLE doctors(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  spec_id INT NOT NULL,
  cabinet_id INT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT fk_doctors_spec FOREIGN KEY(spec_id) REFERENCES specializations(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_doctors_cab FOREIGN KEY(cabinet_id) REFERENCES cabinets(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_doctors_spec(spec_id)
) ENGINE=InnoDB;

CREATE TABLE doctor_slots(
  id INT AUTO_INCREMENT PRIMARY KEY,
  doctor_id INT NOT NULL,
  start_dt DATETIME NOT NULL,
  is_booked TINYINT(1) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_slot_doc_dt(doctor_id,start_dt),
  CONSTRAINT fk_slots_doctor FOREIGN KEY(doctor_id) REFERENCES doctors(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX ix_slots_dt(start_dt),
  INDEX ix_slots_booked(is_booked)
) ENGINE=InnoDB;

CREATE TABLE visit_prices(
  visit_kind ENUM('PRIMARY','REPEAT','PREVENT') PRIMARY KEY,
  price_cash DECIMAL(10,2) NOT NULL,
  price_omc DECIMAL(10,2) NOT NULL,
  price_dmc DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE appointments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  slot_id INT NOT NULL,
  visit_kind ENUM('PRIMARY','REPEAT','PREVENT') NOT NULL,
  status ENUM('SCHEDULED','IN_PROGRESS','COMPLETED','NO_SHOW','CANCELLED') NOT NULL DEFAULT 'SCHEDULED',
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  CONSTRAINT fk_appt_patient FOREIGN KEY(patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_doctor FOREIGN KEY(doctor_id) REFERENCES doctors(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_slot FOREIGN KEY(slot_id) REFERENCES doctor_slots(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  UNIQUE KEY uq_appt_slot(slot_id),
  INDEX ix_appt_status(status),
  INDEX ix_appt_created(created_at)
) ENGINE=InnoDB;

CREATE TABLE payments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  method ENUM('CASH','CARD','INSURANCE') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  pay_status ENUM('PAID','VOID') NOT NULL DEFAULT 'PAID',
  UNIQUE KEY uq_pay_appt(appointment_id),
  CONSTRAINT fk_pay_appt FOREIGN KEY(appointment_id) REFERENCES appointments(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE referrals(
  id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  kind ENUM('LAB','DIAG') NOT NULL,
  description VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ref_appt FOREIGN KEY(appointment_id) REFERENCES appointments(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE medical_records(
  id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  diagnosis VARCHAR(255) NOT NULL,
  prescription VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_mr_appt FOREIGN KEY(appointment_id) REFERENCES appointments(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  UNIQUE KEY uq_mr_appt(appointment_id)
) ENGINE=InnoDB;

CREATE OR REPLACE VIEW v_appointments AS
SELECT
  a.id AS appt_id,
  a.created_at,
  a.status,
  a.visit_kind,
  a.price,
  p.id AS patient_id,
  p.fio AS patient_fio,
  p.phone AS patient_phone,
  p.email AS patient_email,
  p.card_number,
  d.id AS doctor_id,
  d.fio AS doctor_fio,
  s.name AS spec_name,
  c.name AS cabinet_name,
  sl.start_dt,
  pol.policy_type,
  pol.policy_number,
  ins.name AS insurer_name
FROM appointments a
JOIN patients p ON p.id=a.patient_id
JOIN doctors d ON d.id=a.doctor_id
JOIN specializations s ON s.id=d.spec_id
JOIN cabinets c ON c.id=d.cabinet_id
JOIN doctor_slots sl ON sl.id=a.slot_id
LEFT JOIN policies pol ON pol.patient_id=p.id
LEFT JOIN insurers ins ON ins.id=pol.insurer_id;

DELIMITER $$

CREATE PROCEDURE sp_attendance_pct(IN p_from DATE, IN p_to DATE)
BEGIN
  SELECT
    CASE
      WHEN SUM(CASE WHEN status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','NO_SHOW') THEN 1 ELSE 0 END)=0 THEN 0.00
      ELSE ROUND(
        100 * SUM(CASE WHEN status='COMPLETED' THEN 1 ELSE 0 END) /
        SUM(CASE WHEN status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','NO_SHOW') THEN 1 ELSE 0 END),
      2)
    END AS attendance_pct
  FROM appointments a
  JOIN doctor_slots sl ON sl.id=a.slot_id
  WHERE DATE(sl.start_dt) BETWEEN p_from AND p_to;
END $$

CREATE FUNCTION fn_avg_visit_cost(p_from DATE, p_to DATE)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
  DECLARE v_avg DECIMAL(10,2);
  SELECT
    CASE WHEN COUNT(*)=0 THEN 0.00 ELSE ROUND(AVG(price),2) END
  INTO v_avg
  FROM appointments a
  JOIN doctor_slots sl ON sl.id=a.slot_id
  WHERE a.status='COMPLETED' AND DATE(sl.start_dt) BETWEEN p_from AND p_to;
  RETURN v_avg;
END $$

DELIMITER ;

INSERT INTO insurers(name) VALUES
('Росстрах'),('АльфаСтрахование'),('Ингосстрах');

INSERT INTO patients(fio,birth_date,gender,address,phone,email,passport_series,passport_number,card_number) VALUES
('Иванов Иван', '1995-04-10','M','Москва, ул. 1','+79990000001','ivan@mail.ru','4501','111111','MC-000001'),
('Петрова Анна','1989-09-22','F','Москва, ул. 2','+79990000002','anna@mail.ru','4502','222222','MC-000002'),
('Сидоров Петр','2001-01-15','M','Москва, ул. 3','+79990000003','petr@mail.ru','4503','333333','MC-000003');

INSERT INTO policies(patient_id,policy_type,policy_number,insurer_id) VALUES
(1,'OMC','OMC-111',1),
(2,'DMC','DMC-222',2),
(3,'OMC','OMC-333',3);

INSERT INTO users(username,pass_hash,role,patient_id) VALUES
('chief','123','chief',NULL),
('registrar','123','registrar',NULL),
('patient1','123','patient',1),
('patient2','123','patient',2);

INSERT INTO specializations(name) VALUES
('Терапевт'),('Кардиолог'),('Хирург'),('Эндокринолог');

INSERT INTO cabinets(name) VALUES
('101'),('102'),('201'),('202');

INSERT INTO doctors(fio,spec_id,cabinet_id,is_active) VALUES
('Др. Смирнов',1,1,1),
('Др. Кузнецова',2,2,1),
('Др. Волков',3,3,1),
('Др. Иванова',4,4,1);

INSERT INTO visit_prices(visit_kind,price_cash,price_omc,price_dmc) VALUES
('PRIMARY',2500.00,0.00,1200.00),
('REPEAT',1800.00,0.00,900.00),
('PREVENT',1500.00,0.00,700.00);

INSERT INTO doctor_slots(doctor_id,start_dt,is_booked) VALUES
(1, NOW() + INTERVAL 1 DAY, 0),
(1, NOW() + INTERVAL 1 DAY + INTERVAL 30 MINUTE, 0),
(2, NOW() + INTERVAL 1 DAY, 0),
(2, NOW() + INTERVAL 2 DAY, 0),
(3, NOW() + INTERVAL 1 DAY, 0),
(4, NOW() + INTERVAL 3 DAY, 0);

INSERT INTO appointments(patient_id,doctor_id,slot_id,visit_kind,status,price) VALUES
(1,1,1,'PRIMARY','SCHEDULED',0.00),
(2,2,3,'REPEAT','COMPLETED',900.00),
(3,3,5,'PRIMARY','NO_SHOW',0.00);

UPDATE doctor_slots SET is_booked=1 WHERE id IN (1,3,5);

INSERT INTO medical_records(appointment_id,diagnosis,prescription) VALUES
(2,'ОРВИ','Покой, обильное питье');

INSERT INTO payments(appointment_id,method,amount,pay_status) VALUES
(2,'CARD',900.00,'PAID');

INSERT INTO referrals(appointment_id,kind,description) VALUES
(2,'LAB','ОАК, ОАМ'),
(2,'DIAG','ЭКГ');
