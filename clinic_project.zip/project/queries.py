
Q = {
  "auth": "SELECT id, role, patient_id FROM users WHERE username=%s AND pass_hash=%s",

  "patients_list": "SELECT id, fio FROM patients ORDER BY fio",
  "patient_by_id": "SELECT * FROM patients WHERE id=%s",
  "policy_by_patient": """
    SELECT p.policy_type, p.policy_number, i.name AS insurer_name
    FROM policies p JOIN insurers i ON i.id=p.insurer_id
    WHERE p.patient_id=%s
  """,
  "insurers_list": "SELECT id, name FROM insurers ORDER BY name",

  "patient_insert": """
    INSERT INTO patients(fio,birth_date,gender,address,phone,email,passport_series,passport_number,card_number)
    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)
  """,
  "policy_insert": "INSERT INTO policies(patient_id,policy_type,policy_number,insurer_id) VALUES(%s,%s,%s,%s)",

  "spec_list": "SELECT id, name FROM specializations ORDER BY name",
  "doctors_by_spec": """
    SELECT d.id, CONCAT(d.fio,' | каб. ',c.name) AS title
    FROM doctors d JOIN cabinets c ON c.id=d.cabinet_id
    WHERE d.is_active=1 AND d.spec_id=%s
    ORDER BY d.fio
  """,

  "slots_free_by_doctor_period": """
    SELECT id, start_dt FROM doctor_slots
    WHERE doctor_id=%s AND is_booked=0 AND start_dt BETWEEN %s AND %s
    ORDER BY start_dt
  """,
  "slots_free_by_spec_period": """
    SELECT sl.id AS slot_id, sl.start_dt, d.fio AS doctor_fio, c.name AS cabinet_name
    FROM doctor_slots sl
    JOIN doctors d ON d.id=sl.doctor_id
    JOIN cabinets c ON c.id=d.cabinet_id
    WHERE d.is_active=1 AND d.spec_id=%s AND sl.is_booked=0 AND sl.start_dt BETWEEN %s AND %s
    ORDER BY sl.start_dt
  """,

  "visit_price": "SELECT visit_kind, price_cash, price_omc, price_dmc FROM visit_prices WHERE visit_kind=%s",

  "appt_all": "SELECT * FROM v_appointments ORDER BY start_dt DESC",
  "appt_filter": """
    SELECT * FROM v_appointments
    WHERE (%s='ALL' OR status=%s)
      AND (%s=0 OR doctor_id=%s)
      AND DATE(start_dt) BETWEEN %s AND %s
    ORDER BY start_dt DESC
  """,
  "appt_by_patient": """
    SELECT * FROM v_appointments
    WHERE patient_id=%s
    ORDER BY start_dt DESC
  """,

  "appt_insert": """
    INSERT INTO appointments(patient_id,doctor_id,slot_id,visit_kind,status,price)
    VALUES(%s,%s,%s,%s,%s,%s)
  """,
  "appt_update": """
    UPDATE appointments
    SET doctor_id=%s, slot_id=%s, visit_kind=%s, status=%s, price=%s, updated_at=NOW()
    WHERE id=%s
  """,
  "appt_cancel": "UPDATE appointments SET status='CANCELLED', updated_at=NOW() WHERE id=%s",

  "slot_book": "UPDATE doctor_slots SET is_booked=%s WHERE id=%s",

  "pay_upsert": """
    INSERT INTO payments(appointment_id,method,amount,pay_status)
    VALUES(%s,%s,%s,'PAID')
    ON DUPLICATE KEY UPDATE method=VALUES(method), amount=VALUES(amount), pay_status='PAID', paid_at=NOW()
  """,

  "ref_add": "INSERT INTO referrals(appointment_id,kind,description) VALUES(%s,%s,%s)",
  "refs_by_appt": "SELECT kind, description, created_at FROM referrals WHERE appointment_id=%s ORDER BY id",

  "mr_upsert": """
    INSERT INTO medical_records(appointment_id,diagnosis,prescription)
    VALUES(%s,%s,%s)
    ON DUPLICATE KEY UPDATE diagnosis=VALUES(diagnosis), prescription=VALUES(prescription), created_at=NOW()
  """,
  "mr_by_patient": """
    SELECT v.appt_id, v.start_dt, v.doctor_fio, v.spec_name, v.status, mr.diagnosis, mr.prescription
    FROM v_appointments v
    LEFT JOIN medical_records mr ON mr.appointment_id=v.appt_id
    WHERE v.patient_id=%s
    ORDER BY v.start_dt DESC
  """
}
