
from PyQt6.QtCore import QDate, QDateTime
from PyQt6.QtWidgets import QDialog, QMessageBox, QAbstractItemView
from ui_py.ui_edit_dialog import Ui_EditDialog
from queries import Q

class EditDialog(QDialog):
    MODE_PATIENT = "patient"
    MODE_APPT = "appt"

    def __init__(self, mode, db, record=None, patient_id=None, parent=None):
        super().__init__(parent)
        self.ui = Ui_EditDialog()
        self.ui.setupUi(self)
        self.db = db
        self.mode = mode
        self.record = record or {}
        self.patient_id = patient_id
        self.ui.btn_cancel.clicked.connect(self.reject)
        self.ui.btn_save.clicked.connect(self.save)

        self.ui.btn_ref_add.clicked.connect(self.add_ref)
        self.ui.cb_spec.currentIndexChanged.connect(self.reload_doctors)
        self.ui.cb_doctor.currentIndexChanged.connect(self.reload_slots)
        self.ui.cb_patient.currentIndexChanged.connect(self.reload_patient_policy)
        self.ui.cb_kind.currentIndexChanged.connect(self.recalc_price)
        self.ui.cb_pay_method.currentIndexChanged.connect(self.recalc_price)

        self._init_mode()

    def _init_mode(self):
        if self.mode == self.MODE_PATIENT:
            self.ui.stack.setCurrentIndex(0)
            self.ui.de_birth.setDate(QDate.currentDate().addYears(-25))
            self._load_insurers()
            self.ui.le_card.setText(self._gen_card_number())
        else:
            self.ui.stack.setCurrentIndex(1)
            self._load_appt_lists()
            now = QDateTime.currentDateTime()
            self.ui.dt_from.setDateTime(now)
            self.ui.dt_to.setDateTime(now.addDays(7))
            self.reload_doctors()
            self.reload_slots()
            if self.record.get("appt_id"):
                self._fill_appt()

    def _gen_card_number(self):
        row = self.db.fetchone("SELECT MAX(id) AS mx FROM patients", ())
        n = int(row["mx"] or 0) + 1
        return f"MC-{n:06d}"

    def _load_insurers(self):
        self.ins = self.db.fetchall(Q["insurers_list"])
        self.ui.cb_insurer.clear()
        for x in self.ins:
            self.ui.cb_insurer.addItem(x["name"], x["id"])

    def _load_appt_lists(self):
        self.patients = self.db.fetchall(Q["patients_list"])
        self.specs = self.db.fetchall(Q["spec_list"])

        self.ui.cb_patient.clear()
        for p in self.patients:
            self.ui.cb_patient.addItem(p["fio"], p["id"])

        self.ui.cb_spec.clear()
        for s in self.specs:
            self.ui.cb_spec.addItem(s["name"], s["id"])

        if self.patient_id:
            i = self.ui.cb_patient.findData(self.patient_id)
            if i >= 0:
                self.ui.cb_patient.setCurrentIndex(i)
                self.ui.cb_patient.setEnabled(False)
        self.reload_patient_policy()

    def reload_patient_policy(self):
        pid = self.ui.cb_patient.currentData()
        if not pid:
            self.ui.lbl_policy.setText("-")
            return
        pol = self.db.fetchone(Q["policy_by_patient"], (pid,))
        if not pol:
            self.ui.lbl_policy.setText("нет")
        else:
            self.ui.lbl_policy.setText(f'{pol["policy_type"]} | {pol["policy_number"]} | {pol["insurer_name"]}')
        self.recalc_price()

    def reload_doctors(self):
        spec_id = self.ui.cb_spec.currentData()
        rows = self.db.fetchall(Q["doctors_by_spec"], (spec_id,))
        self.ui.cb_doctor.clear()
        for r in rows:
            self.ui.cb_doctor.addItem(r["title"], r["id"])
        self.reload_slots()

    def reload_slots(self):
        did = self.ui.cb_doctor.currentData()
        if not did:
            self.ui.cb_slot.clear()
            return
        dt_from = self.ui.dt_from.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        dt_to = self.ui.dt_to.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        rows = self.db.fetchall(Q["slots_free_by_doctor_period"], (did, dt_from, dt_to))
        self.ui.cb_slot.clear()
        for r in rows:
            self.ui.cb_slot.addItem(str(r["start_dt"]), r["id"])

    def price_for(self, visit_kind, policy_type):
        row = self.db.fetchone(Q["visit_price"], (visit_kind,))
        if not row:
            return 0.0
        if policy_type == "OMC":
            return float(row["price_omc"])
        if policy_type == "DMC":
            return float(row["price_dmc"])
        return float(row["price_cash"])

    def recalc_price(self):
        visit_kind = self.ui.cb_kind.currentText()
        pid = self.ui.cb_patient.currentData()
        pol = self.db.fetchone(Q["policy_by_patient"], (pid,)) if pid else None
        policy_type = pol["policy_type"] if pol else None
        base = self.price_for(visit_kind, policy_type)
        method = self.ui.cb_pay_method.currentText()
        if method == "INSURANCE":
            price = 0.0 if policy_type == "OMC" else base
        else:
            price = base if policy_type != "OMC" else 0.0
        self.ui.lbl_price.setText(f"{price:.2f}")
        return price

    def _fill_appt(self):
        a = self.db.fetchone("SELECT * FROM v_appointments WHERE appt_id=%s", (self.record["appt_id"],))
        if not a:
            return
        i = self.ui.cb_patient.findData(a["patient_id"])
        if i >= 0: self.ui.cb_patient.setCurrentIndex(i)
        i = self.ui.cb_spec.findText(a["spec_name"])
        if i >= 0: self.ui.cb_spec.setCurrentIndex(i)
        self.reload_doctors()
        i = self.ui.cb_doctor.findData(a["doctor_id"])
        if i >= 0: self.ui.cb_doctor.setCurrentIndex(i)
        self.reload_slots()
        self.ui.cb_kind.setCurrentText(a["visit_kind"])
        self.ui.cb_status.setCurrentText(a["status"])
        self.recalc_price()

    def add_ref(self):
        if not self.record.get("appt_id"):
            QMessageBox.warning(self, "Направление", "Сначала сохрани запись.")
            return
        kind = self.ui.cb_ref_kind.currentText()
        desc = self.ui.le_ref_desc.text().strip()
        if not desc:
            return
        try:
            self.db.execute(Q["ref_add"], (int(self.record["appt_id"]), kind, desc))
            self.ui.le_ref_desc.clear()
            QMessageBox.information(self, "Направление", "Добавлено.")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def save(self):
        try:
            if self.mode == self.MODE_PATIENT:
                self._save_patient()
            else:
                self._save_appt()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _save_patient(self):
        fio = self.ui.le_fio.text().strip()
        bd = self.ui.de_birth.date().toString("yyyy-MM-dd")
        gender = self.ui.cb_gender.currentText()
        addr = self.ui.le_addr.text().strip()
        phone = self.ui.le_phone.text().strip()
        email = self.ui.le_email.text().strip()
        ps = self.ui.le_ps.text().strip()
        pn = self.ui.le_pn.text().strip()
        card = self.ui.le_card.text().strip()

        ptype = self.ui.cb_policy_type.currentText()
        pno = self.ui.le_policy_no.text().strip()
        ins = self.ui.cb_insurer.currentData()

        if not all([fio, addr, phone, email, ps, pn, card, pno, ins]):
            raise ValueError("Заполни все поля пациента и полиса.")

        pid = self.db.execute(Q["patient_insert"], (fio, bd, gender, addr, phone, email, ps, pn, card))
        self.db.execute(Q["policy_insert"], (pid, ptype, pno, int(ins)))

    def _save_appt(self):
        pid = int(self.ui.cb_patient.currentData())
        did = int(self.ui.cb_doctor.currentData())
        slot_id = int(self.ui.cb_slot.currentData()) if self.ui.cb_slot.currentData() else None
        kind = self.ui.cb_kind.currentText()
        status = self.ui.cb_status.currentText()
        price = float(self.recalc_price())
        pay_method = self.ui.cb_pay_method.currentText()
        diag = self.ui.le_diag.text().strip()
        rx = self.ui.le_rx.text().strip()

        if not slot_id:
            raise ValueError("Выбери свободный слот.")

        if self.record.get("appt_id"):
            old = self.db.fetchone("SELECT slot_id FROM appointments WHERE id=%s", (int(self.record["appt_id"]),))
            if old and int(old["slot_id"]) != slot_id:
                self.db.execute(Q["slot_book"], (0, int(old["slot_id"])))
            self.db.execute(Q["appt_update"], (did, slot_id, kind, status, price, int(self.record["appt_id"])))
            appt_id = int(self.record["appt_id"])
        else:
            appt_id = self.db.execute(Q["appt_insert"], (pid, did, slot_id, kind, "SCHEDULED", price))
            self.record["appt_id"] = appt_id

        self.db.execute(Q["slot_book"], (1, slot_id))

        if pay_method:
            self.db.execute(Q["pay_upsert"], (appt_id, pay_method, price))

        if diag and rx:
            self.db.execute(Q["mr_upsert"], (appt_id, diag, rx))
