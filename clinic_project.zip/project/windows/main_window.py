
from PyQt6.QtCore import QDate, QDateTime
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem, QAbstractItemView
from ui_py.ui_main import Ui_MainWindow
from db import DB
from queries import Q
from windows.edit_dialog import EditDialog

STYLESHEET = """
QWidget { background:
QLineEdit, QComboBox, QDateEdit, QDateTimeEdit, QSpinBox, QDoubleSpinBox, QListWidget {
  background:
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QDateTimeEdit:focus, QListWidget:focus { border: 1px solid
QPushButton { background:
QPushButton:hover { background:
QPushButton:pressed { background:
QTableWidget { background:
QHeaderView::section { background:
QTableWidget::item:selected { background:
"""

class MainWindow(QMainWindow):
    def __init__(self, role, patient_id, username):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setStyleSheet(STYLESHEET)
        self.db = DB()
        self.role = role
        self.patient_id = patient_id
        self.username = username
        self._setup_tables()
        self._init_defaults()
        self._load_lists()
        self.role_apply(role)
        self._bind()
        self.reload_registrar_all()
        self.reload_chief_all()
        self.reload_patient()

    def _setup_tables(self):
        for tw in [self.ui.tw_registrar, self.ui.tw_chief, self.ui.tw_schedule, self.ui.tw_my_appts, self.ui.tw_medcard]:
            tw.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            tw.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            tw.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            tw.setAlternatingRowColors(True)

    def _init_defaults(self):
        today = QDate.currentDate()
        self.ui.de_r_from.setDate(today.addDays(-14))
        self.ui.de_r_to.setDate(today.addDays(14))
        self.ui.de_c_from.setDate(today.addDays(-30))
        self.ui.de_c_to.setDate(today)
        self.ui.de_p_from.setDate(today)
        self.ui.de_p_to.setDate(today.addDays(14))

        self.ui.cb_r_status.clear()
        self.ui.cb_r_status.addItem("Все", "ALL")
        for s in ["SCHEDULED","IN_PROGRESS","COMPLETED","NO_SHOW","CANCELLED"]:
            self.ui.cb_r_status.addItem(s, s)

    def _bind(self):
        self.ui.btn_r_filter.clicked.connect(self.reload_registrar_filtered)
        self.ui.btn_r_reset.clicked.connect(self.reload_registrar_all)
        self.ui.btn_r_add_patient.clicked.connect(self.add_patient)
        self.ui.btn_r_add_appt.clicked.connect(self.add_appt)
        self.ui.btn_r_edit_appt.clicked.connect(self.edit_appt)
        self.ui.btn_r_cancel_appt.clicked.connect(self.cancel_appt)
        self.ui.btn_r_pay.clicked.connect(self.pay_appt)
        self.ui.btn_r_ref.clicked.connect(self.ref_appt)

        self.ui.btn_c_att.clicked.connect(self.attendance)
        self.ui.btn_c_avg.clicked.connect(self.avg_visit)

        self.ui.btn_p_search.clicked.connect(self.load_schedule)
        self.ui.btn_p_book.clicked.connect(self.patient_book)
        self.ui.btn_p_cancel.clicked.connect(self.patient_cancel)

    def role_apply(self, role):
        idx_r = self.ui.tabs_main.indexOf(self.ui.tab_registrar)
        idx_c = self.ui.tabs_main.indexOf(self.ui.tab_chief)
        idx_p = self.ui.tabs_main.indexOf(self.ui.tab_patient)
        self.ui.tabs_main.setTabVisible(idx_r, role in ("registrar",))
        self.ui.tabs_main.setTabVisible(idx_c, role in ("chief",))
        self.ui.tabs_main.setTabVisible(idx_p, role in ("patient",))
        if role == "registrar":
            self.ui.tabs_main.setCurrentIndex(idx_r)
        elif role == "chief":
            self.ui.tabs_main.setCurrentIndex(idx_c)
        else:
            self.ui.tabs_main.setCurrentIndex(idx_p)

    def _load_lists(self):
        try:
            specs = self.db.fetchall(Q["spec_list"])
            self.ui.cb_p_spec.clear()
            for s in specs:
                self.ui.cb_p_spec.addItem(s["name"], s["id"])

            docs = self.db.fetchall("SELECT d.id, CONCAT(d.fio,' (',sp.name,')') AS title FROM doctors d JOIN specializations sp ON sp.id=d.spec_id WHERE d.is_active=1 ORDER BY d.fio")
            self.ui.cb_r_doctor.clear()
            self.ui.cb_r_doctor.addItem("Все", 0)
            for d in docs:
                self.ui.cb_r_doctor.addItem(d["title"], d["id"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_table(self, tw, rows, headers, keys):
        tw.clear()
        tw.setColumnCount(len(headers))
        tw.setRowCount(len(rows))
        tw.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, k in enumerate(keys):
                v = row.get(k)
                tw.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        tw.resizeColumnsToContents()

    def selected_id(self, tw, col=0):
        sel = tw.selectedItems()
        if not sel:
            return None
        row = sel[0].row()
        try:
            return int(tw.item(row, col).text())
        except:
            return None

    def reload_registrar_all(self):
        try:
            rows = self.db.fetchall(Q["appt_all"])
            self.load_table(self.ui.tw_registrar, rows,
                            ["ID","Дата/время","Статус","Тип","Цена","Пациент","Телефон","Врач","Спец.","Каб."],
                            ["appt_id","start_dt","status","visit_kind","price","patient_fio","patient_phone","doctor_fio","spec_name","cabinet_name"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_registrar_filtered(self):
        try:
            st = self.ui.cb_r_status.currentData()
            doc = int(self.ui.cb_r_doctor.currentData())
            d_from = self.ui.de_r_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_r_to.date().toString("yyyy-MM-dd")
            rows = self.db.fetchall(Q["appt_filter"], (st, st, doc, doc, d_from, d_to))
            self.load_table(self.ui.tw_registrar, rows,
                            ["ID","Дата/время","Статус","Тип","Цена","Пациент","Телефон","Врач","Спец.","Каб."],
                            ["appt_id","start_dt","status","visit_kind","price","patient_fio","patient_phone","doctor_fio","spec_name","cabinet_name"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_patient(self):
        dlg = EditDialog(EditDialog.MODE_PATIENT, db=self.db, parent=self)
        if dlg.exec():
            self.reload_registrar_all()

    def add_appt(self):
        dlg = EditDialog(EditDialog.MODE_APPT, db=self.db, parent=self)
        if dlg.exec():
            QMessageBox.information(self, "Запись", "Запись создана. Пациент уведомлен.")
            self.reload_registrar_all()
            self.reload_chief_all()

    def edit_appt(self):
        appt_id = self.selected_id(self.ui.tw_registrar, 0)
        if not appt_id:
            QMessageBox.warning(self, "Запись", "Выбери запись.")
            return
        dlg = EditDialog(EditDialog.MODE_APPT, db=self.db, record={"appt_id": appt_id}, parent=self)
        if dlg.exec():
            QMessageBox.information(self, "Запись", "Изменено. Пациент уведомлен.")
            self.reload_registrar_all()
            self.reload_chief_all()

    def cancel_appt(self):
        appt_id = self.selected_id(self.ui.tw_registrar, 0)
        if not appt_id:
            QMessageBox.warning(self, "Отмена", "Выбери запись.")
            return
        try:
            old = self.db.fetchone("SELECT slot_id FROM appointments WHERE id=%s", (appt_id,))
            if old:
                self.db.execute(Q["slot_book"], (0, int(old["slot_id"])))
            self.db.execute(Q["appt_cancel"], (appt_id,))
            QMessageBox.information(self, "Отмена", "Отменено. Пациент уведомлен.")
            self.reload_registrar_all()
            self.reload_chief_all()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def pay_appt(self):
        appt_id = self.selected_id(self.ui.tw_registrar, 0)
        if not appt_id:
            QMessageBox.warning(self, "Оплата", "Выбери запись.")
            return
        try:
            row = self.db.fetchone("SELECT price FROM appointments WHERE id=%s", (appt_id,))
            if not row:
                return
            self.db.execute(Q["pay_upsert"], (appt_id, "CARD", float(row["price"])))
            QMessageBox.information(self, "Оплата", "Оплата оформлена (CARD).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def ref_appt(self):
        appt_id = self.selected_id(self.ui.tw_registrar, 0)
        if not appt_id:
            QMessageBox.warning(self, "Направление", "Выбери запись.")
            return
        try:
            self.db.execute(Q["ref_add"], (appt_id, "LAB", "ОАК, ОАМ"))
            QMessageBox.information(self, "Направление", "Создано направление (LAB).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def attendance(self):
        try:
            d_from = self.ui.de_c_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_c_to.date().toString("yyyy-MM-dd")
            res = self.db.callproc_one("sp_attendance_pct", (d_from, d_to))
            self.ui.lbl_c_att.setText(str(res["attendance_pct"] if res else 0.00))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def avg_visit(self):
        try:
            d_from = self.ui.de_c_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_c_to.date().toString("yyyy-MM-dd")
            row = self.db.fetchone("SELECT fn_avg_visit_cost(%s,%s) AS avg_cost", (d_from, d_to))
            self.ui.lbl_c_avg.setText(str(row["avg_cost"] if row else 0.00))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_chief_all(self):
        try:
            rows = self.db.fetchall(Q["appt_all"])
            self.load_table(self.ui.tw_chief, rows,
                            ["ID","Дата/время","Статус","Тип","Цена","Пациент","Врач","Спец."],
                            ["appt_id","start_dt","status","visit_kind","price","patient_fio","doctor_fio","spec_name"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_schedule(self):
        try:
            spec_id = int(self.ui.cb_p_spec.currentData())
            dt_from = self.ui.de_p_from.date().toString("yyyy-MM-dd") + " 00:00:00"
            dt_to = self.ui.de_p_to.date().toString("yyyy-MM-dd") + " 23:59:59"
            rows = self.db.fetchall(Q["slots_free_by_spec_period"], (spec_id, dt_from, dt_to))
            self.load_table(self.ui.tw_schedule, rows,
                            ["SLOT_ID","Дата/время","Врач","Каб."],
                            ["slot_id","start_dt","doctor_fio","cabinet_name"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def patient_book(self):
        if not self.patient_id:
            QMessageBox.warning(self, "Запись", "Нет patient_id.")
            return
        slot_id = self.selected_id(self.ui.tw_schedule, 0)
        if not slot_id:
            QMessageBox.warning(self, "Запись", "Выбери слот.")
            return
        try:
            slot = self.db.fetchone("SELECT doctor_id FROM doctor_slots WHERE id=%s AND is_booked=0", (slot_id,))
            if not slot:
                QMessageBox.warning(self, "Запись", "Слот уже занят.")
                return
            pol = self.db.fetchone(Q["policy_by_patient"], (self.patient_id,))
            policy_type = pol["policy_type"] if pol else None
            row = self.db.fetchone(Q["visit_price"], ("PRIMARY",))
            price = float(row["price_omc"] if policy_type=="OMC" else row["price_dmc"] if policy_type=="DMC" else row["price_cash"])
            appt_id = self.db.execute(Q["appt_insert"], (self.patient_id, int(slot["doctor_id"]), slot_id, "PRIMARY", "SCHEDULED", price))
            self.db.execute(Q["slot_book"], (1, slot_id))
            QMessageBox.information(self, "Запись", f"Запись создана (№{appt_id}). Стоимость: {price:.2f}")
            self.reload_patient()
            self.load_schedule()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def patient_cancel(self):
        if not self.patient_id:
            return
        appt_id = self.selected_id(self.ui.tw_my_appts, 0)
        if not appt_id:
            QMessageBox.warning(self, "Отмена", "Выбери запись.")
            return
        try:
            row = self.db.fetchone("SELECT slot_id, start_dt FROM v_appointments WHERE appt_id=%s", (appt_id,))
            if not row:
                return
            start = row["start_dt"]
            dt = QDateTime.fromString(str(start), "yyyy-MM-dd HH:mm:ss")
            if dt.isValid():
                if QDateTime.currentDateTime().secsTo(dt) < 24*3600:
                    QMessageBox.warning(self, "Отмена", "Отмена возможна не позднее чем за 24 часа.")
                    return
            self.db.execute(Q["appt_cancel"], (appt_id,))
            self.db.execute(Q["slot_book"], (0, int(row["slot_id"])))
            QMessageBox.information(self, "Отмена", "Отменено.")
            self.reload_patient()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_patient(self):
        if not self.patient_id:
            return
        try:
            rows = self.db.fetchall(Q["appt_by_patient"], (self.patient_id,))
            self.load_table(self.ui.tw_my_appts, rows,
                            ["ID","Дата/время","Статус","Тип","Цена","Врач","Спец."],
                            ["appt_id","start_dt","status","visit_kind","price","doctor_fio","spec_name"])
            mr = self.db.fetchall(Q["mr_by_patient"], (self.patient_id,))
            self.load_table(self.ui.tw_medcard, mr,
                            ["ID","Дата/время","Врач","Спец.","Статус","Диагноз","Назначение"],
                            ["appt_id","start_dt","doctor_fio","spec_name","status","diagnosis","prescription"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))
