1) В MySQL Workbench выполни sql/schema.sql
2) В config.py укажи DB_USER/DB_PASSWORD
3) pip install PyQt6 pymysql
4) python main.py
Тестовые пользователи:
registrar / 123
chief / 123
patient1 / 123
