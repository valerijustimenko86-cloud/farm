
from PyQt6 import QtCore, QtWidgets

class Ui_EditDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("EditDialog")
        Dialog.resize(760, 560)
        self.vbox = QtWidgets.QVBoxLayout(Dialog)
        self.vbox.setContentsMargins(12, 12, 12, 12)
        self.vbox.setSpacing(10)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.setObjectName("stack")

        self.page_patient = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(self.page_patient)

        self.le_fio = QtWidgets.QLineEdit(); self.le_fio.setObjectName("le_fio")
        self.de_birth = QtWidgets.QDateEdit(); self.de_birth.setObjectName("de_birth"); self.de_birth.setCalendarPopup(True)
        self.cb_gender = QtWidgets.QComboBox(); self.cb_gender.setObjectName("cb_gender"); self.cb_gender.addItems(["M","F"])
        self.le_addr = QtWidgets.QLineEdit(); self.le_addr.setObjectName("le_addr")
        self.le_phone = QtWidgets.QLineEdit(); self.le_phone.setObjectName("le_phone")
        self.le_email = QtWidgets.QLineEdit(); self.le_email.setObjectName("le_email")
        self.le_ps = QtWidgets.QLineEdit(); self.le_ps.setObjectName("le_ps")
        self.le_pn = QtWidgets.QLineEdit(); self.le_pn.setObjectName("le_pn")

        self.le_card = QtWidgets.QLineEdit(); self.le_card.setObjectName("le_card"); self.le_card.setReadOnly(True)

        self.cb_policy_type = QtWidgets.QComboBox(); self.cb_policy_type.setObjectName("cb_policy_type"); self.cb_policy_type.addItems(["OMC","DMC"])
        self.le_policy_no = QtWidgets.QLineEdit(); self.le_policy_no.setObjectName("le_policy_no")
        self.cb_insurer = QtWidgets.QComboBox(); self.cb_insurer.setObjectName("cb_insurer")

        r=0
        g.addWidget(QtWidgets.QLabel("ФИО"), r,0); g.addWidget(self.le_fio, r,1,1,3); r+=1
        g.addWidget(QtWidgets.QLabel("Дата рождения"), r,0); g.addWidget(self.de_birth, r,1)
        g.addWidget(QtWidgets.QLabel("Пол"), r,2); g.addWidget(self.cb_gender, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Адрес"), r,0); g.addWidget(self.le_addr, r,1,1,3); r+=1
        g.addWidget(QtWidgets.QLabel("Телефон"), r,0); g.addWidget(self.le_phone, r,1)
        g.addWidget(QtWidgets.QLabel("Email"), r,2); g.addWidget(self.le_email, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Паспорт серия"), r,0); g.addWidget(self.le_ps, r,1)
        g.addWidget(QtWidgets.QLabel("Паспорт номер"), r,2); g.addWidget(self.le_pn, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Номер медкарты"), r,0); g.addWidget(self.le_card, r,1); r+=1

        line = QtWidgets.QFrame(); line.setFrameShape(QtWidgets.QFrame.Shape.HLine); line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        g.addWidget(line, r,0,1,4); r+=1

        g.addWidget(QtWidgets.QLabel("Тип страхования"), r,0); g.addWidget(self.cb_policy_type, r,1)
        g.addWidget(QtWidgets.QLabel("Полис"), r,2); g.addWidget(self.le_policy_no, r,3); r+=1
        g.addWidget(QtWidgets.QLabel("Страховая"), r,0); g.addWidget(self.cb_insurer, r,1,1,3); r+=1
        g.setRowStretch(r, 1)

        self.stack.addWidget(self.page_patient)

        self.page_appt = QtWidgets.QWidget()
        ga = QtWidgets.QGridLayout(self.page_appt)

        self.cb_patient = QtWidgets.QComboBox(); self.cb_patient.setObjectName("cb_patient")
        self.cb_spec = QtWidgets.QComboBox(); self.cb_spec.setObjectName("cb_spec")
        self.cb_doctor = QtWidgets.QComboBox(); self.cb_doctor.setObjectName("cb_doctor")
        self.dt_from = QtWidgets.QDateTimeEdit(); self.dt_from.setObjectName("dt_from"); self.dt_from.setCalendarPopup(True)
        self.dt_to = QtWidgets.QDateTimeEdit(); self.dt_to.setObjectName("dt_to"); self.dt_to.setCalendarPopup(True)
        self.cb_slot = QtWidgets.QComboBox(); self.cb_slot.setObjectName("cb_slot")
        self.cb_kind = QtWidgets.QComboBox(); self.cb_kind.setObjectName("cb_kind"); self.cb_kind.addItems(["PRIMARY","REPEAT","PREVENT"])
        self.cb_status = QtWidgets.QComboBox(); self.cb_status.setObjectName("cb_status"); self.cb_status.addItems(["SCHEDULED","IN_PROGRESS","COMPLETED","NO_SHOW","CANCELLED"])
        self.lbl_policy = QtWidgets.QLabel("-"); self.lbl_policy.setObjectName("lbl_policy")
        self.lbl_price = QtWidgets.QLabel("0.00"); self.lbl_price.setObjectName("lbl_price")
        self.cb_pay_method = QtWidgets.QComboBox(); self.cb_pay_method.setObjectName("cb_pay_method"); self.cb_pay_method.addItems(["CASH","CARD","INSURANCE"])

        self.le_diag = QtWidgets.QLineEdit(); self.le_diag.setObjectName("le_diag")
        self.le_rx = QtWidgets.QLineEdit(); self.le_rx.setObjectName("le_rx")
        self.cb_ref_kind = QtWidgets.QComboBox(); self.cb_ref_kind.setObjectName("cb_ref_kind"); self.cb_ref_kind.addItems(["LAB","DIAG"])
        self.le_ref_desc = QtWidgets.QLineEdit(); self.le_ref_desc.setObjectName("le_ref_desc")
        self.btn_ref_add = QtWidgets.QPushButton("Добавить направление"); self.btn_ref_add.setObjectName("btn_ref_add")

        r=0
        ga.addWidget(QtWidgets.QLabel("Пациент"), r,0); ga.addWidget(self.cb_patient, r,1,1,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Специализация"), r,0); ga.addWidget(self.cb_spec, r,1)
        ga.addWidget(QtWidgets.QLabel("Врач"), r,2); ga.addWidget(self.cb_doctor, r,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Период слотов"), r,0)
        hb = QtWidgets.QHBoxLayout()
        hb.addWidget(self.dt_from); hb.addWidget(self.dt_to)
        ga.addLayout(hb, r,1,1,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Свободный слот"), r,0); ga.addWidget(self.cb_slot, r,1,1,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Тип приема"), r,0); ga.addWidget(self.cb_kind, r,1)
        ga.addWidget(QtWidgets.QLabel("Статус"), r,2); ga.addWidget(self.cb_status, r,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Страхование"), r,0); ga.addWidget(self.lbl_policy, r,1)
        ga.addWidget(QtWidgets.QLabel("Стоимость"), r,2); ga.addWidget(self.lbl_price, r,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Оплата"), r,0); ga.addWidget(self.cb_pay_method, r,1); r+=1

        line2 = QtWidgets.QFrame(); line2.setFrameShape(QtWidgets.QFrame.Shape.HLine); line2.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        ga.addWidget(line2, r,0,1,4); r+=1

        ga.addWidget(QtWidgets.QLabel("Диагноз"), r,0); ga.addWidget(self.le_diag, r,1,1,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Назначение"), r,0); ga.addWidget(self.le_rx, r,1,1,3); r+=1
        ga.addWidget(QtWidgets.QLabel("Направление"), r,0); ga.addWidget(self.cb_ref_kind, r,1)
        ga.addWidget(self.le_ref_desc, r,2); ga.addWidget(self.btn_ref_add, r,3); r+=1
        ga.setRowStretch(r, 1)

        self.stack.addWidget(self.page_appt)

        self.hbox = QtWidgets.QHBoxLayout()
        self.hbox.addStretch()
        self.btn_save = QtWidgets.QPushButton("Сохранить"); self.btn_save.setObjectName("btn_save")
        self.btn_cancel = QtWidgets.QPushButton("Отмена"); self.btn_cancel.setObjectName("btn_cancel")
        self.hbox.addWidget(self.btn_save)
        self.hbox.addWidget(self.btn_cancel)

        self.vbox.addWidget(self.stack)
        self.vbox.addLayout(self.hbox)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
