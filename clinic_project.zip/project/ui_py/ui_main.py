
from PyQt6 import QtCore, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1200, 780)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.vbox_main = QtWidgets.QVBoxLayout(self.centralwidget)
        self.vbox_main.setContentsMargins(12, 12, 12, 12)
        self.vbox_main.setSpacing(10)

        self.tabs_main = QtWidgets.QTabWidget(parent=self.centralwidget)
        self.tabs_main.setObjectName("tabs_main")

        self.tab_registrar = QtWidgets.QWidget()
        self.tab_registrar.setObjectName("tab_registrar")
        vR = QtWidgets.QVBoxLayout(self.tab_registrar)
        vR.setSpacing(10)

        gb = QtWidgets.QGroupBox("Фильтр записей", parent=self.tab_registrar)
        grid = QtWidgets.QGridLayout(gb)
        self.cb_r_status = QtWidgets.QComboBox(); self.cb_r_status.setObjectName("cb_r_status")
        self.cb_r_doctor = QtWidgets.QComboBox(); self.cb_r_doctor.setObjectName("cb_r_doctor")
        self.de_r_from = QtWidgets.QDateEdit(); self.de_r_from.setObjectName("de_r_from"); self.de_r_from.setCalendarPopup(True)
        self.de_r_to = QtWidgets.QDateEdit(); self.de_r_to.setObjectName("de_r_to"); self.de_r_to.setCalendarPopup(True)
        self.btn_r_filter = QtWidgets.QPushButton("Фильтровать"); self.btn_r_filter.setObjectName("btn_r_filter")
        self.btn_r_reset = QtWidgets.QPushButton("Показать все"); self.btn_r_reset.setObjectName("btn_r_reset")

        grid.addWidget(QtWidgets.QLabel("Статус"), 0, 0); grid.addWidget(self.cb_r_status, 0, 1)
        grid.addWidget(QtWidgets.QLabel("Врач"), 0, 2); grid.addWidget(self.cb_r_doctor, 0, 3)
        grid.addWidget(QtWidgets.QLabel("С"), 1, 0); grid.addWidget(self.de_r_from, 1, 1)
        grid.addWidget(QtWidgets.QLabel("По"), 1, 2); grid.addWidget(self.de_r_to, 1, 3)
        hb = QtWidgets.QHBoxLayout()
        hb.addStretch()
        hb.addWidget(self.btn_r_filter)
        hb.addWidget(self.btn_r_reset)
        grid.addLayout(hb, 2, 3)

        self.tw_registrar = QtWidgets.QTableWidget(); self.tw_registrar.setObjectName("tw_registrar")

        hr = QtWidgets.QHBoxLayout()
        self.btn_r_add_patient = QtWidgets.QPushButton("Новый пациент"); self.btn_r_add_patient.setObjectName("btn_r_add_patient")
        self.btn_r_add_appt = QtWidgets.QPushButton("Записать на прием"); self.btn_r_add_appt.setObjectName("btn_r_add_appt")
        self.btn_r_edit_appt = QtWidgets.QPushButton("Изменить запись"); self.btn_r_edit_appt.setObjectName("btn_r_edit_appt")
        self.btn_r_cancel_appt = QtWidgets.QPushButton("Отменить"); self.btn_r_cancel_appt.setObjectName("btn_r_cancel_appt")
        self.btn_r_pay = QtWidgets.QPushButton("Оплата"); self.btn_r_pay.setObjectName("btn_r_pay")
        self.btn_r_ref = QtWidgets.QPushButton("Направление"); self.btn_r_ref.setObjectName("btn_r_ref")

        hr.addWidget(self.btn_r_add_patient)
        hr.addWidget(self.btn_r_add_appt)
        hr.addWidget(self.btn_r_edit_appt)
        hr.addWidget(self.btn_r_cancel_appt)
        hr.addStretch()
        hr.addWidget(self.btn_r_pay)
        hr.addWidget(self.btn_r_ref)

        vR.addWidget(gb)
        vR.addWidget(self.tw_registrar, 3)
        vR.addLayout(hr)
        self.tabs_main.addTab(self.tab_registrar, "Регистратура")

        self.tab_chief = QtWidgets.QWidget()
        self.tab_chief.setObjectName("tab_chief")
        vC = QtWidgets.QVBoxLayout(self.tab_chief)
        vC.setSpacing(10)

        gbA = QtWidgets.QGroupBox("Статистика", parent=self.tab_chief)
        gridA = QtWidgets.QGridLayout(gbA)
        self.de_c_from = QtWidgets.QDateEdit(); self.de_c_from.setObjectName("de_c_from"); self.de_c_from.setCalendarPopup(True)
        self.de_c_to = QtWidgets.QDateEdit(); self.de_c_to.setObjectName("de_c_to"); self.de_c_to.setCalendarPopup(True)
        self.btn_c_att = QtWidgets.QPushButton("Процент явки"); self.btn_c_att.setObjectName("btn_c_att")
        self.lbl_c_att = QtWidgets.QLabel("0.00"); self.lbl_c_att.setObjectName("lbl_c_att")
        self.btn_c_avg = QtWidgets.QPushButton("Средняя стоимость приема"); self.btn_c_avg.setObjectName("btn_c_avg")
        self.lbl_c_avg = QtWidgets.QLabel("0.00"); self.lbl_c_avg.setObjectName("lbl_c_avg")

        gridA.addWidget(QtWidgets.QLabel("С"), 0, 0); gridA.addWidget(self.de_c_from, 0, 1)
        gridA.addWidget(QtWidgets.QLabel("По"), 0, 2); gridA.addWidget(self.de_c_to, 0, 3)
        gridA.addWidget(self.btn_c_att, 1, 0); gridA.addWidget(self.lbl_c_att, 1, 1)
        gridA.addWidget(self.btn_c_avg, 1, 2); gridA.addWidget(self.lbl_c_avg, 1, 3)

        self.tw_chief = QtWidgets.QTableWidget(); self.tw_chief.setObjectName("tw_chief")

        vC.addWidget(gbA)
        vC.addWidget(QtWidgets.QLabel("Все записи (обзор)"))
        vC.addWidget(self.tw_chief, 3)
        self.tabs_main.addTab(self.tab_chief, "Главврач")

        self.tab_patient = QtWidgets.QWidget()
        self.tab_patient.setObjectName("tab_patient")
        vP = QtWidgets.QVBoxLayout(self.tab_patient)
        vP.setSpacing(10)

        gbS = QtWidgets.QGroupBox("Расписание", parent=self.tab_patient)
        gridS = QtWidgets.QGridLayout(gbS)
        self.cb_p_spec = QtWidgets.QComboBox(); self.cb_p_spec.setObjectName("cb_p_spec")
        self.de_p_from = QtWidgets.QDateEdit(); self.de_p_from.setObjectName("de_p_from"); self.de_p_from.setCalendarPopup(True)
        self.de_p_to = QtWidgets.QDateEdit(); self.de_p_to.setObjectName("de_p_to"); self.de_p_to.setCalendarPopup(True)
        self.btn_p_search = QtWidgets.QPushButton("Показать"); self.btn_p_search.setObjectName("btn_p_search")
        self.tw_schedule = QtWidgets.QTableWidget(); self.tw_schedule.setObjectName("tw_schedule")
        self.btn_p_book = QtWidgets.QPushButton("Записаться"); self.btn_p_book.setObjectName("btn_p_book")

        gridS.addWidget(QtWidgets.QLabel("Специализация"), 0, 0); gridS.addWidget(self.cb_p_spec, 0, 1)
        gridS.addWidget(QtWidgets.QLabel("С"), 0, 2); gridS.addWidget(self.de_p_from, 0, 3)
        gridS.addWidget(QtWidgets.QLabel("По"), 0, 4); gridS.addWidget(self.de_p_to, 0, 5)
        gridS.addWidget(self.btn_p_search, 0, 6)
        gridS.addWidget(self.tw_schedule, 1, 0, 1, 7)
        gridS.addWidget(self.btn_p_book, 2, 6)

        gbM = QtWidgets.QGroupBox("Моя медкарта", parent=self.tab_patient)
        vM = QtWidgets.QVBoxLayout(gbM)
        self.tw_medcard = QtWidgets.QTableWidget(); self.tw_medcard.setObjectName("tw_medcard")
        self.btn_p_cancel = QtWidgets.QPushButton("Отменить запись"); self.btn_p_cancel.setObjectName("btn_p_cancel")
        self.tw_my_appts = QtWidgets.QTableWidget(); self.tw_my_appts.setObjectName("tw_my_appts")

        vM.addWidget(QtWidgets.QLabel("Мои записи"))
        vM.addWidget(self.tw_my_appts, 2)
        vM.addWidget(self.btn_p_cancel)
        vM.addWidget(QtWidgets.QLabel("История обращений"))
        vM.addWidget(self.tw_medcard, 3)

        vP.addWidget(gbS, 2)
        vP.addWidget(gbM, 3)

        self.tabs_main.addTab(self.tab_patient, "Пациент")

        self.vbox_main.addWidget(self.tabs_main)
        MainWindow.setCentralWidget(self.centralwidget)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
