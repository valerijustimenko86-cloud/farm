
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QDialog, QMessageBox, QListWidgetItem
from ui_py.ui_edit_dialog import Ui_EditDialog

class EditDialog(QDialog):
    MODE_CLIENT = "client"
    MODE_OPERATOR = "operator"
    MODE_BOOKING = "booking"

    def __init__(self, mode, db, record=None, parent=None, client_id_lock=None):
        super().__init__(parent)
        self.ui = Ui_EditDialog()
        self.ui.setupUi(self)
        self.db = db
        self.mode = mode
        self.record = record or {}
        self.client_id_lock = client_id_lock
        self.ui.btn_cancel.clicked.connect(self.reject)
        self.ui.btn_save.clicked.connect(self.save)
        self._init_mode()

    def _init_mode(self):
        if self.mode == self.MODE_CLIENT:
            self.ui.stack.setCurrentIndex(0)
            self._load_client()
        elif self.mode == self.MODE_OPERATOR:
            self.ui.stack.setCurrentIndex(1)
            self._load_operator()
        elif self.mode == self.MODE_BOOKING:
            self.ui.stack.setCurrentIndex(2)
            self._load_booking()
        else:
            raise ValueError("Unknown mode")

    def _load_client(self):
        self.ui.le_fio.setText(self.record.get("fio", ""))
        bd = self.record.get("birth_date")
        self.ui.de_birth.setDate(QDate.currentDate() if not bd else QDate.fromString(str(bd), "yyyy-MM-dd"))
        self.ui.le_phone.setText(self.record.get("phone", ""))
        self.ui.le_email.setText(self.record.get("email", ""))
        self.ui.le_passport.setText(self.record.get("passport", ""))

    def _load_operator(self):
        self.ui.le_op_name.setText(self.record.get("name", ""))
        self.ui.le_op_phone.setText(self.record.get("phone", "") or "")
        self.ui.le_op_email.setText(self.record.get("email", "") or "")

    def _load_booking(self):
        self.clients = self.db.fetchall("SELECT id, fio FROM clients ORDER BY fio")
        self.tours = self.db.fetchall("SELECT * FROM v_tours WHERE is_active=1 ORDER BY depart_date")
        self.services = self.db.fetchall("SELECT id, name, price FROM services ORDER BY name")

        self.ui.cb_b_client.clear()
        for c in self.clients:
            self.ui.cb_b_client.addItem(c["fio"], c["id"])

        self.ui.cb_b_tour.clear()
        for t in self.tours:
            label = f'#{t["tour_id"]} {t["country"]}/{t["city"]} {t["depart_date"]} {t["duration_days"]}д — {t["base_price"]}'
            self.ui.cb_b_tour.addItem(label, t["tour_id"])

        self.ui.lw_b_services.clear()
        for s in self.services:
            it = QListWidgetItem(f'{s["name"]} (+{s["price"]})')
            it.setData(32, s["id"])
            self.ui.lw_b_services.addItem(it)

        if self.record:
            cid = self.record.get("client_id")
            tid = self.record.get("tour_id")
            if cid is not None:
                idx = self.ui.cb_b_client.findData(cid)
                if idx >= 0:
                    self.ui.cb_b_client.setCurrentIndex(idx)
            if tid is not None:
                idx = self.ui.cb_b_tour.findData(tid)
                if idx >= 0:
                    self.ui.cb_b_tour.setCurrentIndex(idx)

            td = self.record.get("travel_date")
            self.ui.de_b_travel.setDate(QDate.currentDate() if not td else QDate.fromString(str(td), "yyyy-MM-dd"))
            self.ui.sp_b_tourists.setValue(int(self.record.get("tourists_count", 1)))
            st = self.record.get("status", "PENDING")
            idx = self.ui.cb_b_status.findText(st)
            if idx >= 0:
                self.ui.cb_b_status.setCurrentIndex(idx)

            bid = self.record.get("id")
            if bid:
                rows = self.db.fetchall("SELECT service_id FROM booking_services WHERE booking_id=%s", (bid,))
                sids = {r["service_id"] for r in rows}
                for i in range(self.ui.lw_b_services.count()):
                    it = self.ui.lw_b_services.item(i)
                    if it.data(32) in sids:
                        it.setSelected(True)
        else:
            self.ui.de_b_travel.setDate(QDate.currentDate())

        if self.client_id_lock is not None:
            idx = self.ui.cb_b_client.findData(self.client_id_lock)
            if idx >= 0:
                self.ui.cb_b_client.setCurrentIndex(idx)
            self.ui.cb_b_client.setEnabled(False)

    def save(self):
        try:
            if self.mode == self.MODE_CLIENT:
                self._save_client()
            elif self.mode == self.MODE_OPERATOR:
                self._save_operator()
            elif self.mode == self.MODE_BOOKING:
                self._save_booking()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _save_client(self):
        fio = self.ui.le_fio.text().strip()
        phone = self.ui.le_phone.text().strip()
        email = self.ui.le_email.text().strip()
        passport = self.ui.le_passport.text().strip()
        birth = self.ui.de_birth.date().toString("yyyy-MM-dd")
        if not fio or not phone or not email or not passport:
            raise ValueError("Заполни все поля клиента.")
        if self.record.get("id"):
            self.db.execute(
                "UPDATE clients SET fio=%s,birth_date=%s,phone=%s,email=%s,passport=%s WHERE id=%s",
                (fio, birth, phone, email, passport, self.record["id"])
            )
        else:
            self.db.execute(
                "INSERT INTO clients(fio,birth_date,phone,email,passport) VALUES(%s,%s,%s,%s,%s)",
                (fio, birth, phone, email, passport)
            )

    def _save_operator(self):
        name = self.ui.le_op_name.text().strip()
        phone = self.ui.le_op_phone.text().strip() or None
        email = self.ui.le_op_email.text().strip() or None
        if not name:
            raise ValueError("Название туроператора обязательно.")
        if self.record.get("id"):
            self.db.execute("UPDATE tour_operators SET name=%s, phone=%s, email=%s WHERE id=%s", (name, phone, email, self.record["id"]))
        else:
            self.db.execute("INSERT INTO tour_operators(name, phone, email) VALUES(%s,%s,%s)", (name, phone, email))

    def _save_booking(self):
        client_id = int(self.ui.cb_b_client.currentData())
        tour_id = int(self.ui.cb_b_tour.currentData())
        travel_date = self.ui.de_b_travel.date().toString("yyyy-MM-dd")
        tourists = int(self.ui.sp_b_tourists.value())
        status = self.ui.cb_b_status.currentText()
        note = None

        selected_service_ids = [int(it.data(32)) for it in self.ui.lw_b_services.selectedItems()]

        if self.record.get("id"):
            bid = self.record["id"]
            self.db.execute(
                "UPDATE bookings SET client_id=%s, tour_id=%s, tourists_count=%s, travel_date=%s, status=%s, note=%s WHERE id=%s",
                (client_id, tour_id, tourists, travel_date, status, note, bid)
            )
        else:
            bid = self.db.execute(
                "INSERT INTO bookings(client_id,tour_id,tourists_count,travel_date,status,note) VALUES(%s,%s,%s,%s,%s,%s)",
                (client_id, tour_id, tourists, travel_date, status, note)
            )

        self.db.execute("DELETE FROM booking_services WHERE booking_id=%s", (bid,))
        for sid in selected_service_ids:
            self.db.execute("INSERT INTO booking_services(booking_id, service_id, qty) VALUES(%s,%s,%s)", (bid, sid, 1))
