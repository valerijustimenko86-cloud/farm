
from PyQt6.QtWidgets import QMainWindow, QMessageBox
from ui_py.ui_login import Ui_LoginWindow
from db import DB
from queries import Q

class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)
        self.db = DB()
        self.ui.btn_login.clicked.connect(self.do_login)
        self.ui.le_username.setText("manager")
        self.ui.le_password.setText("123")

    def do_login(self):
        u = self.ui.le_username.text().strip()
        p = self.ui.le_password.text().strip()
        if not u or not p:
            QMessageBox.warning(self, "Вход", "Введи логин и пароль.")
            return
        try:
            row = self.db.fetchone(Q["auth"], (u, p))
            if not row:
                QMessageBox.warning(self, "Вход", "Неверный логин или пароль.")
                return
            role = row["role"]
            client_id = row["client_id"]
            from windows.main_window import MainWindow
            self.main = MainWindow(role=role, client_id=client_id)
            self.main.show()
            self.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))
