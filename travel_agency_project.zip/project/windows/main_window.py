
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem, QAbstractItemView, QInputDialog
from ui_py.ui_main import Ui_MainWindow
from db import DB
from queries import Q
from windows.edit_dialog import EditDialog

STYLESHEET = """
QWidget { background:
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QListWidget {
  background:
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QListWidget:focus { border: 1px solid
QPushButton { background:
QPushButton:hover { background:
QPushButton:pressed { background:
QTableWidget { background:
QHeaderView::section { background:
QTableWidget::item:selected { background:
"""

class MainWindow(QMainWindow):
    def __init__(self, role, client_id):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setStyleSheet(STYLESHEET)
        self.db = DB()
        self.role = role
        self.client_id = client_id
        self._setup_tables()
        self._init_dates()
        self._load_common_lists()
        self.role_apply(role)
        self._bind()
        self.reload_tours_manager()
        self.reload_bookings_manager()
        self.reload_ops_director()
        self.reload_tours_client()
        self.reload_mybookings_client()

    def _setup_tables(self):
        for tw in [self.ui.tw_m_tours, self.ui.tw_m_bookings, self.ui.tw_d_ops, self.ui.tw_c_tours, self.ui.tw_c_mybookings]:
            tw.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            tw.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            tw.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            tw.setAlternatingRowColors(True)

    def _init_dates(self):
        today = QDate.currentDate()
        self.ui.de_m_from.setDate(today.addMonths(-1))
        self.ui.de_m_to.setDate(today.addMonths(6))
        self.ui.de_d_from.setDate(today.addMonths(-1))
        self.ui.de_d_to.setDate(today)
        self.ui.de_c_travel_date.setDate(today.addDays(7))

    def _bind(self):
        self.ui.btn_m_filter.clicked.connect(self.reload_tours_manager_filtered)
        self.ui.btn_m_reset.clicked.connect(self.reload_tours_manager)
        self.ui.btn_m_add_client.clicked.connect(self.add_client)
        self.ui.btn_m_book.clicked.connect(self.add_booking_from_selected_tour)
        self.ui.btn_m_edit_booking.clicked.connect(self.edit_selected_booking)
        self.ui.btn_m_cancel_booking.clicked.connect(self.cancel_selected_booking)
        self.ui.btn_m_pay.clicked.connect(self.pay_selected_booking)
        self.ui.btn_m_receipt.clicked.connect(self.show_receipt_selected_booking)

        self.ui.btn_d_avg.clicked.connect(self.director_avg)
        self.ui.btn_d_repeat.clicked.connect(self.director_repeat_pct)
        self.ui.btn_d_add_op.clicked.connect(self.add_operator)
        self.ui.btn_d_edit_op.clicked.connect(self.edit_operator)
        self.ui.btn_d_del_op.clicked.connect(self.delete_operator)

        self.ui.btn_c_filter.clicked.connect(self.reload_tours_client_filtered)
        self.ui.btn_c_reset.clicked.connect(self.reload_tours_client)
        self.ui.btn_c_request.clicked.connect(self.client_request_booking)

    def role_apply(self, role):
        idx_m = self.ui.tabs_main.indexOf(self.ui.tab_manager)
        idx_d = self.ui.tabs_main.indexOf(self.ui.tab_director)
        idx_c = self.ui.tabs_main.indexOf(self.ui.tab_client)
        self.ui.tabs_main.setTabVisible(idx_m, role in ("manager", "director"))
        self.ui.tabs_main.setTabVisible(idx_d, role == "director")
        self.ui.tabs_main.setTabVisible(idx_c, role == "client")
        if role == "manager":
            self.ui.tabs_main.setCurrentIndex(idx_m)
        elif role == "director":
            self.ui.tabs_main.setCurrentIndex(idx_d)
        else:
            self.ui.tabs_main.setCurrentIndex(idx_c)

    def _load_common_lists(self):
        try:
            ops = self.db.fetchall(Q["ops_list"])
            self.ui.cb_m_operator.clear()
            self.ui.cb_m_operator.addItem("Все", "ALL")
            for o in ops:
                self.ui.cb_m_operator.addItem(o["name"], o["name"])

            services = self.db.fetchall(Q["services_list"])
            self.ui.lw_c_services.clear()
            from PyQt6.QtWidgets import QListWidgetItem
            for s in services:
                item = QListWidgetItem(f'{s["name"]} (+{s["price"]})')
                item.setData(32, s["id"])
                self.ui.lw_c_services.addItem(item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_table(self, tw, rows, headers, keys):
        tw.clear()
        tw.setColumnCount(len(headers))
        tw.setRowCount(len(rows))
        tw.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, k in enumerate(keys):
                v = row.get(k)
                item = QTableWidgetItem("" if v is None else str(v))
                tw.setItem(r, c, item)
        tw.resizeColumnsToContents()

    def selected_id(self, tw, id_col=0):
        sel = tw.selectedItems()
        if not sel:
            return None
        row = sel[0].row()
        val = tw.item(row, id_col).text()
        try:
            return int(val)
        except:
            return None

    def reload_tours_manager(self):
        try:
            rows = self.db.fetchall(Q["tours_base"])
            self.load_table(self.ui.tw_m_tours, rows,
                ["ID", "Оператор", "Страна", "Город", "Вылет", "Дней", "Цена"],
                ["tour_id", "operator_name", "country", "city", "depart_date", "duration_days", "base_price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_tours_manager_filtered(self):
        try:
            country = self.ui.le_m_country.text().strip()
            city = self.ui.le_m_city.text().strip()
            op = self.ui.cb_m_operator.currentData()
            d_from = self.ui.de_m_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_m_to.date().toString("yyyy-MM-dd")
            p_from = float(self.ui.sp_m_price_from.value())
            p_to = float(self.ui.sp_m_price_to.value())
            rows = self.db.fetchall(Q["tours_filter_manager"], (country, country, city, city, op, op, d_from, d_to, p_from, p_to))
            self.load_table(self.ui.tw_m_tours, rows,
                ["ID", "Оператор", "Страна", "Город", "Вылет", "Дней", "Цена"],
                ["tour_id", "operator_name", "country", "city", "depart_date", "duration_days", "base_price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_bookings_manager(self):
        try:
            rows = self.db.fetchall(Q["bookings_table"])
            self.load_table(self.ui.tw_m_bookings, rows,
                ["ID", "Клиент", "Тел", "Email", "Оператор", "Страна", "Дата", "Туристов", "Статус"],
                ["booking_id", "client_fio", "client_phone", "client_email", "operator_name",
                 "country", "travel_date", "tourists_count", "status"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_client(self):
        dlg = EditDialog(EditDialog.MODE_CLIENT, db=self.db, parent=self)
        if dlg.exec():
            self._load_common_lists()
            QMessageBox.information(self, "Готово", "Клиент сохранён.")

    def add_booking_from_selected_tour(self):
        tour_id = self.selected_id(self.ui.tw_m_tours, 0)
        if not tour_id:
            QMessageBox.warning(self, "Бронь", "Выбери тур.")
            return
        rec = {"tour_id": tour_id}
        dlg = EditDialog(EditDialog.MODE_BOOKING, db=self.db, record=rec, parent=self)
        if dlg.exec():
            self.reload_bookings_manager()

    def edit_selected_booking(self):
        bid = self.selected_id(self.ui.tw_m_bookings, 0)
        if not bid:
            QMessageBox.warning(self, "Изменение", "Выбери бронирование.")
            return
        row = self.db.fetchone("SELECT * FROM bookings WHERE id=%s", (bid,))
        dlg = EditDialog(EditDialog.MODE_BOOKING, db=self.db, record=row, parent=self)
        if dlg.exec():
            self.reload_bookings_manager()

    def cancel_selected_booking(self):
        bid = self.selected_id(self.ui.tw_m_bookings, 0)
        if not bid:
            QMessageBox.warning(self, "Отмена", "Выбери бронирование.")
            return
        try:
            self.db.execute(Q["booking_set_status"], ("CANCELLED", bid))
            self.reload_bookings_manager()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def pay_selected_booking(self):
        bid = self.selected_id(self.ui.tw_m_bookings, 0)
        if not bid:
            QMessageBox.warning(self, "Оплата", "Выбери бронирование.")
            return
        method, ok = QInputDialog.getItem(self, "Оплата", "Способ оплаты:", ["CASH", "CARD", "ONLINE"], 0, False)
        if not ok:
            return
        try:
            total = self.db.fetchone(Q["calc_total"], (bid,))["total_amount"]
            self.db.execute(Q["payment_upsert"], (bid, method, total))
            self.db.execute(Q["booking_set_status"], ("PAID", bid))
            self.reload_bookings_manager()
            QMessageBox.information(self, "Оплата", f"Оплачено: {total} ({method})")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def show_receipt_selected_booking(self):
        bid = self.selected_id(self.ui.tw_m_bookings, 0)
        if not bid:
            QMessageBox.warning(self, "Чек", "Выбери бронирование.")
            return
        try:
            head = self.db.fetchone(Q["receipt"], (bid,))
            lines = self.db.fetchall(Q["receipt_services"], (bid,))
            if not head:
                QMessageBox.warning(self, "Чек", "Данные не найдены.")
                return
            txt = []
            txt.append(f'ЧЕК №{head["booking_id"]}')
            txt.append(f'Клиент: {head["fio"]} | {head["phone"]} | {head["email"]}')
            txt.append(f'Туроператор: {head["operator_name"]}')
            txt.append(f'Тур: {head["country"]} / {head["city"]} | дата: {head["travel_date"]}')
            txt.append(f'Туристов: {head["tourists_count"]}')
            txt.append("")
            txt.append("Услуги:")
            if lines:
                for ln in lines:
                    txt.append(f'- {ln["name"]}: {ln["price"]} x {ln["qty"]} = {ln["line_sum"]}')
            else:
                txt.append("- нет")
            txt.append("")
            txt.append(f'Итого: {head.get("amount") or "не оплачено"}')
            txt.append(f'Метод: {head.get("method") or "-"} | Дата оплаты: {head.get("paid_at") or "-"}')
            QMessageBox.information(self, "Чек", "\n".join(txt))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_ops_director(self):
        try:
            rows = self.db.fetchall(Q["ops_table"])
            self.load_table(self.ui.tw_d_ops, rows, ["ID", "Название", "Телефон", "Email"], ["id", "name", "phone", "email"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_operator(self):
        dlg = EditDialog(EditDialog.MODE_OPERATOR, db=self.db, parent=self)
        if dlg.exec():
            self.reload_ops_director()
            self._load_common_lists()

    def edit_operator(self):
        oid = self.selected_id(self.ui.tw_d_ops, 0)
        if not oid:
            QMessageBox.warning(self, "Оператор", "Выбери туроператора.")
            return
        row = self.db.fetchone("SELECT id, name, phone, email FROM tour_operators WHERE id=%s", (oid,))
        dlg = EditDialog(EditDialog.MODE_OPERATOR, db=self.db, record=row, parent=self)
        if dlg.exec():
            self.reload_ops_director()
            self._load_common_lists()

    def delete_operator(self):
        oid = self.selected_id(self.ui.tw_d_ops, 0)
        if not oid:
            QMessageBox.warning(self, "Оператор", "Выбери туроператора.")
            return
        try:
            self.db.execute(Q["ops_delete"], (oid,))
            self.reload_ops_director()
            self._load_common_lists()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def director_avg(self):
        try:
            d_from = self.ui.de_d_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_d_to.date().toString("yyyy-MM-dd")
            res = self.db.callproc_one("sp_avg_tour_cost", (d_from, d_to))
            val = res["avg_tour_cost"] if res else 0.00
            self.ui.lbl_d_avg_result.setText(str(val))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def director_repeat_pct(self):
        try:
            res = self.db.fetchone(Q["director_repeat_pct"])
            self.ui.lbl_d_repeat_result.setText(str(res["pct"]))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_tours_client(self):
        try:
            rows = self.db.fetchall(Q["tours_base"])
            self.load_table(self.ui.tw_c_tours, rows,
                ["ID", "Оператор", "Страна", "Город", "Вылет", "Дней", "Цена"],
                ["tour_id", "operator_name", "country", "city", "depart_date", "duration_days", "base_price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_tours_client_filtered(self):
        try:
            country = self.ui.le_c_country.text().strip()
            city = self.ui.le_c_city.text().strip()
            rows = self.db.fetchall(Q["tours_filter_client"], (country, country, city, city))
            self.load_table(self.ui.tw_c_tours, rows,
                ["ID", "Оператор", "Страна", "Город", "Вылет", "Дней", "Цена"],
                ["tour_id", "operator_name", "country", "city", "depart_date", "duration_days", "base_price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_mybookings_client(self):
        if not self.client_id:
            return
        try:
            rows = self.db.fetchall(
                "SELECT b.id AS booking_id, t.country, t.city, b.travel_date, b.tourists_count, b.status FROM bookings b JOIN tours t ON t.id=b.tour_id WHERE b.client_id=%s ORDER BY b.created_at DESC",
                (self.client_id,)
            )
            self.load_table(self.ui.tw_c_mybookings, rows,
                ["ID", "Страна", "Город", "Дата", "Туристов", "Статус"],
                ["booking_id", "country", "city", "travel_date", "tourists_count", "status"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def client_request_booking(self):
        if not self.client_id:
            QMessageBox.warning(self, "Заявка", "Нет client_id.")
            return
        tour_id = self.selected_id(self.ui.tw_c_tours, 0)
        if not tour_id:
            QMessageBox.warning(self, "Заявка", "Выбери тур.")
            return
        try:
            travel_date = self.ui.de_c_travel_date.date().toString("yyyy-MM-dd")
            tourists = int(self.ui.sp_c_tourists.value())
            bid = self.db.execute(Q["booking_insert"], (self.client_id, tour_id, tourists, travel_date, "PENDING", "Заявка от клиента"))
            selected_service_ids = [int(it.data(32)) for it in self.ui.lw_c_services.selectedItems()]
            self.db.execute(Q["bs_clear"], (bid,))
            for sid in selected_service_ids:
                self.db.execute(Q["bs_add"], (bid, sid, 1))
            self.reload_mybookings_client()
            QMessageBox.information(self, "Заявка", f"Заявка создана (№{bid}).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))
