
from PyQt6 import QtCore, QtWidgets

class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        LoginWindow.setObjectName("LoginWindow")
        LoginWindow.resize(360, 220)
        self.centralwidget = QtWidgets.QWidget(parent=LoginWindow)
        self.vbox = QtWidgets.QVBoxLayout(self.centralwidget)
        self.vbox.setContentsMargins(18, 18, 18, 18)
        self.vbox.setSpacing(12)

        self.lbl_title = QtWidgets.QLabel("Турагентство", parent=self.centralwidget)
        font = self.lbl_title.font()
        font.setPointSize(14)
        font.setBold(True)
        self.lbl_title.setFont(font)
        self.lbl_title.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

        self.le_username = QtWidgets.QLineEdit(parent=self.centralwidget)
        self.le_username.setObjectName("le_username")
        self.le_username.setPlaceholderText("Логин")

        self.le_password = QtWidgets.QLineEdit(parent=self.centralwidget)
        self.le_password.setObjectName("le_password")
        self.le_password.setPlaceholderText("Пароль")
        self.le_password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)

        self.btn_login = QtWidgets.QPushButton("Войти", parent=self.centralwidget)
        self.btn_login.setObjectName("btn_login")

        self.vbox.addWidget(self.lbl_title)
        self.vbox.addWidget(self.le_username)
        self.vbox.addWidget(self.le_password)
        self.vbox.addWidget(self.btn_login)

        LoginWindow.setCentralWidget(self.centralwidget)
        QtCore.QMetaObject.connectSlotsByName(LoginWindow)
