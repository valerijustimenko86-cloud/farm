
from PyQt6 import QtCore, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1100, 720)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.vbox_main = QtWidgets.QVBoxLayout(self.centralwidget)
        self.vbox_main.setContentsMargins(12, 12, 12, 12)
        self.vbox_main.setSpacing(10)

        self.tabs_main = QtWidgets.QTabWidget(parent=self.centralwidget)
        self.tabs_main.setObjectName("tabs_main")

        self.tab_manager = QtWidgets.QWidget()
        self.tab_manager.setObjectName("tab_manager")
        self.vbox_m = QtWidgets.QVBoxLayout(self.tab_manager)
        self.vbox_m.setSpacing(10)

        self.gb_m_filter = QtWidgets.QGroupBox("Фильтр туров", parent=self.tab_manager)
        self.grid_m = QtWidgets.QGridLayout(self.gb_m_filter)

        self.le_m_country = QtWidgets.QLineEdit()
        self.le_m_country.setObjectName("le_m_country")
        self.le_m_country.setPlaceholderText("Страна")

        self.le_m_city = QtWidgets.QLineEdit()
        self.le_m_city.setObjectName("le_m_city")
        self.le_m_city.setPlaceholderText("Город")

        self.cb_m_operator = QtWidgets.QComboBox()
        self.cb_m_operator.setObjectName("cb_m_operator")

        self.de_m_from = QtWidgets.QDateEdit()
        self.de_m_from.setObjectName("de_m_from")
        self.de_m_from.setCalendarPopup(True)

        self.de_m_to = QtWidgets.QDateEdit()
        self.de_m_to.setObjectName("de_m_to")
        self.de_m_to.setCalendarPopup(True)

        self.sp_m_price_from = QtWidgets.QDoubleSpinBox()
        self.sp_m_price_from.setObjectName("sp_m_price_from")
        self.sp_m_price_from.setMaximum(9999999)
        self.sp_m_price_from.setDecimals(2)

        self.sp_m_price_to = QtWidgets.QDoubleSpinBox()
        self.sp_m_price_to.setObjectName("sp_m_price_to")
        self.sp_m_price_to.setMaximum(9999999)
        self.sp_m_price_to.setDecimals(2)
        self.sp_m_price_to.setValue(9999999)

        self.btn_m_filter = QtWidgets.QPushButton("Фильтровать")
        self.btn_m_filter.setObjectName("btn_m_filter")
        self.btn_m_reset = QtWidgets.QPushButton("Показать все")
        self.btn_m_reset.setObjectName("btn_m_reset")

        self.grid_m.addWidget(QtWidgets.QLabel("Страна"), 0, 0)
        self.grid_m.addWidget(self.le_m_country, 0, 1)
        self.grid_m.addWidget(QtWidgets.QLabel("Город"), 0, 2)
        self.grid_m.addWidget(self.le_m_city, 0, 3)

        self.grid_m.addWidget(QtWidgets.QLabel("Оператор"), 1, 0)
        self.grid_m.addWidget(self.cb_m_operator, 1, 1)
        self.grid_m.addWidget(QtWidgets.QLabel("Даты"), 1, 2)
        h_dates = QtWidgets.QHBoxLayout()
        h_dates.addWidget(self.de_m_from)
        h_dates.addWidget(self.de_m_to)
        self.grid_m.addLayout(h_dates, 1, 3)

        self.grid_m.addWidget(QtWidgets.QLabel("Цена"), 2, 0)
        h_price = QtWidgets.QHBoxLayout()
        h_price.addWidget(self.sp_m_price_from)
        h_price.addWidget(self.sp_m_price_to)
        self.grid_m.addLayout(h_price, 2, 1)

        h_btns = QtWidgets.QHBoxLayout()
        h_btns.addStretch()
        h_btns.addWidget(self.btn_m_filter)
        h_btns.addWidget(self.btn_m_reset)
        self.grid_m.addLayout(h_btns, 2, 3)

        self.tw_m_tours = QtWidgets.QTableWidget()
        self.tw_m_tours.setObjectName("tw_m_tours")
        self.tw_m_bookings = QtWidgets.QTableWidget()
        self.tw_m_bookings.setObjectName("tw_m_bookings")

        self.hbox_m_actions = QtWidgets.QHBoxLayout()
        self.btn_m_add_client = QtWidgets.QPushButton("Добавить клиента")
        self.btn_m_add_client.setObjectName("btn_m_add_client")
        self.btn_m_book = QtWidgets.QPushButton("Бронировать")
        self.btn_m_book.setObjectName("btn_m_book")
        self.btn_m_edit_booking = QtWidgets.QPushButton("Изменить")
        self.btn_m_edit_booking.setObjectName("btn_m_edit_booking")
        self.btn_m_cancel_booking = QtWidgets.QPushButton("Отменить")
        self.btn_m_cancel_booking.setObjectName("btn_m_cancel_booking")
        self.btn_m_pay = QtWidgets.QPushButton("Оплата")
        self.btn_m_pay.setObjectName("btn_m_pay")
        self.btn_m_receipt = QtWidgets.QPushButton("Чек")
        self.btn_m_receipt.setObjectName("btn_m_receipt")

        self.hbox_m_actions.addWidget(self.btn_m_add_client)
        self.hbox_m_actions.addStretch()
        self.hbox_m_actions.addWidget(self.btn_m_book)
        self.hbox_m_actions.addWidget(self.btn_m_edit_booking)
        self.hbox_m_actions.addWidget(self.btn_m_cancel_booking)
        self.hbox_m_actions.addWidget(self.btn_m_pay)
        self.hbox_m_actions.addWidget(self.btn_m_receipt)

        self.vbox_m.addWidget(self.gb_m_filter)
        self.vbox_m.addWidget(QtWidgets.QLabel("Доступные туры"))
        self.vbox_m.addWidget(self.tw_m_tours, 2)
        self.vbox_m.addLayout(self.hbox_m_actions)
        self.vbox_m.addWidget(QtWidgets.QLabel("Бронирования"))
        self.vbox_m.addWidget(self.tw_m_bookings, 2)

        self.tabs_main.addTab(self.tab_manager, "Менеджер")

        self.tab_director = QtWidgets.QWidget()
        self.tab_director.setObjectName("tab_director")
        self.vbox_d = QtWidgets.QVBoxLayout(self.tab_director)
        self.vbox_d.setSpacing(10)

        self.gb_d_analytics = QtWidgets.QGroupBox("Аналитика", parent=self.tab_director)
        self.grid_d = QtWidgets.QGridLayout(self.gb_d_analytics)

        self.de_d_from = QtWidgets.QDateEdit()
        self.de_d_from.setObjectName("de_d_from")
        self.de_d_from.setCalendarPopup(True)
        self.de_d_to = QtWidgets.QDateEdit()
        self.de_d_to.setObjectName("de_d_to")
        self.de_d_to.setCalendarPopup(True)

        self.btn_d_avg = QtWidgets.QPushButton("Средний чек (период)")
        self.btn_d_avg.setObjectName("btn_d_avg")
        self.lbl_d_avg_result = QtWidgets.QLabel("0.00")
        self.lbl_d_avg_result.setObjectName("lbl_d_avg_result")

        self.btn_d_repeat = QtWidgets.QPushButton("% повторных клиентов (6 мес)")
        self.btn_d_repeat.setObjectName("btn_d_repeat")
        self.lbl_d_repeat_result = QtWidgets.QLabel("0.00")
        self.lbl_d_repeat_result.setObjectName("lbl_d_repeat_result")

        self.grid_d.addWidget(QtWidgets.QLabel("С"), 0, 0)
        self.grid_d.addWidget(self.de_d_from, 0, 1)
        self.grid_d.addWidget(QtWidgets.QLabel("По"), 0, 2)
        self.grid_d.addWidget(self.de_d_to, 0, 3)
        self.grid_d.addWidget(self.btn_d_avg, 1, 0, 1, 2)
        self.grid_d.addWidget(self.lbl_d_avg_result, 1, 2, 1, 2)
        self.grid_d.addWidget(self.btn_d_repeat, 2, 0, 1, 2)
        self.grid_d.addWidget(self.lbl_d_repeat_result, 2, 2, 1, 2)

        self.tw_d_ops = QtWidgets.QTableWidget()
        self.tw_d_ops.setObjectName("tw_d_ops")

        self.hbox_d_ops = QtWidgets.QHBoxLayout()
        self.btn_d_add_op = QtWidgets.QPushButton("Добавить")
        self.btn_d_add_op.setObjectName("btn_d_add_op")
        self.btn_d_edit_op = QtWidgets.QPushButton("Изменить")
        self.btn_d_edit_op.setObjectName("btn_d_edit_op")
        self.btn_d_del_op = QtWidgets.QPushButton("Удалить")
        self.btn_d_del_op.setObjectName("btn_d_del_op")
        self.hbox_d_ops.addWidget(self.btn_d_add_op)
        self.hbox_d_ops.addWidget(self.btn_d_edit_op)
        self.hbox_d_ops.addWidget(self.btn_d_del_op)
        self.hbox_d_ops.addStretch()

        self.vbox_d.addWidget(self.gb_d_analytics)
        self.vbox_d.addWidget(QtWidgets.QLabel("Туроператоры"))
        self.vbox_d.addWidget(self.tw_d_ops, 1)
        self.vbox_d.addLayout(self.hbox_d_ops)

        self.tabs_main.addTab(self.tab_director, "Директор")

        self.tab_client = QtWidgets.QWidget()
        self.tab_client.setObjectName("tab_client")
        self.vbox_c = QtWidgets.QVBoxLayout(self.tab_client)
        self.vbox_c.setSpacing(10)

        self.hbox_c_filter = QtWidgets.QHBoxLayout()
        self.le_c_country = QtWidgets.QLineEdit()
        self.le_c_country.setObjectName("le_c_country")
        self.le_c_country.setPlaceholderText("Страна")
        self.le_c_city = QtWidgets.QLineEdit()
        self.le_c_city.setObjectName("le_c_city")
        self.le_c_city.setPlaceholderText("Город")
        self.btn_c_filter = QtWidgets.QPushButton("Фильтровать")
        self.btn_c_filter.setObjectName("btn_c_filter")
        self.btn_c_reset = QtWidgets.QPushButton("Показать все")
        self.btn_c_reset.setObjectName("btn_c_reset")
        self.hbox_c_filter.addWidget(self.le_c_country)
        self.hbox_c_filter.addWidget(self.le_c_city)
        self.hbox_c_filter.addWidget(self.btn_c_filter)
        self.hbox_c_filter.addWidget(self.btn_c_reset)
        self.hbox_c_filter.addStretch()

        self.tw_c_tours = QtWidgets.QTableWidget()
        self.tw_c_tours.setObjectName("tw_c_tours")

        self.gb_c_request = QtWidgets.QGroupBox("Заявка на бронирование", parent=self.tab_client)
        self.grid_c = QtWidgets.QGridLayout(self.gb_c_request)

        self.de_c_travel_date = QtWidgets.QDateEdit()
        self.de_c_travel_date.setObjectName("de_c_travel_date")
        self.de_c_travel_date.setCalendarPopup(True)

        self.sp_c_tourists = QtWidgets.QSpinBox()
        self.sp_c_tourists.setObjectName("sp_c_tourists")
        self.sp_c_tourists.setMinimum(1)
        self.sp_c_tourists.setMaximum(10)

        self.lw_c_services = QtWidgets.QListWidget()
        self.lw_c_services.setObjectName("lw_c_services")
        self.lw_c_services.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.MultiSelection)

        self.btn_c_request = QtWidgets.QPushButton("Оставить заявку")
        self.btn_c_request.setObjectName("btn_c_request")

        self.grid_c.addWidget(QtWidgets.QLabel("Желаемая дата"), 0, 0)
        self.grid_c.addWidget(self.de_c_travel_date, 0, 1)
        self.grid_c.addWidget(QtWidgets.QLabel("Туристов"), 0, 2)
        self.grid_c.addWidget(self.sp_c_tourists, 0, 3)
        self.grid_c.addWidget(QtWidgets.QLabel("Услуги"), 1, 0)
        self.grid_c.addWidget(self.lw_c_services, 1, 1, 1, 3)
        self.grid_c.addWidget(self.btn_c_request, 2, 3)

        self.tw_c_mybookings = QtWidgets.QTableWidget()
        self.tw_c_mybookings.setObjectName("tw_c_mybookings")

        self.vbox_c.addLayout(self.hbox_c_filter)
        self.vbox_c.addWidget(QtWidgets.QLabel("Доступные туры"))
        self.vbox_c.addWidget(self.tw_c_tours, 2)
        self.vbox_c.addWidget(self.gb_c_request)
        self.vbox_c.addWidget(QtWidgets.QLabel("Мои бронирования"))
        self.vbox_c.addWidget(self.tw_c_mybookings, 2)

        self.tabs_main.addTab(self.tab_client, "Клиент")

        self.vbox_main.addWidget(self.tabs_main)
        MainWindow.setCentralWidget(self.centralwidget)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
