
from PyQt6 import QtCore, QtWidgets

class Ui_EditDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("EditDialog")
        Dialog.resize(520, 420)

        self.vbox = QtWidgets.QVBoxLayout(Dialog)
        self.vbox.setContentsMargins(12, 12, 12, 12)
        self.vbox.setSpacing(10)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.setObjectName("stack")

        self.page_client = QtWidgets.QWidget()
        g1 = QtWidgets.QGridLayout(self.page_client)

        self.le_fio = QtWidgets.QLineEdit(); self.le_fio.setObjectName("le_fio")
        self.de_birth = QtWidgets.QDateEdit(); self.de_birth.setObjectName("de_birth"); self.de_birth.setCalendarPopup(True)
        self.le_phone = QtWidgets.QLineEdit(); self.le_phone.setObjectName("le_phone")
        self.le_email = QtWidgets.QLineEdit(); self.le_email.setObjectName("le_email")
        self.le_passport = QtWidgets.QLineEdit(); self.le_passport.setObjectName("le_passport")

        g1.addWidget(QtWidgets.QLabel("ФИО"), 0, 0); g1.addWidget(self.le_fio, 0, 1)
        g1.addWidget(QtWidgets.QLabel("Дата рождения"), 1, 0); g1.addWidget(self.de_birth, 1, 1)
        g1.addWidget(QtWidgets.QLabel("Телефон"), 2, 0); g1.addWidget(self.le_phone, 2, 1)
        g1.addWidget(QtWidgets.QLabel("Email"), 3, 0); g1.addWidget(self.le_email, 3, 1)
        g1.addWidget(QtWidgets.QLabel("Паспорт"), 4, 0); g1.addWidget(self.le_passport, 4, 1)
        g1.setRowStretch(5, 1)

        self.stack.addWidget(self.page_client)

        self.page_operator = QtWidgets.QWidget()
        g2 = QtWidgets.QGridLayout(self.page_operator)

        self.le_op_name = QtWidgets.QLineEdit(); self.le_op_name.setObjectName("le_op_name")
        self.le_op_phone = QtWidgets.QLineEdit(); self.le_op_phone.setObjectName("le_op_phone")
        self.le_op_email = QtWidgets.QLineEdit(); self.le_op_email.setObjectName("le_op_email")

        g2.addWidget(QtWidgets.QLabel("Название"), 0, 0); g2.addWidget(self.le_op_name, 0, 1)
        g2.addWidget(QtWidgets.QLabel("Телефон"), 1, 0); g2.addWidget(self.le_op_phone, 1, 1)
        g2.addWidget(QtWidgets.QLabel("Email"), 2, 0); g2.addWidget(self.le_op_email, 2, 1)
        g2.setRowStretch(3, 1)

        self.stack.addWidget(self.page_operator)

        self.page_booking = QtWidgets.QWidget()
        g3 = QtWidgets.QGridLayout(self.page_booking)

        self.cb_b_client = QtWidgets.QComboBox(); self.cb_b_client.setObjectName("cb_b_client")
        self.cb_b_tour = QtWidgets.QComboBox(); self.cb_b_tour.setObjectName("cb_b_tour")
        self.de_b_travel = QtWidgets.QDateEdit(); self.de_b_travel.setObjectName("de_b_travel"); self.de_b_travel.setCalendarPopup(True)
        self.sp_b_tourists = QtWidgets.QSpinBox(); self.sp_b_tourists.setObjectName("sp_b_tourists"); self.sp_b_tourists.setRange(1, 50)
        self.lw_b_services = QtWidgets.QListWidget(); self.lw_b_services.setObjectName("lw_b_services")
        self.lw_b_services.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.MultiSelection)
        self.cb_b_status = QtWidgets.QComboBox(); self.cb_b_status.setObjectName("cb_b_status")
        self.cb_b_status.addItems(["PENDING", "CONFIRMED", "CANCELLED", "PAID"])

        g3.addWidget(QtWidgets.QLabel("Клиент"), 0, 0); g3.addWidget(self.cb_b_client, 0, 1)
        g3.addWidget(QtWidgets.QLabel("Тур"), 1, 0); g3.addWidget(self.cb_b_tour, 1, 1)
        g3.addWidget(QtWidgets.QLabel("Дата поездки"), 2, 0); g3.addWidget(self.de_b_travel, 2, 1)
        g3.addWidget(QtWidgets.QLabel("Туристов"), 3, 0); g3.addWidget(self.sp_b_tourists, 3, 1)
        g3.addWidget(QtWidgets.QLabel("Услуги"), 4, 0); g3.addWidget(self.lw_b_services, 4, 1)
        g3.addWidget(QtWidgets.QLabel("Статус"), 5, 0); g3.addWidget(self.cb_b_status, 5, 1)
        g3.setRowStretch(6, 1)

        self.stack.addWidget(self.page_booking)

        self.hbox_btn = QtWidgets.QHBoxLayout()
        self.hbox_btn.addStretch()
        self.btn_save = QtWidgets.QPushButton("Сохранить"); self.btn_save.setObjectName("btn_save")
        self.btn_cancel = QtWidgets.QPushButton("Отмена"); self.btn_cancel.setObjectName("btn_cancel")
        self.hbox_btn.addWidget(self.btn_save)
        self.hbox_btn.addWidget(self.btn_cancel)

        self.vbox.addWidget(self.stack)
        self.vbox.addLayout(self.hbox_btn)

        QtCore.QMetaObject.connectSlotsByName(Dialog)
