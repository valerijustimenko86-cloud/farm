
DROP DATABASE IF EXISTS travel_agency;
CREATE DATABASE travel_agency CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE travel_agency;

CREATE TABLE clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(120) NOT NULL,
  birth_date DATE NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  passport VARCHAR(30) NOT NULL,
  UNIQUE KEY uq_clients_email (email),
  UNIQUE KEY uq_clients_passport (passport)
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  role ENUM('director','manager','client') NOT NULL,
  client_id INT NULL,
  UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_client
    FOREIGN KEY (client_id) REFERENCES clients(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tour_operators (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(120) NULL,
  UNIQUE KEY uq_ops_name (name)
) ENGINE=InnoDB;

CREATE TABLE tours (
  id INT AUTO_INCREMENT PRIMARY KEY,
  operator_id INT NOT NULL,
  country VARCHAR(80) NOT NULL,
  city VARCHAR(80) NOT NULL,
  depart_date DATE NOT NULL,
  duration_days INT NOT NULL,
  base_price DECIMAL(10,2) NOT NULL,
  seats_total INT NOT NULL DEFAULT 30,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  INDEX ix_tours_filters (country, city, depart_date, base_price),
  CONSTRAINT fk_tours_operator
    FOREIGN KEY (operator_id) REFERENCES tour_operators(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  UNIQUE KEY uq_services_name (name)
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  tour_id INT NOT NULL,
  tourists_count INT NOT NULL DEFAULT 1,
  travel_date DATE NOT NULL,
  status ENUM('PENDING','CONFIRMED','CANCELLED','PAID') NOT NULL DEFAULT 'PENDING',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  note VARCHAR(255) NULL,
  CONSTRAINT fk_bookings_client
    FOREIGN KEY (client_id) REFERENCES clients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_bookings_tour
    FOREIGN KEY (tour_id) REFERENCES tours(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE booking_services (
  booking_id INT NOT NULL,
  service_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  PRIMARY KEY (booking_id, service_id),
  CONSTRAINT fk_bs_booking
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_bs_service
    FOREIGN KEY (service_id) REFERENCES services(id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  method ENUM('CASH','CARD','ONLINE') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  pay_status ENUM('PAID','VOID') NOT NULL DEFAULT 'PAID',
  UNIQUE KEY uq_payments_booking (booking_id),
  CONSTRAINT fk_payments_booking
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE OR REPLACE VIEW v_tours AS
SELECT
  t.id AS tour_id,
  o.name AS operator_name,
  t.country, t.city, t.depart_date, t.duration_days,
  t.base_price, t.seats_total, t.is_active
FROM tours t
JOIN tour_operators o ON o.id = t.operator_id;

CREATE OR REPLACE VIEW v_bookings AS
SELECT
  b.id AS booking_id,
  c.fio AS client_fio,
  c.phone AS client_phone,
  c.email AS client_email,
  o.name AS operator_name,
  t.country, t.city, t.depart_date, t.duration_days, t.base_price,
  b.tourists_count,
  b.travel_date,
  b.status,
  b.created_at
FROM bookings b
JOIN clients c ON c.id = b.client_id
JOIN tours t ON t.id = b.tour_id
JOIN tour_operators o ON o.id = t.operator_id;

DELIMITER $$

CREATE PROCEDURE sp_avg_tour_cost(IN p_from DATE, IN p_to DATE)
BEGIN
  SELECT
    CASE
      WHEN COUNT(*) = 0 THEN 0.00
      ELSE ROUND(SUM(p.amount) / COUNT(*), 2)
    END AS avg_tour_cost
  FROM payments p
  WHERE p.pay_status = 'PAID'
    AND DATE(p.paid_at) BETWEEN p_from AND p_to;
END $$

CREATE FUNCTION fn_repeat_clients_pct_6m()
RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
  DECLARE total_clients INT DEFAULT 0;
  DECLARE repeat_clients INT DEFAULT 0;

  SELECT COUNT(DISTINCT b.client_id) INTO total_clients
  FROM bookings b
  JOIN payments p ON p.booking_id = b.id AND p.pay_status='PAID'
  WHERE p.paid_at >= (NOW() - INTERVAL 6 MONTH);

  SELECT COUNT(*) INTO repeat_clients
  FROM (
    SELECT b.client_id
    FROM bookings b
    JOIN payments p ON p.booking_id = b.id AND p.pay_status='PAID'
    WHERE p.paid_at >= (NOW() - INTERVAL 6 MONTH)
    GROUP BY b.client_id
    HAVING COUNT(*) > 1
  ) x;

  RETURN CASE
    WHEN total_clients = 0 THEN 0.00
    ELSE ROUND(repeat_clients * 100.0 / total_clients, 2)
  END;
END $$

DELIMITER ;

INSERT INTO clients (fio, birth_date, phone, email, passport) VALUES
('Иванов Иван Иванович', '1998-03-12', '+79990000001', 'ivanov@mail.ru', '4510 123456'),
('Петров Пётр Петрович', '1995-07-21', '+79990000002', 'petrov@mail.ru', '4510 654321'),
('Сидорова Анна Сергеевна', '2001-11-05', '+79990000003', 'sidorova@mail.ru', '4510 111222');

INSERT INTO users (username, pass_hash, role, client_id) VALUES
('director', '123', 'director', NULL),
('manager',  '123', 'manager',  NULL),
('client1',  '123', 'client',   1),
('client2',  '123', 'client',   2),
('client3',  '123', 'client',   3);

INSERT INTO tour_operators (name, phone, email) VALUES
('SunWave Travel', '+79991112233', 'ops1@sunwave.ru'),
('NorthLine Tours', '+79994445566', 'ops2@northline.ru'),
('CityBreak', '+79997778899', 'ops3@citybreak.ru');

INSERT INTO tours (operator_id, country, city, depart_date, duration_days, base_price, seats_total, is_active) VALUES
(1, 'Турция', 'Анталья', '2026-05-10', 7, 85000.00, 30, 1),
(2, 'ОАЭ', 'Дубай',     '2026-04-18', 5, 120000.00, 25, 1),
(3, 'Италия', 'Рим',    '2026-06-02', 6, 150000.00, 20, 1);

INSERT INTO services (name, price) VALUES
('Страховка', 3000.00),
('Трансфер',  2500.00),
('Экскурсии', 8000.00);

INSERT INTO bookings (client_id, tour_id, tourists_count, travel_date, status, note) VALUES
(1, 1, 2, '2026-05-10', 'CONFIRMED', 'Хочу номер с видом на море'),
(2, 2, 1, '2026-04-18', 'PENDING',   NULL),
(3, 3, 1, '2026-06-02', 'CANCELLED', 'Передумал');

INSERT INTO booking_services (booking_id, service_id, qty) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 1, 1);

INSERT INTO payments (booking_id, method, amount, pay_status) VALUES
(1, 'CARD',  (2 * 85000.00) + (2 * 3000.00) + (1 * 2500.00), 'PAID');
