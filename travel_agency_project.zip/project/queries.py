
Q = {
    "auth": "SELECT id, role, client_id FROM users WHERE username=%s AND pass_hash=%s",
    "ops_list": "SELECT id, name FROM tour_operators ORDER BY name",
    "ops_table": "SELECT id, name, phone, email FROM tour_operators ORDER BY name",
    "ops_insert": "INSERT INTO tour_operators(name, phone, email) VALUES(%s,%s,%s)",
    "ops_update": "UPDATE tour_operators SET name=%s, phone=%s, email=%s WHERE id=%s",
    "ops_delete": "DELETE FROM tour_operators WHERE id=%s",
    "clients_list": "SELECT id, fio FROM clients ORDER BY fio",
    "clients_insert": "INSERT INTO clients(fio,birth_date,phone,email,passport) VALUES(%s,%s,%s,%s,%s)",
    "clients_update": "UPDATE clients SET fio=%s,birth_date=%s,phone=%s,email=%s,passport=%s WHERE id=%s",
    "tours_base": "SELECT * FROM v_tours WHERE is_active=1 ORDER BY depart_date",
    "tours_filter_manager": """
        SELECT * FROM v_tours
        WHERE is_active=1
          AND (%s='' OR country=%s)
          AND (%s='' OR city=%s)
          AND (%s='ALL' OR operator_name=%s)
          AND depart_date BETWEEN %s AND %s
          AND base_price BETWEEN %s AND %s
        ORDER BY depart_date
    """,
    "tours_filter_client": """
        SELECT * FROM v_tours
        WHERE is_active=1
          AND (%s='' OR country=%s)
          AND (%s='' OR city=%s)
        ORDER BY depart_date
    """,
    "bookings_table": "SELECT * FROM v_bookings ORDER BY created_at DESC",
    "booking_insert": """
        INSERT INTO bookings(client_id,tour_id,tourists_count,travel_date,status,note)
        VALUES(%s,%s,%s,%s,%s,%s)
    """,
    "booking_update": """
        UPDATE bookings
        SET client_id=%s, tour_id=%s, tourists_count=%s, travel_date=%s, status=%s, note=%s
        WHERE id=%s
    """,
    "booking_set_status": "UPDATE bookings SET status=%s WHERE id=%s",
    "bs_clear": "DELETE FROM booking_services WHERE booking_id=%s",
    "bs_add": "INSERT INTO booking_services(booking_id, service_id, qty) VALUES(%s,%s,%s)",
    "services_list": "SELECT id, name, price FROM services ORDER BY name",
    "calc_total": """
        SELECT
          (t.base_price * b.tourists_count) +
          IFNULL((
            SELECT SUM(s.price * bs.qty)
            FROM booking_services bs
            JOIN services s ON s.id=bs.service_id
            WHERE bs.booking_id=b.id
          ), 0) AS total_amount
        FROM bookings b
        JOIN tours t ON t.id=b.tour_id
        WHERE b.id=%s
    """,
    "payment_upsert": """
        INSERT INTO payments(booking_id, method, amount, pay_status)
        VALUES(%s,%s,%s,'PAID')
        ON DUPLICATE KEY UPDATE method=VALUES(method), amount=VALUES(amount), pay_status='PAID', paid_at=NOW()
    """,
    "receipt": """
        SELECT
          b.id AS booking_id,
          c.fio, c.phone, c.email,
          o.name AS operator_name,
          t.country, t.city, b.travel_date, b.tourists_count,
          t.base_price,
          p.method, p.amount, p.paid_at
        FROM bookings b
        JOIN clients c ON c.id=b.client_id
        JOIN tours t ON t.id=b.tour_id
        JOIN tour_operators o ON o.id=t.operator_id
        LEFT JOIN payments p ON p.booking_id=b.id AND p.pay_status='PAID'
        WHERE b.id=%s
    """,
    "receipt_services": """
        SELECT s.name, s.price, bs.qty, (s.price*bs.qty) AS line_sum
        FROM booking_services bs
        JOIN services s ON s.id=bs.service_id
        WHERE bs.booking_id=%s
        ORDER BY s.name
    """,
    "director_repeat_pct": "SELECT fn_repeat_clients_pct_6m() AS pct",
}
