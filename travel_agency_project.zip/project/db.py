
import pymysql
from pymysql.cursors import DictCursor
from config import DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME

class DB:
    def __init__(self):
        self.conn = None

    def connect(self):
        if self.conn:
            return
        self.conn = pymysql.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            charset="utf8mb4",
            cursorclass=DictCursor,
            autocommit=True,
        )

    def fetchall(self, sql: str, params: tuple = ()):
        self.connect()
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()

    def fetchone(self, sql: str, params: tuple = ()):
        self.connect()
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchone()

    def execute(self, sql: str, params: tuple = ()):
        self.connect()
        with self.conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.lastrowid

    def callproc_one(self, proc_name: str, params: tuple = ()):
        self.connect()
        with self.conn.cursor() as cur:
            cur.callproc(proc_name, params)
            res = cur.fetchall()
            return res[0] if res else None
