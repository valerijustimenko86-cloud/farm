
DROP DATABASE IF EXISTS beauty_salon;
CREATE DATABASE beauty_salon CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE beauty_salon;

CREATE TABLE clients(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  birth_date DATE NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  registration_date DATE NOT NULL,
  UNIQUE KEY uq_clients_email(email)
) ENGINE=InnoDB;

CREATE TABLE masters(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  specialization VARCHAR(80) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  hire_date DATE NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_masters_email(email)
) ENGINE=InnoDB;

CREATE TABLE service_categories(
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(120) NOT NULL,
  description VARCHAR(255) NOT NULL,
  UNIQUE KEY uq_cat_name(category_name)
) ENGINE=InnoDB;

CREATE TABLE services(
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  service_name VARCHAR(140) NOT NULL,
  description VARCHAR(255) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  duration_minutes INT NOT NULL,
  required_materials VARCHAR(255) NOT NULL,
  CONSTRAINT fk_services_cat FOREIGN KEY(category_id) REFERENCES service_categories(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_services_cat(category_id)
) ENGINE=InnoDB;

CREATE TABLE master_schedule(
  id INT AUTO_INCREMENT PRIMARY KEY,
  master_id INT NOT NULL,
  weekday ENUM('Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье') NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  slot_duration_minutes INT NOT NULL DEFAULT 60,
  CONSTRAINT fk_sched_master FOREIGN KEY(master_id) REFERENCES masters(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  UNIQUE KEY uq_sched(master_id, weekday)
) ENGINE=InnoDB;

CREATE TABLE appointments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  master_id INT NOT NULL,
  service_id INT NOT NULL,
  appointment_dt DATETIME NOT NULL,
  status ENUM('Запланирован','Клиент пришёл','Завершён','Отменён') NOT NULL DEFAULT 'Запланирован',
  total_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  CONSTRAINT fk_appt_client FOREIGN KEY(client_id) REFERENCES clients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_master FOREIGN KEY(master_id) REFERENCES masters(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appt_service FOREIGN KEY(service_id) REFERENCES services(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  UNIQUE KEY uq_master_dt(master_id, appointment_dt),
  INDEX ix_appt_status(status),
  INDEX ix_appt_dt(appointment_dt)
) ENGINE=InnoDB;

CREATE TABLE gift_certificates(
  id INT AUTO_INCREMENT PRIMARY KEY,
  certificate_number VARCHAR(40) NOT NULL,
  nominal_value DECIMAL(10,2) NOT NULL,
  remaining_balance DECIMAL(10,2) NOT NULL,
  issue_date DATE NOT NULL,
  expiration_date DATE NOT NULL,
  purchaser_name VARCHAR(150) NOT NULL,
  recipient_name VARCHAR(150) NOT NULL,
  status ENUM('Активен','Использован','Просрочен') NOT NULL DEFAULT 'Активен',
  UNIQUE KEY uq_cert_num(certificate_number)
) ENGINE=InnoDB;

CREATE TABLE payments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  payment_date DATE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('Наличные','Карта','Онлайн') NOT NULL,
  pay_status ENUM('Оплачен','Возврат') NOT NULL DEFAULT 'Оплачен',
  UNIQUE KEY uq_pay_appt(appointment_id),
  CONSTRAINT fk_pay_appt FOREIGN KEY(appointment_id) REFERENCES appointments(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','master','client') NOT NULL,
  client_id INT NULL,
  master_id INT NULL,
  UNIQUE KEY uq_users_username(username),
  CONSTRAINT fk_users_client FOREIGN KEY(client_id) REFERENCES clients(id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_users_master FOREIGN KEY(master_id) REFERENCES masters(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE OR REPLACE VIEW v_appointments AS
SELECT
  a.id AS appt_id,
  a.appointment_dt,
  a.status,
  a.total_price,
  a.notes,
  c.id AS client_id,
  c.fio AS client_fio,
  c.phone AS client_phone,
  m.id AS master_id,
  m.fio AS master_fio,
  m.specialization,
  s.id AS service_id,
  s.service_name,
  s.price AS base_price,
  sc.category_name
FROM appointments a
JOIN clients c ON c.id=a.client_id
JOIN masters m ON m.id=a.master_id
JOIN services s ON s.id=a.service_id
JOIN service_categories sc ON sc.id=s.category_id;

DELIMITER $$

CREATE PROCEDURE sp_avg_check(IN p_from DATE, IN p_to DATE)
BEGIN
  SELECT
    CASE WHEN COUNT(*)=0 THEN 0.00 ELSE ROUND(SUM(total_price)/COUNT(*),2) END AS avg_check,
    COUNT(*) AS completed_cnt,
    ROUND(SUM(total_price),2) AS revenue
  FROM appointments
  WHERE status='Завершён' AND DATE(appointment_dt) BETWEEN p_from AND p_to;
END $$

CREATE FUNCTION fn_repeat_clients(p_from DATE, p_to DATE)
RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
  DECLARE total_clients INT;
  DECLARE repeat_clients INT;
  SELECT COUNT(DISTINCT client_id) INTO total_clients
  FROM appointments
  WHERE DATE(appointment_dt) BETWEEN p_from AND p_to;

  SELECT COUNT(*) INTO repeat_clients
  FROM (
    SELECT client_id
    FROM appointments
    WHERE DATE(appointment_dt) BETWEEN p_from AND p_to
    GROUP BY client_id
    HAVING COUNT(*) > 1
  ) t;

  RETURN CASE WHEN total_clients=0 THEN 0.00 ELSE ROUND(100*repeat_clients/total_clients,2) END;
END $$

DELIMITER ;

INSERT INTO clients(fio,birth_date,phone,email,registration_date) VALUES
('Иванова Анна Сергеевна','1990-05-15','+7 (495) 123-45-67','ivanova@mail.ru','2023-01-10'),
('Петров Дмитрий Игоревич','1985-08-22','+7 (495) 234-56-78','petrov@gmail.com','2023-02-15'),
('Сидорова Елена Викторовна','1995-11-30','+7 (495) 345-67-89','sidorova@yandex.ru','2023-03-20');

INSERT INTO masters(fio,specialization,phone,email,hire_date,is_active) VALUES
('Волкова Марина Александровна','Маникюр','+7 (495) 111-11-11','volkova@salon.ru','2022-01-15',1),
('Орлов Сергей Петрович','Барбер','+7 (495) 222-22-22','orlov@salon.ru','2021-03-10',1),
('Лебедева Татьяна Ивановна','Косметолог','+7 (495) 333-33-33','lebedeva@salon.ru','2022-06-20',1);

INSERT INTO service_categories(category_name,description) VALUES
('Маникюр и педикюр','Услуги по уходу за ногтями рук и ног'),
('Парикмахерские услуги','Стрижки, окрашивание, укладки'),
('Косметология','Уходовые процедуры для лица и тела');

INSERT INTO services(category_id,service_name,description,price,duration_minutes,required_materials) VALUES
(1,'Маникюр комбинированный','Обрезной маникюр с покрытием гель-лаком',2500.00,90,'Гель-лак, база, топ, дезинфектор'),
(1,'Педикюр аппаратный','Обработка стоп и ногтей аппаратом',3000.00,120,'Керамические насадки, крем для ног'),
(2,'Мужская стрижка','Стрижка машинкой и ножницами',1500.00,60,'Машинка, ножницы, стайлинг'),
(2,'Окрашивание','Окрашивание волос средней длины',4000.00,120,'Краска, перчатки, оксид'),
(3,'Чистка лица','Ультразвуковая чистка лица',3500.00,80,'Гель, маска, антисептик');

INSERT INTO master_schedule(master_id,weekday,start_time,end_time,slot_duration_minutes) VALUES
(1,'Понедельник','09:00:00','18:00:00',60),
(1,'Вторник','10:00:00','19:00:00',60),
(1,'Среда','09:00:00','18:00:00',60),
(2,'Понедельник','10:00:00','20:00:00',60),
(2,'Четверг','10:00:00','20:00:00',60),
(3,'Пятница','09:00:00','17:00:00',60);

INSERT INTO appointments(client_id,master_id,service_id,appointment_dt,status,total_price,notes) VALUES
(1,1,1,'2023-11-15 10:00:00','Завершён',2500.00,'Клиентка хочет французский маникюр'),
(2,2,3,'2023-11-16 14:30:00','Запланирован',1500.00,'Под ноль с переходом'),
(3,3,5,'2023-11-17 11:00:00','Клиент пришёл',3500.00,'Чувствительная кожа');

INSERT INTO payments(appointment_id,payment_date,amount,payment_method,pay_status) VALUES
(1,'2023-11-15',2500.00,'Карта','Оплачен'),
(2,'2023-11-16',1500.00,'Наличные','Оплачен'),
(3,'2023-11-17',3500.00,'Карта','Оплачен');

INSERT INTO gift_certificates(certificate_number,nominal_value,remaining_balance,issue_date,expiration_date,purchaser_name,recipient_name,status) VALUES
('GC-001-2023',5000.00,2500.00,'2023-10-15','2024-04-15','Иванов П.С.','Сидорова Е.В.','Активен'),
('GC-002-2023',3000.00,0.00,'2023-09-20','2024-03-20','Петрова А.И.','Козлов А.М.','Использован'),
('GC-003-2023',10000.00,10000.00,'2023-11-01','2024-05-01','Соколов В.П.','Волкова М.А.','Активен');

INSERT INTO users(username,pass_hash,role,client_id,master_id) VALUES
('admin','123','admin',NULL,NULL),
('master1','123','master',NULL,1),
('master2','123','master',NULL,2),
('client1','123','client',1,NULL),
('client2','123','client',2,NULL);
