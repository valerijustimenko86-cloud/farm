
from PyQt6.QtCore import QDate, QDateTime, Qt
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem, QAbstractItemView
from ui_py.ui_main import Ui_MainWindow
from db import DB
from queries import Q
from windows.edit_dialog import EditDialog, WEEKDAYS

STYLESHEET = """
QWidget { background:
QLineEdit, QComboBox, QDateEdit, QDateTimeEdit, QTimeEdit, QSpinBox {
  background:
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QDateTimeEdit:focus, QTimeEdit:focus { border: 1px solid
QPushButton { background:
QPushButton:hover { background:
QPushButton:pressed { background:
QTableWidget { background:
QHeaderView::section { background:
QTableWidget::item:selected { background:
"""

STATUSES = ['Запланирован','Клиент пришёл','Завершён','Отменён']

class MainWindow(QMainWindow):
    def __init__(self, role, client_id, master_id, username):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setStyleSheet(STYLESHEET)
        self.db = DB()
        self.role = role
        self.client_id = client_id
        self.master_id = master_id
        self.username = username
        self._setup_tables()
        self._init_defaults()
        self._load_lists()
        self.role_apply(role)
        self._bind()
        self.reload_all()

    def _setup_tables(self):
        for tw in [self.ui.tw_clients, self.ui.tw_schedule, self.ui.tw_appts_admin, self.ui.tw_master_appts, self.ui.tw_client_appts]:
            tw.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            tw.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            tw.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            tw.setAlternatingRowColors(True)

    def _init_defaults(self):
        today = QDate.currentDate()
        self.ui.de_st_from.setDate(today.addDays(-30))
        self.ui.de_st_to.setDate(today)
        self.ui.de_cl_date.setDate(today.addDays(1))
        self.ui.cb_a_status.clear()
        self.ui.cb_m_status.clear()
        for s in STATUSES:
            self.ui.cb_a_status.addItem(s)
            self.ui.cb_m_status.addItem(s)

    def _bind(self):
        self.ui.btn_c_add.clicked.connect(self.client_add)
        self.ui.btn_c_edit.clicked.connect(self.client_edit)
        self.ui.btn_c_del.clicked.connect(self.client_delete)

        self.ui.btn_s_add.clicked.connect(self.schedule_add)
        self.ui.btn_s_edit.clicked.connect(self.schedule_edit)
        self.ui.btn_s_del.clicked.connect(self.schedule_delete)

        self.ui.btn_a_set_status.clicked.connect(self.admin_set_status)
        self.ui.btn_a_payment.clicked.connect(self.admin_payment)

        self.ui.btn_st_calc.clicked.connect(self.calc_stats)

        self.ui.btn_m_apply.clicked.connect(self.master_set_price)
        self.ui.btn_m_set_status.clicked.connect(self.master_set_status)

        self.ui.btn_cl_slots.clicked.connect(self.client_load_slots)
        self.ui.btn_cl_book.clicked.connect(self.client_book)
        self.ui.btn_cl_cancel.clicked.connect(self.client_cancel)
        self.ui.cb_cl_service.currentIndexChanged.connect(self.client_update_price)

    def role_apply(self, role):
        iA = self.ui.tabs_main.indexOf(self.ui.tab_admin)
        iM = self.ui.tabs_main.indexOf(self.ui.tab_master)
        iC = self.ui.tabs_main.indexOf(self.ui.tab_client)
        self.ui.tabs_main.setTabVisible(iA, role == "admin")
        self.ui.tabs_main.setTabVisible(iM, role == "master")
        self.ui.tabs_main.setTabVisible(iC, role == "client")
        if role == "admin":
            self.ui.tabs_main.setCurrentIndex(iA)
        elif role == "master":
            self.ui.tabs_main.setCurrentIndex(iM)
        else:
            self.ui.tabs_main.setCurrentIndex(iC)

    def _load_lists(self):
        try:
            self.masters = self.db.fetchall(Q["masters_all"])
            self.services = self.db.fetchall(Q["services_all"])

            self.ui.cb_cl_master.clear()
            for m in self.masters:
                self.ui.cb_cl_master.addItem(f'{m["fio"]} | {m["specialization"]}', m["id"])

            self.ui.cb_cl_service.clear()
            for s in self.services:
                self.ui.cb_cl_service.addItem(f'{s["service_name"]} | {float(s["price"]):.2f} ₽', s["id"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_table(self, tw, rows, headers, keys):
        tw.clear()
        tw.setColumnCount(len(headers))
        tw.setRowCount(len(rows))
        tw.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, k in enumerate(keys):
                v = row.get(k)
                tw.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        tw.resizeColumnsToContents()

    def selected_id(self, tw, col=0):
        items = tw.selectedItems()
        if not items:
            return None
        row = items[0].row()
        try:
            return int(tw.item(row, col).text())
        except:
            return None

    def reload_all(self):
        if self.role == "admin":
            self.reload_clients()
            self.reload_schedule()
            self.reload_admin_appts()
        if self.role == "master":
            self.reload_master_appts()
        if self.role == "client":
            self.reload_client_appts()
            self.client_update_price()

    def reload_clients(self):
        rows = self.db.fetchall(Q["clients_all"])
        self.load_table(self.ui.tw_clients, rows,
                        ["ID","ФИО","Дата рожд.","Телефон","Email","Регистрация"],
                        ["id","fio","birth_date","phone","email","registration_date"])

    def client_add(self):
        dlg = EditDialog(EditDialog.MODE_CLIENT, db=self.db, parent=self)
        if dlg.exec():
            self.reload_clients()

    def client_edit(self):
        cid = self.selected_id(self.ui.tw_clients, 0)
        if not cid:
            QMessageBox.warning(self, "Клиенты", "Выбери клиента.")
            return
        row = self.db.fetchone("SELECT * FROM clients WHERE id=%s", (cid,))
        dlg = EditDialog(EditDialog.MODE_CLIENT, db=self.db, record=row, parent=self)
        if dlg.exec():
            self.reload_clients()

    def client_delete(self):
        cid = self.selected_id(self.ui.tw_clients, 0)
        if not cid:
            QMessageBox.warning(self, "Клиенты", "Выбери клиента.")
            return
        try:
            self.db.execute(Q["client_delete"], (cid,))
            self.reload_clients()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def reload_schedule(self):
        rows = self.db.fetchall(Q["schedule_all"])
        self.load_table(self.ui.tw_schedule, rows,
                        ["ID","Мастер","master_id","День","Начало","Конец","Слот, мин"],
                        ["id","master_fio","master_id","weekday","start_time","end_time","slot_duration_minutes"])

    def schedule_add(self):
        dlg = EditDialog(EditDialog.MODE_SCHEDULE, db=self.db, masters=self.masters, parent=self)
        if dlg.exec():
            self.reload_schedule()

    def schedule_edit(self):
        sid = self.selected_id(self.ui.tw_schedule, 0)
        if not sid:
            QMessageBox.warning(self, "Расписание", "Выбери строку расписания.")
            return
        row = self.db.fetchone("SELECT * FROM master_schedule WHERE id=%s", (sid,))
        dlg = EditDialog(EditDialog.MODE_SCHEDULE, db=self.db, record=row, masters=self.masters, parent=self)
        if dlg.exec():
            self.reload_schedule()

    def schedule_delete(self):
        sid = self.selected_id(self.ui.tw_schedule, 0)
        if not sid:
            QMessageBox.warning(self, "Расписание", "Выбери строку расписания.")
            return
        try:
            self.db.execute(Q["schedule_delete"], (sid,))
            self.reload_schedule()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def reload_admin_appts(self):
        rows = self.db.fetchall(Q["appt_all"])
        self.load_table(self.ui.tw_appts_admin, rows,
                        ["ID","Дата/время","Статус","Цена","Клиент","Телефон","Мастер","Услуга","Категория"],
                        ["appt_id","appointment_dt","status","total_price","client_fio","client_phone","master_fio","service_name","category_name"])

    def admin_set_status(self):
        appt_id = self.selected_id(self.ui.tw_appts_admin, 0)
        if not appt_id:
            QMessageBox.warning(self, "Записи", "Выбери запись.")
            return
        st = self.ui.cb_a_status.currentText()
        try:
            self.db.execute(Q["appt_status_update"], (st, appt_id))
            self.reload_admin_appts()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def admin_payment(self):
        appt_id = self.selected_id(self.ui.tw_appts_admin, 0)
        if not appt_id:
            QMessageBox.warning(self, "Оплата", "Выбери запись.")
            return
        try:
            row = self.db.fetchone("SELECT total_price, DATE(appointment_dt) AS d FROM appointments WHERE id=%s", (appt_id,))
            if not row:
                return
            amount = float(row["total_price"])
            pay_date = str(row["d"])
            self.db.execute(Q["payment_upsert"], (appt_id, pay_date, amount, "Карта"))
            QMessageBox.information(self, "Оплата", "Оплата сохранена (Карта).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def calc_stats(self):
        try:
            d1 = self.ui.de_st_from.date().toString("yyyy-MM-dd")
            d2 = self.ui.de_st_to.date().toString("yyyy-MM-dd")
            res = self.db.callproc_one("sp_avg_check", (d1, d2))
            pct = self.db.fetchone(Q["repeat_fn"], (d1, d2))
            self.ui.lbl_avg.setText(str(res["avg_check"] if res else 0.00))
            self.ui.lbl_rev.setText(str(res["revenue"] if res else 0.00))
            self.ui.lbl_rep.setText(str(pct["pct"] if pct else 0.00))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def reload_master_appts(self):
        rows = self.db.fetchall(Q["appt_by_master"], (self.master_id,))
        self.load_table(self.ui.tw_master_appts, rows,
                        ["ID","Дата/время","Статус","Цена","Клиент","Услуга","База"],
                        ["appt_id","appointment_dt","status","total_price","client_fio","service_name","base_price"])

    def master_set_price(self):
        appt_id = self.selected_id(self.ui.tw_master_appts, 0)
        if not appt_id:
            QMessageBox.warning(self, "Мастер", "Выбери запись.")
            return
        try:
            price = float(self.ui.le_m_price.text().replace(",", ".").strip())
        except:
            QMessageBox.warning(self, "Мастер", "Введи корректную цену.")
            return
        notes = self.ui.le_m_notes.text().strip()
        try:
            self.db.execute(Q["appt_price_update"], (price, notes, appt_id))
            self.reload_master_appts()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def master_set_status(self):
        appt_id = self.selected_id(self.ui.tw_master_appts, 0)
        if not appt_id:
            QMessageBox.warning(self, "Мастер", "Выбери запись.")
            return
        st = self.ui.cb_m_status.currentText()
        try:
            self.db.execute(Q["appt_status_update"], (st, appt_id))
            self.reload_master_appts()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def reload_client_appts(self):
        rows = self.db.fetchall(Q["appt_by_client"], (self.client_id,))
        self.load_table(self.ui.tw_client_appts, rows,
                        ["ID","Дата/время","Статус","Цена","Мастер","Услуга"],
                        ["appt_id","appointment_dt","status","total_price","master_fio","service_name"])

    def client_update_price(self):
        sid = self.ui.cb_cl_service.currentData()
        if not sid:
            self.ui.lbl_cl_price.setText("0.00")
            return
        row = self.db.fetchone("SELECT price FROM services WHERE id=%s", (int(sid),))
        self.ui.lbl_cl_price.setText(f'{float(row["price"]):.2f}' if row else "0.00")

    def weekday_ru(self, qdate: QDate):
        return WEEKDAYS[qdate.dayOfWeek()-1]

    def client_load_slots(self):
        mid = self.ui.cb_cl_master.currentData()
        dt = self.ui.de_cl_date.date()
        if not mid:
            return
        wd = self.weekday_ru(dt)
        try:
            sched = self.db.fetchone("SELECT start_time, end_time, slot_duration_minutes FROM master_schedule WHERE master_id=%s AND weekday=%s", (int(mid), wd))
            self.ui.cb_cl_time.clear()
            if not sched:
                QMessageBox.warning(self, "Время", "У мастера нет расписания на этот день.")
                return
            start = QDateTime(dt, QDateTime.fromString("2000-01-01 "+str(sched["start_time"]), "yyyy-MM-dd HH:mm:ss").time())
            end = QDateTime(dt, QDateTime.fromString("2000-01-01 "+str(sched["end_time"]), "yyyy-MM-dd HH:mm:ss").time())
            step = int(sched["slot_duration_minutes"])
            cur = start
            while cur < end:
                dt_str = cur.toString("yyyy-MM-dd HH:mm:ss")
                busy = self.db.fetchone(Q["appt_exists"], (int(mid), dt_str))
                if not busy:
                    self.ui.cb_cl_time.addItem(cur.toString("HH:mm"), dt_str)
                cur = cur.addSecs(step*60)
            if self.ui.cb_cl_time.count()==0:
                QMessageBox.information(self, "Время", "Свободных слотов нет.")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def client_book(self):
        sid = self.ui.cb_cl_service.currentData()
        mid = self.ui.cb_cl_master.currentData()
        dt_str = self.ui.cb_cl_time.currentData()
        if not all([sid, mid, dt_str]):
            QMessageBox.warning(self, "Запись", "Выбери услугу, мастера, дату и время.")
            return
        try:
            base = self.db.fetchone("SELECT price FROM services WHERE id=%s", (int(sid),))
            price = float(base["price"]) if base else 0.0
            notes = self.ui.le_cl_notes.text().strip()
            self.db.execute(Q["appt_insert"], (int(self.client_id), int(mid), int(sid), dt_str, price, notes))
            QMessageBox.information(self, "Запись", "Запись создана.")
            self.reload_client_appts()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def client_cancel(self):
        appt_id = self.selected_id(self.ui.tw_client_appts, 0)
        if not appt_id:
            QMessageBox.warning(self, "Отмена", "Выбери запись.")
            return
        try:
            self.db.execute(Q["appt_cancel_by_client"], (appt_id, int(self.client_id)))
            self.reload_client_appts()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))
