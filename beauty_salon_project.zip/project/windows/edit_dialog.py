
from PyQt6.QtCore import QDate, QTime
from PyQt6.QtWidgets import QDialog, QMessageBox
from ui_py.ui_edit_dialog import Ui_EditDialog
from queries import Q

WEEKDAYS = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье']

class EditDialog(QDialog):
    MODE_CLIENT = "client"
    MODE_SCHEDULE = "schedule"

    def __init__(self, mode, db, record=None, masters=None, parent=None):
        super().__init__(parent)
        self.ui = Ui_EditDialog()
        self.ui.setupUi(self)
        self.db = db
        self.mode = mode
        self.record = record or {}
        self.masters = masters or []
        self.ui.btn_cancel.clicked.connect(self.reject)
        self.ui.btn_save.clicked.connect(self.save)
        self._init()

    def _init(self):
        if self.mode == self.MODE_CLIENT:
            self.ui.stack.setCurrentIndex(0)
            self.ui.de_birth.setDate(QDate.currentDate().addYears(-25))
            self.ui.de_reg.setDate(QDate.currentDate())
            if self.record.get("id"):
                self.ui.le_fio.setText(self.record.get("fio",""))
                self.ui.de_birth.setDate(self._to_date(self.record.get("birth_date")))
                self.ui.le_phone.setText(self.record.get("phone",""))
                self.ui.le_email.setText(self.record.get("email",""))
                self.ui.de_reg.setDate(self._to_date(self.record.get("registration_date")))
        else:
            self.ui.stack.setCurrentIndex(1)
            self.ui.cb_weekday.clear()
            self.ui.cb_weekday.addItems(WEEKDAYS)
            self.ui.cb_master.clear()
            for m in self.masters:
                self.ui.cb_master.addItem(f'{m["fio"]} | {m["specialization"]}', m["id"])
            self.ui.te_start.setTime(QTime(9,0))
            self.ui.te_end.setTime(QTime(18,0))
            self.ui.sb_slot.setValue(60)
            if self.record.get("id"):
                i = self.ui.cb_master.findData(self.record.get("master_id"))
                if i>=0: self.ui.cb_master.setCurrentIndex(i)
                self.ui.cb_weekday.setCurrentText(self.record.get("weekday","Понедельник"))
                self.ui.te_start.setTime(self._to_time(self.record.get("start_time")))
                self.ui.te_end.setTime(self._to_time(self.record.get("end_time")))
                self.ui.sb_slot.setValue(int(self.record.get("slot_duration_minutes") or 60))

    def _to_date(self, v):
        if isinstance(v, QDate):
            return v
        if hasattr(v, "to_pydatetime"):
            v = v.to_pydatetime().date()
        if hasattr(v, "year"):
            return QDate(v.year, v.month, v.day)
        s = str(v)
        y,m,d = s.split("-")
        return QDate(int(y), int(m), int(d))

    def _to_time(self, v):
        if isinstance(v, QTime):
            return v
        s = str(v)
        if len(s) > 8:
            s = s.split()[-1]
        h,mi,sec = s.split(":")
        return QTime(int(h), int(mi), int(sec))

    def save(self):
        try:
            if self.mode == self.MODE_CLIENT:
                self._save_client()
            else:
                self._save_schedule()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _save_client(self):
        fio = self.ui.le_fio.text().strip()
        bd = self.ui.de_birth.date().toString("yyyy-MM-dd")
        phone = self.ui.le_phone.text().strip()
        email = self.ui.le_email.text().strip()
        reg = self.ui.de_reg.date().toString("yyyy-MM-dd")
        if not all([fio, phone, email]):
            raise ValueError("Заполни ФИО, телефон и email.")
        if self.record.get("id"):
            self.db.execute(Q["client_update"], (fio, bd, phone, email, int(self.record["id"])))
        else:
            self.db.execute(Q["client_insert"], (fio, bd, phone, email, reg))

    def _save_schedule(self):
        mid = int(self.ui.cb_master.currentData())
        wd = self.ui.cb_weekday.currentText()
        st = self.ui.te_start.time().toString("HH:mm:ss")
        en = self.ui.te_end.time().toString("HH:mm:ss")
        slot = int(self.ui.sb_slot.value())
        if st >= en:
            raise ValueError("Время начала должно быть меньше времени окончания.")
        if self.record.get("id"):
            self.db.execute(Q["schedule_update"], (mid, wd, st, en, slot, int(self.record["id"])))
        else:
            self.db.execute(Q["schedule_insert"], (mid, wd, st, en, slot))
