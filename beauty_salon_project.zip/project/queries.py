
Q = {
  "auth": "SELECT id, role, client_id, master_id FROM users WHERE username=%s AND pass_hash=%s",

  "clients_all": "SELECT id, fio, birth_date, phone, email, registration_date FROM clients ORDER BY id DESC",
  "client_insert": "INSERT INTO clients(fio,birth_date,phone,email,registration_date) VALUES(%s,%s,%s,%s,%s)",
  "client_update": "UPDATE clients SET fio=%s, birth_date=%s, phone=%s, email=%s WHERE id=%s",
  "client_delete": "DELETE FROM clients WHERE id=%s",

  "masters_all": "SELECT id, fio, specialization FROM masters WHERE is_active=1 ORDER BY fio",
  "services_all": "SELECT id, service_name, price, duration_minutes FROM services ORDER BY service_name",
  "services_by_master": """
    SELECT s.id, CONCAT(s.service_name,' | ',s.price,' ₽') AS title
    FROM services s
    JOIN service_categories c ON c.id=s.category_id
    WHERE 1=1
    ORDER BY s.service_name
  """,

  "schedule_all": """
    SELECT ms.id, m.fio AS master_fio, ms.master_id, ms.weekday, ms.start_time, ms.end_time, ms.slot_duration_minutes
    FROM master_schedule ms JOIN masters m ON m.id=ms.master_id
    ORDER BY ms.master_id, FIELD(ms.weekday,'Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье')
  """,
  "schedule_insert": "INSERT INTO master_schedule(master_id,weekday,start_time,end_time,slot_duration_minutes) VALUES(%s,%s,%s,%s,%s)",
  "schedule_update": "UPDATE master_schedule SET master_id=%s, weekday=%s, start_time=%s, end_time=%s, slot_duration_minutes=%s WHERE id=%s",
  "schedule_delete": "DELETE FROM master_schedule WHERE id=%s",

  "appt_all": "SELECT * FROM v_appointments ORDER BY appointment_dt DESC",
  "appt_by_master": "SELECT * FROM v_appointments WHERE master_id=%s ORDER BY appointment_dt DESC",
  "appt_by_client": "SELECT * FROM v_appointments WHERE client_id=%s ORDER BY appointment_dt DESC",

  "appt_insert": """
    INSERT INTO appointments(client_id,master_id,service_id,appointment_dt,status,total_price,notes)
    VALUES(%s,%s,%s,%s,'Запланирован',%s,%s)
  """,
  "appt_status_update": "UPDATE appointments SET status=%s, updated_at=NOW() WHERE id=%s",
  "appt_price_update": "UPDATE appointments SET total_price=%s, notes=%s, updated_at=NOW() WHERE id=%s",
  "appt_cancel_by_client": "UPDATE appointments SET status='Отменён', updated_at=NOW() WHERE id=%s AND client_id=%s",

  "appt_exists": "SELECT id FROM appointments WHERE master_id=%s AND appointment_dt=%s AND status<>'Отменён'",

  "avg_check_proc": "CALL sp_avg_check(%s,%s)",
  "repeat_fn": "SELECT fn_repeat_clients(%s,%s) AS pct",

  "payments_by_appt": "SELECT payment_date, amount, payment_method, pay_status FROM payments WHERE appointment_id=%s",
  "payment_upsert": """
    INSERT INTO payments(appointment_id,payment_date,amount,payment_method,pay_status)
    VALUES(%s,%s,%s,%s,'Оплачен')
    ON DUPLICATE KEY UPDATE payment_date=VALUES(payment_date), amount=VALUES(amount), payment_method=VALUES(payment_method), pay_status='Оплачен'
  """
}
