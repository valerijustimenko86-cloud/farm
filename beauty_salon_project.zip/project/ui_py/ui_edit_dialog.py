
from PyQt6 import QtCore, QtWidgets

class Ui_EditDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("EditDialog")
        Dialog.resize(680, 420)
        self.vbox = QtWidgets.QVBoxLayout(Dialog)
        self.vbox.setContentsMargins(12, 12, 12, 12)
        self.vbox.setSpacing(10)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.setObjectName("stack")

        self.page_client = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(self.page_client)

        self.le_fio = QtWidgets.QLineEdit(); self.le_fio.setObjectName("le_fio")
        self.de_birth = QtWidgets.QDateEdit(); self.de_birth.setObjectName("de_birth"); self.de_birth.setCalendarPopup(True)
        self.le_phone = QtWidgets.QLineEdit(); self.le_phone.setObjectName("le_phone")
        self.le_email = QtWidgets.QLineEdit(); self.le_email.setObjectName("le_email")
        self.de_reg = QtWidgets.QDateEdit(); self.de_reg.setObjectName("de_reg"); self.de_reg.setCalendarPopup(True)

        g.addWidget(QtWidgets.QLabel("ФИО"),0,0); g.addWidget(self.le_fio,0,1,1,3)
        g.addWidget(QtWidgets.QLabel("Дата рождения"),1,0); g.addWidget(self.de_birth,1,1)
        g.addWidget(QtWidgets.QLabel("Телефон"),2,0); g.addWidget(self.le_phone,2,1)
        g.addWidget(QtWidgets.QLabel("Email"),2,2); g.addWidget(self.le_email,2,3)
        g.addWidget(QtWidgets.QLabel("Дата регистрации"),3,0); g.addWidget(self.de_reg,3,1)
        g.setRowStretch(4, 1)

        self.stack.addWidget(self.page_client)

        self.page_schedule = QtWidgets.QWidget()
        gs = QtWidgets.QGridLayout(self.page_schedule)

        self.cb_master = QtWidgets.QComboBox(); self.cb_master.setObjectName("cb_master")
        self.cb_weekday = QtWidgets.QComboBox(); self.cb_weekday.setObjectName("cb_weekday")
        self.te_start = QtWidgets.QTimeEdit(); self.te_start.setObjectName("te_start")
        self.te_end = QtWidgets.QTimeEdit(); self.te_end.setObjectName("te_end")
        self.sb_slot = QtWidgets.QSpinBox(); self.sb_slot.setObjectName("sb_slot"); self.sb_slot.setRange(15, 240); self.sb_slot.setSingleStep(15)

        gs.addWidget(QtWidgets.QLabel("Мастер"),0,0); gs.addWidget(self.cb_master,0,1,1,3)
        gs.addWidget(QtWidgets.QLabel("День недели"),1,0); gs.addWidget(self.cb_weekday,1,1)
        gs.addWidget(QtWidgets.QLabel("С"),2,0); gs.addWidget(self.te_start,2,1)
        gs.addWidget(QtWidgets.QLabel("По"),2,2); gs.addWidget(self.te_end,2,3)
        gs.addWidget(QtWidgets.QLabel("Длительность слота, мин"),3,0); gs.addWidget(self.sb_slot,3,1)
        gs.setRowStretch(4, 1)

        self.stack.addWidget(self.page_schedule)

        self.hbox = QtWidgets.QHBoxLayout()
        self.hbox.addStretch()
        self.btn_save = QtWidgets.QPushButton("Сохранить"); self.btn_save.setObjectName("btn_save")
        self.btn_cancel = QtWidgets.QPushButton("Отмена"); self.btn_cancel.setObjectName("btn_cancel")
        self.hbox.addWidget(self.btn_save)
        self.hbox.addWidget(self.btn_cancel)

        self.vbox.addWidget(self.stack)
        self.vbox.addLayout(self.hbox)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
