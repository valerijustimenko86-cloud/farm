
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QDialog, QMessageBox, QListWidgetItem
from ui_py.ui_edit_dialog import Ui_EditDialog

class EditDialog(QDialog):
    MODE_CLIENT = "client"
    MODE_ORDER = "order"

    def __init__(self, mode, db, record=None, parent=None, client_id_lock=None):
        super().__init__(parent)
        self.ui = Ui_EditDialog()
        self.ui.setupUi(self)
        self.db = db
        self.mode = mode
        self.record = record or {}
        self.client_id_lock = client_id_lock
        self.ui.btn_cancel.clicked.connect(self.reject)
        self.ui.btn_save.clicked.connect(self.save)
        self._init_mode()

    def _init_mode(self):
        if self.mode == self.MODE_CLIENT:
            self.ui.stack.setCurrentIndex(0)
            self._load_client()
        elif self.mode == self.MODE_ORDER:
            self.ui.stack.setCurrentIndex(1)
            self._load_order()
        else:
            raise ValueError("Unknown mode")

    def _load_client(self):
        self.ui.le_fio.setText(self.record.get("fio", ""))
        self.ui.le_phone.setText(self.record.get("phone", ""))
        self.ui.le_email.setText(self.record.get("email", ""))

    def _load_order(self):
        self.clients = self.db.fetchall("SELECT id, fio FROM clients ORDER BY fio")
        self.products = self.db.fetchall("SELECT id, ptype, name, price FROM products WHERE is_active=1 ORDER BY ptype, name")
        self.pack = self.db.fetchall("SELECT id, name, price FROM packaging ORDER BY name")
        self.acc = self.db.fetchall("SELECT id, name, price FROM accessories ORDER BY name")

        self.ui.cb_o_client.clear()
        for c in self.clients:
            self.ui.cb_o_client.addItem(c["fio"], c["id"])

        self.ui.cb_o_product.clear()
        for p in self.products:
            label = f'{p["ptype"]}: {p["name"]} — {p["price"]}'
            self.ui.cb_o_product.addItem(label, p["id"])

        self.ui.cb_o_pack.clear()
        self.ui.cb_o_pack.addItem("Без упаковки", None)
        for pk in self.pack:
            self.ui.cb_o_pack.addItem(f'{pk["name"]} (+{pk["price"]})', pk["id"])

        self.ui.lw_o_acc.clear()
        for a in self.acc:
            it = QListWidgetItem(f'{a["name"]} (+{a["price"]})')
            it.setData(32, a["id"])
            self.ui.lw_o_acc.addItem(it)

        today = QDate.currentDate()
        self.ui.de_o_desired.setDate(today.addDays(1))

        if self.record.get("order_id"):
            o = self.db.fetchone("SELECT * FROM orders WHERE id=%s", (self.record["order_id"],))
            if o:
                idx = self.ui.cb_o_client.findData(o["client_id"])
                if idx >= 0:
                    self.ui.cb_o_client.setCurrentIndex(idx)
                self.ui.sp_o_discount.setValue(float(o["discount_pct"]))
                self.ui.cb_o_status.setCurrentText(o["status"])
                if o.get("desired_date"):
                    self.ui.de_o_desired.setDate(QDate.fromString(str(o["desired_date"]), "yyyy-MM-dd"))
                self.ui.le_o_comment.setText(o.get("comment") or "")

                lines = self.db.fetchall("SELECT * FROM order_items WHERE order_id=%s", (o["id"],))
                prod = next((x for x in lines if x["item_type"]=="PRODUCT"), None)
                if prod:
                    idx = self.ui.cb_o_product.findData(prod["ref_id"])
                    if idx >= 0:
                        self.ui.cb_o_product.setCurrentIndex(idx)
                    self.ui.sp_o_qty.setValue(int(prod["qty"]))
                pk = next((x for x in lines if x["item_type"]=="PACKAGING"), None)
                if pk:
                    idx = self.ui.cb_o_pack.findData(pk["ref_id"])
                    if idx >= 0:
                        self.ui.cb_o_pack.setCurrentIndex(idx)
                acc_ids = {x["ref_id"] for x in lines if x["item_type"]=="ACCESSORY"}
                for i in range(self.ui.lw_o_acc.count()):
                    it = self.ui.lw_o_acc.item(i)
                    if it.data(32) in acc_ids:
                        it.setSelected(True)

        if self.client_id_lock is not None:
            idx = self.ui.cb_o_client.findData(self.client_id_lock)
            if idx >= 0:
                self.ui.cb_o_client.setCurrentIndex(idx)
            self.ui.cb_o_client.setEnabled(False)

    def save(self):
        try:
            if self.mode == self.MODE_CLIENT:
                self._save_client()
            else:
                self._save_order()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _save_client(self):
        fio = self.ui.le_fio.text().strip()
        phone = self.ui.le_phone.text().strip()
        email = self.ui.le_email.text().strip()
        if not fio or not phone or not email:
            raise ValueError("Заполни ФИО, телефон и email.")
        if self.record.get("id"):
            self.db.execute("UPDATE clients SET fio=%s, phone=%s, email=%s WHERE id=%s", (fio, phone, email, self.record["id"]))
        else:
            self.db.execute("INSERT INTO clients(fio,phone,email) VALUES(%s,%s,%s)", (fio, phone, email))

    def _save_order(self):
        client_id = int(self.ui.cb_o_client.currentData())
        product_id = int(self.ui.cb_o_product.currentData())
        qty = int(self.ui.sp_o_qty.value())
        pack_id = self.ui.cb_o_pack.currentData()
        discount = float(self.ui.sp_o_discount.value())
        status = self.ui.cb_o_status.currentText()
        desired = self.ui.de_o_desired.date().toString("yyyy-MM-dd")
        comment = self.ui.le_o_comment.text().strip() or None

        prod_price = float(self.db.fetchone("SELECT price FROM products WHERE id=%s", (product_id,))["price"])
        total = prod_price * qty

        items = [("PRODUCT", product_id, qty, prod_price, prod_price*qty)]

        if pack_id is not None:
            pack_price = float(self.db.fetchone("SELECT price FROM packaging WHERE id=%s", (pack_id,))["price"])
            total += pack_price
            items.append(("PACKAGING", int(pack_id), 1, pack_price, pack_price))

        for it in self.ui.lw_o_acc.selectedItems():
            aid = int(it.data(32))
            acc_price = float(self.db.fetchone("SELECT price FROM accessories WHERE id=%s", (aid,))["price"])
            total += acc_price
            items.append(("ACCESSORY", aid, 1, acc_price, acc_price))

        total = round(total * (1 - discount/100.0), 2)

        if self.record.get("order_id"):
            oid = int(self.record["order_id"])
            self.db.execute(
                "UPDATE orders SET client_id=%s, desired_date=%s, status=%s, discount_pct=%s, comment=%s, total_amount=%s WHERE id=%s",
                (client_id, desired, status, discount, comment, total, oid)
            )
            self.db.execute("DELETE FROM order_items WHERE order_id=%s", (oid,))
        else:
            oid = self.db.execute(
                "INSERT INTO orders(client_id, desired_date, status, discount_pct, comment, total_amount) VALUES(%s,%s,%s,%s,%s,%s)",
                (client_id, desired, status, discount, comment, total)
            )

        for t, rid, q, up, ls in items:
            self.db.execute(
                "INSERT INTO order_items(order_id,item_type,ref_id,qty,unit_price,line_sum) VALUES(%s,%s,%s,%s,%s,%s)",
                (oid, t, rid, q, up, ls)
            )
