
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem, QAbstractItemView, QInputDialog
from ui_py.ui_main import Ui_MainWindow
from db import DB
from queries import Q
from windows.edit_dialog import EditDialog

STYLESHEET = """
QWidget { background:
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QListWidget {
  background:
}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QListWidget:focus { border: 1px solid
QPushButton { background:
QPushButton:hover { background:
QPushButton:pressed { background:
QTableWidget { background:
QHeaderView::section { background:
QTableWidget::item:selected { background:
"""

class MainWindow(QMainWindow):
    def __init__(self, role, client_id, username):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setStyleSheet(STYLESHEET)
        self.db = DB()
        self.role = role
        self.client_id = client_id
        self.username = username
        self._setup_tables()
        self._init_defaults()
        self._load_lists()
        self.role_apply(role)
        self._bind()
        self.reload_catalog_seller()
        self.reload_orders_seller()
        self.reload_catalog_client()
        self.reload_orders_client()

    def _setup_tables(self):
        for tw in [self.ui.tw_s_catalog, self.ui.tw_s_orders, self.ui.tw_c_catalog, self.ui.tw_c_orders]:
            tw.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            tw.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            tw.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            tw.setAlternatingRowColors(True)

    def _init_defaults(self):
        today = QDate.currentDate()
        self.ui.de_p_from.setDate(today.addMonths(-1))
        self.ui.de_p_to.setDate(today)
        self.ui.cb_c_type.clear()
        self.ui.cb_c_type.addItem("Все", "ALL")
        self.ui.cb_c_type.addItem("Цветы", "FLOWER")
        self.ui.cb_c_type.addItem("Букеты", "BOUQUET")
        self.ui.de_c_desired.setDate(today.addDays(1))
        self.ui.sp_c_qty.setValue(1)

    def _bind(self):
        self.ui.btn_s_filter.clicked.connect(self.reload_catalog_seller_filtered)
        self.ui.btn_s_reset.clicked.connect(self.reload_catalog_seller)
        self.ui.btn_s_add_client.clicked.connect(self.add_client)
        self.ui.btn_s_add_order.clicked.connect(self.add_order)
        self.ui.btn_s_edit_order.clicked.connect(self.edit_order)
        self.ui.btn_s_cancel_order.clicked.connect(self.cancel_order)
        self.ui.btn_s_pay.clicked.connect(self.pay_order)
        self.ui.btn_s_receipt.clicked.connect(self.receipt_order)

        self.ui.btn_p_avg.clicked.connect(self.proc_avg_cost)
        self.ui.btn_p_writeoff.clicked.connect(self.proc_writeoff_pct)

        self.ui.btn_c_filter.clicked.connect(self.reload_catalog_client_filtered)
        self.ui.btn_c_reset.clicked.connect(self.reload_catalog_client)
        self.ui.btn_c_request.clicked.connect(self.client_request)

    def role_apply(self, role):
        idx_s = self.ui.tabs_main.indexOf(self.ui.tab_seller)
        idx_p = self.ui.tabs_main.indexOf(self.ui.tab_proc)
        idx_c = self.ui.tabs_main.indexOf(self.ui.tab_client)
        self.ui.tabs_main.setTabVisible(idx_s, role in ("seller",))
        self.ui.tabs_main.setTabVisible(idx_p, role in ("procurement",))
        self.ui.tabs_main.setTabVisible(idx_c, role in ("client",))
        if role == "seller":
            self.ui.tabs_main.setCurrentIndex(idx_s)
        elif role == "procurement":
            self.ui.tabs_main.setCurrentIndex(idx_p)
        else:
            self.ui.tabs_main.setCurrentIndex(idx_c)

    def _load_lists(self):
        try:
            self.sorts = self.db.fetchall(Q["proc_sorts"])
            self.ui.cb_p_sort.clear()
            for s in self.sorts:
                self.ui.cb_p_sort.addItem(s["sort"], s["sort"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def load_table(self, tw, rows, headers, keys):
        tw.clear()
        tw.setColumnCount(len(headers))
        tw.setRowCount(len(rows))
        tw.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, k in enumerate(keys):
                v = row.get(k)
                tw.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
        tw.resizeColumnsToContents()

    def selected_id(self, tw, id_col=0):
        sel = tw.selectedItems()
        if not sel:
            return None
        row = sel[0].row()
        try:
            return int(tw.item(row, id_col).text())
        except:
            return None

    def reload_catalog_seller(self):
        try:
            rows = self.db.fetchall(Q["catalog_all"])
            self.load_table(self.ui.tw_s_catalog, rows,
                            ["ID", "Тип", "Название", "Цвет", "Сорт", "Повод", "Цена", "Остаток"],
                            ["id","ptype","name","color","sort","occasion","price","stock_qty"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_catalog_seller_filtered(self):
        try:
            name = self.ui.le_s_name.text().strip()
            color = self.ui.le_s_color.text().strip()
            occ = self.ui.le_s_occasion.text().strip()
            p_from = float(self.ui.sp_s_price_from.value())
            p_to = float(self.ui.sp_s_price_to.value())
            rows = self.db.fetchall(Q["catalog_filter_seller"], (name, name, color, color, occ, occ, p_from, p_to))
            self.load_table(self.ui.tw_s_catalog, rows,
                            ["ID", "Тип", "Название", "Цвет", "Сорт", "Повод", "Цена", "Остаток"],
                            ["id","ptype","name","color","sort","occasion","price","stock_qty"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_orders_seller(self):
        try:
            rows = self.db.fetchall(Q["orders_table"])
            self.load_table(self.ui.tw_s_orders, rows,
                            ["ID","Создан","Желаемая дата","Статус","Скидка","Сумма","Клиент","Тел","Email"],
                            ["order_id","created_at","desired_date","status","discount_pct","total_amount","fio","phone","email"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def add_client(self):
        dlg = EditDialog(EditDialog.MODE_CLIENT, db=self.db, parent=self)
        if dlg.exec():
            QMessageBox.information(self, "Готово", "Клиент сохранён.")

    def add_order(self):
        dlg = EditDialog(EditDialog.MODE_ORDER, db=self.db, parent=self)
        if dlg.exec():
            self.reload_orders_seller()

    def edit_order(self):
        oid = self.selected_id(self.ui.tw_s_orders, 0)
        if not oid:
            QMessageBox.warning(self, "Заказ", "Выбери заказ.")
            return
        dlg = EditDialog(EditDialog.MODE_ORDER, db=self.db, record={"order_id": oid}, parent=self)
        if dlg.exec():
            self.reload_orders_seller()

    def cancel_order(self):
        oid = self.selected_id(self.ui.tw_s_orders, 0)
        if not oid:
            QMessageBox.warning(self, "Заказ", "Выбери заказ.")
            return
        try:
            self.db.execute("UPDATE orders SET status='CANCELLED' WHERE id=%s", (oid,))
            self.reload_orders_seller()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def pay_order(self):
        oid = self.selected_id(self.ui.tw_s_orders, 0)
        if not oid:
            QMessageBox.warning(self, "Оплата", "Выбери заказ.")
            return
        method, ok = QInputDialog.getItem(self, "Оплата", "Способ оплаты:", ["CASH", "CARD"], 0, False)
        if not ok:
            return
        try:
            order = self.db.fetchone("SELECT total_amount FROM orders WHERE id=%s", (oid,))
            amount = float(order["total_amount"])
            self.db.execute(Q["payment_upsert"], (oid, method, amount))
            self.db.execute("UPDATE orders SET status='ISSUED' WHERE id=%s", (oid,))
            QMessageBox.information(self, "Оплата", f"Оплачено: {amount} ({method})")
            self.reload_orders_seller()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def receipt_order(self):
        oid = self.selected_id(self.ui.tw_s_orders, 0)
        if not oid:
            QMessageBox.warning(self, "Чек", "Выбери заказ.")
            return
        try:
            head = self.db.fetchone(Q["receipt_head"], (oid,))
            lines = self.db.fetchall(Q["receipt_lines"], (oid,))
            if not head:
                QMessageBox.warning(self, "Чек", "Данные не найдены.")
                return
            txt = []
            txt.append(f'ЧЕК №{head["order_id"]}')
            txt.append(f'Клиент: {head["fio"]} | {head["phone"]} | {head["email"]}')
            txt.append(f'Статус: {head["status"]} | Скидка: {head["discount_pct"]}%')
            txt.append("")
            txt.append("Позиции:")
            def ref_name(t, rid):
                if t=="PRODUCT":
                    r = self.db.fetchone("SELECT name FROM products WHERE id=%s", (rid,))
                    return r["name"] if r else str(rid)
                if t=="PACKAGING":
                    r = self.db.fetchone("SELECT name FROM packaging WHERE id=%s", (rid,))
                    return r["name"] if r else str(rid)
                r = self.db.fetchone("SELECT name FROM accessories WHERE id=%s", (rid,))
                return r["name"] if r else str(rid)
            for ln in lines:
                nm = ref_name(ln["item_type"], ln["ref_id"])
                txt.append(f'- {ln["item_type"]}: {nm} | {ln["unit_price"]} x {ln["qty"]} = {ln["line_sum"]}')
            txt.append("")
            txt.append(f'Итого: {head["total_amount"]}')
            txt.append(f'Оплата: {head.get("amount") or "-"} | Метод: {head.get("method") or "-"} | Дата: {head.get("paid_at") or "-"}')
            QMessageBox.information(self, "Чек", "\n".join(txt))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def proc_avg_cost(self):
        try:
            sort = self.ui.cb_p_sort.currentData()
            d_from = self.ui.de_p_from.date().toString("yyyy-MM-dd")
            d_to = self.ui.de_p_to.date().toString("yyyy-MM-dd")
            res = self.db.callproc_one("sp_avg_flower_cost_by_sort_period", (sort, d_from, d_to))
            val = res["avg_cost"] if res else 0.00
            self.ui.lbl_p_avg.setText(str(val))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def proc_writeoff_pct(self):
        try:
            sort = self.ui.cb_p_sort.currentData()
            res = self.db.fetchone(Q["proc_writeoff_pct"], (sort,))
            self.ui.lbl_p_writeoff.setText(str(res["pct"]))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_catalog_client(self):
        try:
            rows = self.db.fetchall(Q["catalog_all"])
            self.load_table(self.ui.tw_c_catalog, rows,
                            ["ID", "Тип", "Название", "Цвет", "Повод", "Цена"],
                            ["id","ptype","name","color","occasion","price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_catalog_client_filtered(self):
        try:
            t = self.ui.cb_c_type.currentData()
            p_from = float(self.ui.sp_c_price_from.value())
            p_to = float(self.ui.sp_c_price_to.value())
            rows = self.db.fetchall(Q["catalog_filter_client"], (t, t, p_from, p_to))
            self.load_table(self.ui.tw_c_catalog, rows,
                            ["ID", "Тип", "Название", "Цвет", "Повод", "Цена"],
                            ["id","ptype","name","color","occasion","price"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def reload_orders_client(self):
        if not self.client_id:
            return
        try:
            cl = self.db.fetchone("SELECT email FROM clients WHERE id=%s", (self.client_id,))
            if not cl:
                return
            rows = self.db.fetchall(Q["orders_by_client"], (cl["email"],))
            self.load_table(self.ui.tw_c_orders, rows,
                            ["ID","Создан","Желаемая дата","Статус","Скидка","Сумма"],
                            ["order_id","created_at","desired_date","status","discount_pct","total_amount"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))

    def client_request(self):
        if not self.client_id:
            QMessageBox.warning(self, "Заявка", "Нет client_id.")
            return
        pid = self.selected_id(self.ui.tw_c_catalog, 0)
        if not pid:
            QMessageBox.warning(self, "Заявка", "Выбери товар в каталоге.")
            return
        try:
            qty = int(self.ui.sp_c_qty.value())
            desired = self.ui.de_c_desired.date().toString("yyyy-MM-dd")
            wish = self.ui.le_c_wish.text().strip() or "Заявка клиента"
            price = float(self.db.fetchone("SELECT price FROM products WHERE id=%s", (pid,))["price"])
            total = round(price * qty, 2)
            oid = self.db.execute(
                "INSERT INTO orders(client_id, desired_date, status, discount_pct, comment, total_amount) VALUES(%s,%s,'NEW',0,%s,%s)",
                (self.client_id, desired, wish, total)
            )
            self.db.execute(
                "INSERT INTO order_items(order_id,item_type,ref_id,qty,unit_price,line_sum) VALUES(%s,'PRODUCT',%s,%s,%s,%s)",
                (oid, pid, qty, price, total)
            )
            self.reload_orders_client()
            QMessageBox.information(self, "Заявка", f"Заявка создана (№{oid}).")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))
