
from PyQt6 import QtCore, QtWidgets

class Ui_EditDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("EditDialog")
        Dialog.resize(560, 520)
        self.vbox = QtWidgets.QVBoxLayout(Dialog)
        self.vbox.setContentsMargins(12, 12, 12, 12)
        self.vbox.setSpacing(10)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.setObjectName("stack")

        self.page_client = QtWidgets.QWidget()
        g1 = QtWidgets.QGridLayout(self.page_client)
        self.le_fio = QtWidgets.QLineEdit(); self.le_fio.setObjectName("le_fio")
        self.le_phone = QtWidgets.QLineEdit(); self.le_phone.setObjectName("le_phone")
        self.le_email = QtWidgets.QLineEdit(); self.le_email.setObjectName("le_email")
        g1.addWidget(QtWidgets.QLabel("ФИО"), 0, 0); g1.addWidget(self.le_fio, 0, 1)
        g1.addWidget(QtWidgets.QLabel("Телефон"), 1, 0); g1.addWidget(self.le_phone, 1, 1)
        g1.addWidget(QtWidgets.QLabel("Email"), 2, 0); g1.addWidget(self.le_email, 2, 1)
        g1.setRowStretch(3, 1)
        self.stack.addWidget(self.page_client)

        self.page_order = QtWidgets.QWidget()
        g2 = QtWidgets.QGridLayout(self.page_order)

        self.cb_o_client = QtWidgets.QComboBox(); self.cb_o_client.setObjectName("cb_o_client")
        self.cb_o_product = QtWidgets.QComboBox(); self.cb_o_product.setObjectName("cb_o_product")
        self.sp_o_qty = QtWidgets.QSpinBox(); self.sp_o_qty.setObjectName("sp_o_qty"); self.sp_o_qty.setRange(1, 50)
        self.cb_o_pack = QtWidgets.QComboBox(); self.cb_o_pack.setObjectName("cb_o_pack")
        self.lw_o_acc = QtWidgets.QListWidget(); self.lw_o_acc.setObjectName("lw_o_acc")
        self.lw_o_acc.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.MultiSelection)
        self.sp_o_discount = QtWidgets.QDoubleSpinBox(); self.sp_o_discount.setObjectName("sp_o_discount"); self.sp_o_discount.setRange(0, 100); self.sp_o_discount.setDecimals(2)
        self.cb_o_status = QtWidgets.QComboBox(); self.cb_o_status.setObjectName("cb_o_status")
        self.cb_o_status.addItems(["NEW","ACCEPTED","IN_PROGRESS","READY","ISSUED","CANCELLED"])
        self.de_o_desired = QtWidgets.QDateEdit(); self.de_o_desired.setObjectName("de_o_desired"); self.de_o_desired.setCalendarPopup(True)
        self.le_o_comment = QtWidgets.QLineEdit(); self.le_o_comment.setObjectName("le_o_comment")

        g2.addWidget(QtWidgets.QLabel("Клиент"), 0, 0); g2.addWidget(self.cb_o_client, 0, 1)
        g2.addWidget(QtWidgets.QLabel("Товар"), 1, 0); g2.addWidget(self.cb_o_product, 1, 1)
        g2.addWidget(QtWidgets.QLabel("Кол-во"), 2, 0); g2.addWidget(self.sp_o_qty, 2, 1)
        g2.addWidget(QtWidgets.QLabel("Упаковка"), 3, 0); g2.addWidget(self.cb_o_pack, 3, 1)
        g2.addWidget(QtWidgets.QLabel("Аксессуары"), 4, 0); g2.addWidget(self.lw_o_acc, 4, 1)
        g2.addWidget(QtWidgets.QLabel("Скидка %"), 5, 0); g2.addWidget(self.sp_o_discount, 5, 1)
        g2.addWidget(QtWidgets.QLabel("Статус"), 6, 0); g2.addWidget(self.cb_o_status, 6, 1)
        g2.addWidget(QtWidgets.QLabel("Желаемая дата"), 7, 0); g2.addWidget(self.de_o_desired, 7, 1)
        g2.addWidget(QtWidgets.QLabel("Комментарий"), 8, 0); g2.addWidget(self.le_o_comment, 8, 1)
        g2.setRowStretch(9, 1)

        self.stack.addWidget(self.page_order)

        self.hbox = QtWidgets.QHBoxLayout()
        self.hbox.addStretch()
        self.btn_save = QtWidgets.QPushButton("Сохранить"); self.btn_save.setObjectName("btn_save")
        self.btn_cancel = QtWidgets.QPushButton("Отмена"); self.btn_cancel.setObjectName("btn_cancel")
        self.hbox.addWidget(self.btn_save)
        self.hbox.addWidget(self.btn_cancel)

        self.vbox.addWidget(self.stack)
        self.vbox.addLayout(self.hbox)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
