
from PyQt6 import QtCore, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1120, 740)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.vbox_main = QtWidgets.QVBoxLayout(self.centralwidget)
        self.vbox_main.setContentsMargins(12, 12, 12, 12)
        self.vbox_main.setSpacing(10)

        self.tabs_main = QtWidgets.QTabWidget(parent=self.centralwidget)
        self.tabs_main.setObjectName("tabs_main")

        self.tab_seller = QtWidgets.QWidget()
        self.tab_seller.setObjectName("tab_seller")
        self.vbox_s = QtWidgets.QVBoxLayout(self.tab_seller)
        self.vbox_s.setSpacing(10)

        self.gb_s_filter = QtWidgets.QGroupBox("Фильтр каталога", parent=self.tab_seller)
        self.grid_s = QtWidgets.QGridLayout(self.gb_s_filter)

        self.le_s_name = QtWidgets.QLineEdit(); self.le_s_name.setObjectName("le_s_name"); self.le_s_name.setPlaceholderText("Название")
        self.le_s_color = QtWidgets.QLineEdit(); self.le_s_color.setObjectName("le_s_color"); self.le_s_color.setPlaceholderText("Цвет")
        self.le_s_occasion = QtWidgets.QLineEdit(); self.le_s_occasion.setObjectName("le_s_occasion"); self.le_s_occasion.setPlaceholderText("Повод")

        self.sp_s_price_from = QtWidgets.QDoubleSpinBox(); self.sp_s_price_from.setObjectName("sp_s_price_from"); self.sp_s_price_from.setMaximum(9999999); self.sp_s_price_from.setDecimals(2)
        self.sp_s_price_to = QtWidgets.QDoubleSpinBox(); self.sp_s_price_to.setObjectName("sp_s_price_to"); self.sp_s_price_to.setMaximum(9999999); self.sp_s_price_to.setDecimals(2); self.sp_s_price_to.setValue(9999999)

        self.btn_s_filter = QtWidgets.QPushButton("Фильтровать"); self.btn_s_filter.setObjectName("btn_s_filter")
        self.btn_s_reset = QtWidgets.QPushButton("Показать все"); self.btn_s_reset.setObjectName("btn_s_reset")

        self.grid_s.addWidget(QtWidgets.QLabel("Название"), 0, 0); self.grid_s.addWidget(self.le_s_name, 0, 1)
        self.grid_s.addWidget(QtWidgets.QLabel("Цвет"), 0, 2); self.grid_s.addWidget(self.le_s_color, 0, 3)
        self.grid_s.addWidget(QtWidgets.QLabel("Повод"), 1, 0); self.grid_s.addWidget(self.le_s_occasion, 1, 1)
        self.grid_s.addWidget(QtWidgets.QLabel("Цена"), 1, 2)
        h_price = QtWidgets.QHBoxLayout()
        h_price.addWidget(self.sp_s_price_from)
        h_price.addWidget(self.sp_s_price_to)
        self.grid_s.addLayout(h_price, 1, 3)

        h_btn = QtWidgets.QHBoxLayout()
        h_btn.addStretch()
        h_btn.addWidget(self.btn_s_filter)
        h_btn.addWidget(self.btn_s_reset)
        self.grid_s.addLayout(h_btn, 2, 3)

        self.tw_s_catalog = QtWidgets.QTableWidget(); self.tw_s_catalog.setObjectName("tw_s_catalog")
        self.tw_s_orders = QtWidgets.QTableWidget(); self.tw_s_orders.setObjectName("tw_s_orders")

        self.hbox_s_actions = QtWidgets.QHBoxLayout()
        self.btn_s_add_client = QtWidgets.QPushButton("Добавить клиента"); self.btn_s_add_client.setObjectName("btn_s_add_client")
        self.btn_s_add_order = QtWidgets.QPushButton("Оформить заказ"); self.btn_s_add_order.setObjectName("btn_s_add_order")
        self.btn_s_edit_order = QtWidgets.QPushButton("Изменить"); self.btn_s_edit_order.setObjectName("btn_s_edit_order")
        self.btn_s_cancel_order = QtWidgets.QPushButton("Отменить"); self.btn_s_cancel_order.setObjectName("btn_s_cancel_order")
        self.btn_s_pay = QtWidgets.QPushButton("Оплата"); self.btn_s_pay.setObjectName("btn_s_pay")
        self.btn_s_receipt = QtWidgets.QPushButton("Чек"); self.btn_s_receipt.setObjectName("btn_s_receipt")

        self.hbox_s_actions.addWidget(self.btn_s_add_client)
        self.hbox_s_actions.addStretch()
        self.hbox_s_actions.addWidget(self.btn_s_add_order)
        self.hbox_s_actions.addWidget(self.btn_s_edit_order)
        self.hbox_s_actions.addWidget(self.btn_s_cancel_order)
        self.hbox_s_actions.addWidget(self.btn_s_pay)
        self.hbox_s_actions.addWidget(self.btn_s_receipt)

        self.vbox_s.addWidget(self.gb_s_filter)
        self.vbox_s.addWidget(QtWidgets.QLabel("Каталог"))
        self.vbox_s.addWidget(self.tw_s_catalog, 2)
        self.vbox_s.addLayout(self.hbox_s_actions)
        self.vbox_s.addWidget(QtWidgets.QLabel("Заказы"))
        self.vbox_s.addWidget(self.tw_s_orders, 2)

        self.tabs_main.addTab(self.tab_seller, "Продавец-флорист")

        self.tab_proc = QtWidgets.QWidget()
        self.tab_proc.setObjectName("tab_proc")
        self.vbox_p = QtWidgets.QVBoxLayout(self.tab_proc)
        self.vbox_p.setSpacing(10)

        self.gb_p_analytics = QtWidgets.QGroupBox("Аналитика закупок", parent=self.tab_proc)
        self.grid_p = QtWidgets.QGridLayout(self.gb_p_analytics)

        self.cb_p_sort = QtWidgets.QComboBox(); self.cb_p_sort.setObjectName("cb_p_sort")
        self.de_p_from = QtWidgets.QDateEdit(); self.de_p_from.setObjectName("de_p_from"); self.de_p_from.setCalendarPopup(True)
        self.de_p_to = QtWidgets.QDateEdit(); self.de_p_to.setObjectName("de_p_to"); self.de_p_to.setCalendarPopup(True)
        self.btn_p_avg = QtWidgets.QPushButton("Средняя стоимость (период)"); self.btn_p_avg.setObjectName("btn_p_avg")
        self.lbl_p_avg = QtWidgets.QLabel("0.00"); self.lbl_p_avg.setObjectName("lbl_p_avg")
        self.btn_p_writeoff = QtWidgets.QPushButton("% списаний (3 мес)"); self.btn_p_writeoff.setObjectName("btn_p_writeoff")
        self.lbl_p_writeoff = QtWidgets.QLabel("0.00"); self.lbl_p_writeoff.setObjectName("lbl_p_writeoff")

        self.grid_p.addWidget(QtWidgets.QLabel("Сорт"), 0, 0); self.grid_p.addWidget(self.cb_p_sort, 0, 1)
        self.grid_p.addWidget(QtWidgets.QLabel("С"), 0, 2); self.grid_p.addWidget(self.de_p_from, 0, 3)
        self.grid_p.addWidget(QtWidgets.QLabel("По"), 0, 4); self.grid_p.addWidget(self.de_p_to, 0, 5)
        self.grid_p.addWidget(self.btn_p_avg, 1, 0, 1, 3); self.grid_p.addWidget(self.lbl_p_avg, 1, 3, 1, 3)
        self.grid_p.addWidget(self.btn_p_writeoff, 2, 0, 1, 3); self.grid_p.addWidget(self.lbl_p_writeoff, 2, 3, 1, 3)

        self.vbox_p.addWidget(self.gb_p_analytics)
        self.tabs_main.addTab(self.tab_proc, "Менеджер по закупкам")

        self.tab_client = QtWidgets.QWidget()
        self.tab_client.setObjectName("tab_client")
        self.vbox_c = QtWidgets.QVBoxLayout(self.tab_client)
        self.vbox_c.setSpacing(10)

        self.hbox_c_filter = QtWidgets.QHBoxLayout()
        self.cb_c_type = QtWidgets.QComboBox(); self.cb_c_type.setObjectName("cb_c_type")
        self.sp_c_price_from = QtWidgets.QDoubleSpinBox(); self.sp_c_price_from.setObjectName("sp_c_price_from"); self.sp_c_price_from.setMaximum(9999999); self.sp_c_price_from.setDecimals(2)
        self.sp_c_price_to = QtWidgets.QDoubleSpinBox(); self.sp_c_price_to.setObjectName("sp_c_price_to"); self.sp_c_price_to.setMaximum(9999999); self.sp_c_price_to.setDecimals(2); self.sp_c_price_to.setValue(9999999)
        self.btn_c_filter = QtWidgets.QPushButton("Фильтровать"); self.btn_c_filter.setObjectName("btn_c_filter")
        self.btn_c_reset = QtWidgets.QPushButton("Показать все"); self.btn_c_reset.setObjectName("btn_c_reset")
        self.hbox_c_filter.addWidget(self.cb_c_type)
        self.hbox_c_filter.addWidget(QtWidgets.QLabel("Цена"))
        self.hbox_c_filter.addWidget(self.sp_c_price_from)
        self.hbox_c_filter.addWidget(self.sp_c_price_to)
        self.hbox_c_filter.addWidget(self.btn_c_filter)
        self.hbox_c_filter.addWidget(self.btn_c_reset)
        self.hbox_c_filter.addStretch()

        self.tw_c_catalog = QtWidgets.QTableWidget(); self.tw_c_catalog.setObjectName("tw_c_catalog")

        self.gb_c_request = QtWidgets.QGroupBox("Заявка на букет", parent=self.tab_client)
        self.grid_c = QtWidgets.QGridLayout(self.gb_c_request)

        self.le_c_wish = QtWidgets.QLineEdit(); self.le_c_wish.setObjectName("le_c_wish"); self.le_c_wish.setPlaceholderText("Пожелания к оформлению")
        self.de_c_desired = QtWidgets.QDateEdit(); self.de_c_desired.setObjectName("de_c_desired"); self.de_c_desired.setCalendarPopup(True)
        self.sp_c_qty = QtWidgets.QSpinBox(); self.sp_c_qty.setObjectName("sp_c_qty"); self.sp_c_qty.setRange(1, 50)
        self.btn_c_request = QtWidgets.QPushButton("Оставить заявку"); self.btn_c_request.setObjectName("btn_c_request")

        self.grid_c.addWidget(QtWidgets.QLabel("Пожелания"), 0, 0); self.grid_c.addWidget(self.le_c_wish, 0, 1, 1, 3)
        self.grid_c.addWidget(QtWidgets.QLabel("Желаемая дата"), 1, 0); self.grid_c.addWidget(self.de_c_desired, 1, 1)
        self.grid_c.addWidget(QtWidgets.QLabel("Кол-во"), 1, 2); self.grid_c.addWidget(self.sp_c_qty, 1, 3)
        self.grid_c.addWidget(self.btn_c_request, 2, 3)

        self.tw_c_orders = QtWidgets.QTableWidget(); self.tw_c_orders.setObjectName("tw_c_orders")

        self.vbox_c.addLayout(self.hbox_c_filter)
        self.vbox_c.addWidget(QtWidgets.QLabel("Каталог"))
        self.vbox_c.addWidget(self.tw_c_catalog, 2)
        self.vbox_c.addWidget(self.gb_c_request)
        self.vbox_c.addWidget(QtWidgets.QLabel("Мои заказы"))
        self.vbox_c.addWidget(self.tw_c_orders, 2)

        self.tabs_main.addTab(self.tab_client, "Клиент")

        self.vbox_main.addWidget(self.tabs_main)
        MainWindow.setCentralWidget(self.centralwidget)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
