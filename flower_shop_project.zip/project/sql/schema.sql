
DROP DATABASE IF EXISTS flower_shop;
CREATE DATABASE flower_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE flower_shop;

CREATE TABLE clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_clients_email (email)
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  role ENUM('seller','procurement','client') NOT NULL,
  client_id INT NULL,
  UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_client FOREIGN KEY (client_id) REFERENCES clients(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ptype ENUM('FLOWER','BOUQUET') NOT NULL,
  name VARCHAR(120) NOT NULL,
  color VARCHAR(50) NULL,
  sort VARCHAR(80) NULL,
  occasion VARCHAR(80) NULL,
  price DECIMAL(10,2) NOT NULL,
  stock_qty INT NOT NULL DEFAULT 0,
  shelf_life_days INT NOT NULL DEFAULT 7,
  composition TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  INDEX ix_products_filter (ptype, name, color, occasion, price),
  INDEX ix_products_sort (sort)
) ENGINE=InnoDB;

CREATE TABLE packaging (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  UNIQUE KEY uq_packaging_name (name)
) ENGINE=InnoDB;

CREATE TABLE accessories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  UNIQUE KEY uq_accessories_name (name)
) ENGINE=InnoDB;

CREATE TABLE suppliers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(120) NULL,
  UNIQUE KEY uq_suppliers_name (name)
) ENGINE=InnoDB;

CREATE TABLE purchases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  supplier_id INT NOT NULL,
  product_id INT NOT NULL,
  qty INT NOT NULL,
  unit_cost DECIMAL(10,2) NOT NULL,
  purchase_date DATE NOT NULL,
  CONSTRAINT fk_purchases_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_purchases_product FOREIGN KEY (product_id) REFERENCES products(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_purchases_date (purchase_date)
) ENGINE=InnoDB;

CREATE TABLE writeoffs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  qty INT NOT NULL,
  reason ENUM('EXPIRED','DAMAGED') NOT NULL DEFAULT 'EXPIRED',
  writeoff_date DATE NOT NULL,
  CONSTRAINT fk_writeoffs_product FOREIGN KEY (product_id) REFERENCES products(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_writeoffs_date (writeoff_date)
) ENGINE=InnoDB;

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  desired_date DATE NULL,
  status ENUM('NEW','ACCEPTED','IN_PROGRESS','READY','ISSUED','CANCELLED') NOT NULL DEFAULT 'NEW',
  discount_pct DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  comment VARCHAR(255) NULL,
  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  CONSTRAINT fk_orders_client FOREIGN KEY (client_id) REFERENCES clients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX ix_orders_date (created_at)
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  item_type ENUM('PRODUCT','PACKAGING','ACCESSORY') NOT NULL,
  ref_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  line_sum DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX ix_order_items_order (order_id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  method ENUM('CASH','CARD') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  pay_status ENUM('PAID','VOID') NOT NULL DEFAULT 'PAID',
  UNIQUE KEY uq_payments_order (order_id),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES orders(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE OR REPLACE VIEW v_catalog AS
SELECT id, ptype, name, color, sort, occasion, price, stock_qty, composition
FROM products
WHERE is_active=1;

CREATE OR REPLACE VIEW v_orders AS
SELECT
  o.id AS order_id,
  o.created_at,
  o.desired_date,
  o.status,
  o.discount_pct,
  o.total_amount,
  c.fio,
  c.phone,
  c.email
FROM orders o
JOIN clients c ON c.id=o.client_id;

DELIMITER $$

CREATE PROCEDURE sp_avg_flower_cost_by_sort_period(IN p_sort VARCHAR(80), IN p_from DATE, IN p_to DATE)
BEGIN
  SELECT
    CASE WHEN COUNT(*)=0 THEN 0.00 ELSE ROUND(SUM(pu.unit_cost*pu.qty)/SUM(pu.qty), 2) END AS avg_cost
  FROM purchases pu
  JOIN products pr ON pr.id=pu.product_id
  WHERE pr.ptype='FLOWER'
    AND (p_sort IS NULL OR p_sort='' OR pr.sort=p_sort)
    AND pu.purchase_date BETWEEN p_from AND p_to;
END $$

CREATE FUNCTION fn_writeoff_pct_sort_3m(p_sort VARCHAR(80))
RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
  DECLARE purchased_qty INT DEFAULT 0;
  DECLARE writeoff_qty INT DEFAULT 0;

  SELECT IFNULL(SUM(pu.qty),0) INTO purchased_qty
  FROM purchases pu
  JOIN products pr ON pr.id=pu.product_id
  WHERE pr.ptype='FLOWER'
    AND pr.sort=p_sort
    AND pu.purchase_date >= (CURDATE() - INTERVAL 3 MONTH);

  SELECT IFNULL(SUM(w.qty),0) INTO writeoff_qty
  FROM writeoffs w
  JOIN products pr ON pr.id=w.product_id
  WHERE pr.ptype='FLOWER'
    AND pr.sort=p_sort
    AND w.reason='EXPIRED'
    AND w.writeoff_date >= (CURDATE() - INTERVAL 3 MONTH);

  RETURN CASE
    WHEN purchased_qty=0 THEN 0.00
    ELSE ROUND(writeoff_qty*100.0/purchased_qty, 2)
  END;
END $$

DELIMITER ;

INSERT INTO clients(fio,phone,email) VALUES
('Иванов Иван', '+79990000001', 'ivan@mail.ru'),
('Петров Петр', '+79990000002', 'petr@mail.ru'),
('Сидорова Анна', '+79990000003', 'anna@mail.ru');

INSERT INTO users(username, pass_hash, role, client_id) VALUES
('seller', '123', 'seller', NULL),
('proc', '123', 'procurement', NULL),
('client1', '123', 'client', 1),
('client2', '123', 'client', 2);

INSERT INTO products(ptype,name,color,sort,occasion,price,stock_qty,shelf_life_days,composition) VALUES
('FLOWER','Роза','Красный','Роза','Любовь',180.00,120,7,NULL),
('FLOWER','Тюльпан','Жёлтый','Тюльпан','8 марта',120.00,200,6,NULL),
('FLOWER','Лилия','Белый','Лилия','Свадьба',250.00,60,8,NULL),
('BOUQUET','Букет "Романтика"','Красный',NULL,'Любовь',1500.00,10,2,'Розы x7, упаковка, лента'),
('BOUQUET','Букет "Весна"','Микс',NULL,'8 марта',1300.00,12,2,'Тюльпаны x11, упаковка');

INSERT INTO packaging(name,price) VALUES
('Крафт', 150.00),
('Пленка', 100.00),
('Коробка', 350.00);

INSERT INTO accessories(name,price) VALUES
('Открытка', 120.00),
('Лента', 60.00),
('Шоколад', 250.00);

INSERT INTO suppliers(name,phone,email) VALUES
('ОптЦвет', '+79991112233', 'opt@flowers.ru'),
('GreenImport', '+79992223344', 'green@import.ru'),
('CityFarm', '+79993334455', 'farm@city.ru');

INSERT INTO purchases(supplier_id,product_id,qty,unit_cost,purchase_date) VALUES
(1,1,200,90.00, CURDATE()-INTERVAL 20 DAY),
(2,2,300,60.00, CURDATE()-INTERVAL 10 DAY),
(3,3,100,120.00, CURDATE()-INTERVAL 5 DAY);

INSERT INTO writeoffs(product_id,qty,reason,writeoff_date) VALUES
(1,10,'EXPIRED', CURDATE()-INTERVAL 15 DAY),
(2,20,'EXPIRED', CURDATE()-INTERVAL 25 DAY),
(1,5,'DAMAGED', CURDATE()-INTERVAL 3 DAY);
