1) В MySQL Workbench выполни sql/schema.sql
2) В config.py укажи DB_USER/DB_PASSWORD
3) pip install PyQt6 pymysql
4) python main.py
Тестовые пользователи:
seller / 123
proc / 123
client1 / 123
