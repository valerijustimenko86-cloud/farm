
Q = {
  "auth": "SELECT id, role, client_id FROM users WHERE username=%s AND pass_hash=%s",

  "catalog_all": "SELECT * FROM v_catalog ORDER BY ptype, name",
  "catalog_filter_seller": """
    SELECT * FROM v_catalog
    WHERE (%s='' OR name LIKE CONCAT('%%',%s,'%%'))
      AND (%s='' OR color=%s)
      AND (%s='' OR occasion=%s)
      AND price BETWEEN %s AND %s
    ORDER BY ptype, name
  """,
  "catalog_filter_client": """
    SELECT * FROM v_catalog
    WHERE (%s='ALL' OR ptype=%s)
      AND price BETWEEN %s AND %s
    ORDER BY ptype, name
  """,

  "clients_list": "SELECT id, fio FROM clients ORDER BY fio",
  "client_insert": "INSERT INTO clients(fio,phone,email) VALUES(%s,%s,%s)",

  "orders_table": "SELECT * FROM v_orders ORDER BY created_at DESC",
  "orders_by_client": "SELECT * FROM v_orders WHERE email=%s ORDER BY created_at DESC",

  "order_insert": """
    INSERT INTO orders(client_id, desired_date, status, discount_pct, comment, total_amount)
    VALUES(%s,%s,%s,%s,%s,%s)
  """,
  "order_update": """
    UPDATE orders
    SET client_id=%s, desired_date=%s, status=%s, discount_pct=%s, comment=%s, total_amount=%s
    WHERE id=%s
  """,
  "order_set_status": "UPDATE orders SET status=%s WHERE id=%s",

  "order_items_clear": "DELETE FROM order_items WHERE order_id=%s",
  "order_item_add": """
    INSERT INTO order_items(order_id,item_type,ref_id,qty,unit_price,line_sum)
    VALUES(%s,%s,%s,%s,%s,%s)
  """,

  "pack_list": "SELECT id, name, price FROM packaging ORDER BY name",
  "acc_list": "SELECT id, name, price FROM accessories ORDER BY name",

  "product_price": "SELECT price FROM products WHERE id=%s",
  "pack_price": "SELECT price FROM packaging WHERE id=%s",
  "acc_price": "SELECT price FROM accessories WHERE id=%s",

  "payment_upsert": """
    INSERT INTO payments(order_id, method, amount, pay_status)
    VALUES(%s,%s,%s,'PAID')
    ON DUPLICATE KEY UPDATE method=VALUES(method), amount=VALUES(amount), pay_status='PAID', paid_at=NOW()
  """,

  "receipt_head": """
    SELECT v.*, p.method, p.amount, p.paid_at
    FROM v_orders v
    LEFT JOIN payments p ON p.order_id=v.order_id AND p.pay_status='PAID'
    WHERE v.order_id=%s
  """,
  "receipt_lines": """
    SELECT item_type, ref_id, qty, unit_price, line_sum
    FROM order_items
    WHERE order_id=%s
    ORDER BY item_type, id
  """,

  "proc_avg_cost": "CALL sp_avg_flower_cost_by_sort_period(%s,%s,%s)",
  "proc_writeoff_pct": "SELECT fn_writeoff_pct_sort_3m(%s) AS pct",
  "proc_sorts": "SELECT DISTINCT sort FROM products WHERE ptype='FLOWER' AND sort IS NOT NULL ORDER BY sort",
}
